CREATE OR REPLACE FUNCTION alpine_miner_adaboost_changep(schemaname              varchar2,
                                                         tablename               varchar2,
                                                         stamp                   varchar2,
                                                         dependcolumnq           varchar2,
                                                         dependentcolumnreplaceq varchar2,
                                                         dependentcolumnstr      varchar2,
                                                         dependinfor             varchar2array)
  RETURN binary_double  is
  rownumber   binary_double;
  totalpeoso  binary_double;
  i           integer;
  classnumber integer;
  wrongnumber binary_double;
  err         binary_double;
  maxerror    binary_double;
  PRAGMA AUTONOMOUS_TRANSACTION;
  c     binary_double := 0;
  sqlan clob;
BEGIN
  commit;
  execute immediate 'alter table ' || schemaname || '."tp' || stamp ||
                    '"  add("notsame" int)';
  execute immediate 'update  ' || schemaname || '."tp' || stamp ||
                    '" set "notsame" = CASE WHEN ' || dependentcolumnstr ||
                    ' = "P(' || dependentcolumnreplaceq ||
                    ')"  THEN 0 ELSE 1 END';
  commit;
  execute immediate 'select count(*) from ' || schemaname || '."tp' ||
                    stamp || '" where "notsame" =1'
    into wrongnumber;
  execute immediate 'select count(*) from ' || schemaname || '.' ||
                    tablename || ''
    into rownumber;
  err := wrongnumber / rownumber;
  execute immediate 'select "count" from ( select ' || dependcolumnq ||
                    ', count(*) "count" from ' || schemaname || '.' ||
                    tablename || ' group by ' || dependcolumnq ||
                    '  order by "count" desc ) where rownum <=1'
    into maxerror;
  commit;
  maxerror := maxerror / rownumber;
  IF err >= maxerror THEN
    c := 0.001;
    execute immediate 'update ' || schemaname || '."pnew' || stamp ||
                      '"  set "alpine_adaboost_peoso"=' || 1 / rownumber ||
                      ',"alpine_adaboost_totalpeoso"=rownum*' ||
                      1 / rownumber;
    commit;
  ELSIF err = 0 THEN
    c := 3;
    execute immediate 'update ' || schemaname || '."pnew' || stamp ||
                      '"  set "alpine_adaboost_peoso"=' || 1 / rownumber ||
                      ',"alpine_adaboost_totalpeoso"=rownum*' ||
                      1 / rownumber;
    commit;
  ELSE
    c          := ln((1 - err) / err);
    c          := c / 2;
    totalpeoso := 0;
    execute immediate 'alter table ' || schemaname || '."pnew' || stamp ||
                      '"  add ("notsame" int)';
    commit;
    execute immediate 'update  ' || schemaname || '."pnew' || stamp ||
                      '"  set "notsame" = (select  ' || schemaname ||
                      '."tp' || stamp || '"."notsame" from ' || schemaname ||
                      '."tp' || stamp || '" where ' || schemaname ||
                      '."pnew' || stamp || '"."alpine_adaboost_id" = ' ||
                      schemaname || '."tp' || stamp ||
                      '"."alpine_adaboost_id")';
    commit;
    execute immediate 'update  ' || schemaname || '."pnew' || stamp ||
                      '" set  "alpine_adaboost_peoso" = "alpine_adaboost_peoso"*exp(' || c ||
                      '*"notsame") ';
    commit;
--    execute immediate 'select sum("alpine_adaboost_peoso") from ' ||
 --                     schemaname || '."pnew' || stamp || '"'
 --     into totalpeoso;
 --   commit;
 --   execute immediate 'update  ' || schemaname || '."pnew' || stamp ||
 --                     '" set  "alpine_adaboost_peoso" = "alpine_adaboost_peoso"/' ||
 --                     totalpeoso;
 --   commit;
    execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                      '."sp' || stamp || '"'')';
    execute immediate 'Create  table ' || schemaname || '."sp' || stamp ||
                      '" as select "alpine_adaboost_id", "alpine_adaboost_peoso", sum("alpine_adaboost_peoso")over (order by "alpine_adaboost_id" ) alpine_sum_peoso from ' ||
                      schemaname || '."pnew' || stamp || '"';
    commit;
    execute immediate 'update  ' || schemaname || '."pnew' || stamp ||
                      '" set  "alpine_adaboost_totalpeoso" = (select alpine_sum_peoso from ' ||
                      schemaname || '."sp' || stamp || '" where ' ||
                      schemaname || '."pnew' || stamp ||
                      '"."alpine_adaboost_id" = ' || schemaname || '."sp' ||
                      stamp || '"."alpine_adaboost_id")';
    commit;
    execute immediate 'alter table ' || schemaname || '."pnew' || stamp ||
                      '"  drop column "notsame"';
  END IF;
  commit;
  classnumber := dependinfor.count();
  i           := 2;
  sqlan       := 'update ' || schemaname || '."p' || stamp || '" set "C(' ||
                 dependinfor(1) || ')" ="C(' || dependinfor(1) ||
                 ')" + (select "C(' || dependinfor(1) || ')" from  ' ||
                 schemaname || '."tp' || stamp || '"  where ' || schemaname ||
                 '."p' || stamp || '"."alpine_adaboost_id" = ' ||
                 schemaname || '."tp' || stamp ||
                 '"."alpine_adaboost_id")*' || c;
  while i <= classnumber loop
    dbms_lob.append(sqlan,
                    ' , "C(' || dependinfor(i) || ')" ="C(' ||
                    dependinfor(i) || ')" + (select "C(' || dependinfor(i) ||
                    ')" from  ' || schemaname || '."tp' || stamp ||
                    '"  where ' || schemaname || '."p' || stamp ||
                    '"."alpine_adaboost_id" = ' || schemaname || '."tp' ||
                    stamp || '"."alpine_adaboost_id") *' || c);
    i := i + 1;
  end loop;
  execute immediate sqlan;
  commit;
  RETURN(c);
END;

/



CREATE OR REPLACE FUNCTION alpine_miner_adaboost_initpre(schemaname   varchar2,
                                                         tablename    varchar2,
                                                         stamp        varchar2,
                                                         dependcolumn varchar2,
                                                         infor        varchar2array)
  RETURN integer is
  tempstring clob;
  i          integer := 0;
  idtable    varchar2(32767);
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
  if schemaname is null then
    idtable := '"id' || stamp || '"';
  else
    idtable := schemaname || '."id' || stamp || '"';
  end if;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || idtable || ''')';
  execute immediate 'Create  table ' || idtable || ' as (select ' ||
                    tablename ||
                    '.*,row_number()over(order by 1) "alpine_adaboost_id" from ' ||
                    tablename || ')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || tablename ||
                    ''')';
  execute immediate 'Create  table ' || tablename || ' as select * from ' ||
                    idtable;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || idtable || ''')';
  tempstring := 'update ' || tablename || ' set "C(' || infor(1) || ')"=0';
  i          := 0;
  for i in 2 .. infor.count() loop
    dbms_lob.append(tempstring, ', "C(' || infor(i) || ')"=0');
  end loop;
  execute immediate tempstring;
  commit;
  RETURN i;
end alpine_miner_adaboost_initpre;

/

CREATE OR REPLACE FUNCTION alpine_miner_adaboost_inittra(schemaname   varchar2,
                                                         tablename    varchar2,
                                                         stamp        varchar2,
                                                         dependcolumn varchar2,
                                                         dependinfor  varchar2array)
  RETURN integer is
  sqlan       clob;
  sqlan1      clob;
  rownumber   integer;
  classnumber integer;
  peoso       binary_double;
  i           integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."pnew' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."dn' || stamp || '"'')';
  execute immediate 'alter session force parallel dml';
  execute immediate 'Create  table ' || schemaname || '."dn' || stamp ||
                    '" parallel  as (select ' || schemaname || '.' ||
                    tablename || '.* from ' || schemaname || '.' ||
                    tablename || ' where ' || dependcolumn ||
                    ' is not null)';
  execute immediate 'alter session disable parallel dml';
  execute immediate 'select count(*)   from ' || schemaname || '."dn' ||
                    stamp || '"'
    into rownumber;
  peoso := 1.0 / rownumber;
 
  execute immediate 'Create  table ' || schemaname || '."pnew' || stamp ||
                    '"    as (select ' || schemaname || '."dn' ||
                    stamp ||
                    '".*, row_number()over(order by 1) "alpine_adaboost_id", ' ||
                    peoso || ' "alpine_adaboost_peoso", rownum*' || peoso ||
                    ' "alpine_adaboost_totalpeoso" from ' || schemaname ||
                    '."dn' || stamp || '") ';
  classnumber := dependinfor.count();
  
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS( ''' || schemaname ||
                    '."tp' || stamp || '"'')';
  execute immediate 'alter session force parallel dml';
  execute immediate 'CREATE TABLE ' || schemaname || '."tp' || stamp ||
                    '" parallel   as select * from  ' || schemaname ||
                    '."pnew' || stamp || '" ';
  execute immediate 'alter session disable parallel dml';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."p' || stamp || '"'')';
  execute immediate 'alter session force parallel dml';
  execute immediate 'CREATE TABLE ' || schemaname || '."p' || stamp ||
                    '"  parallel as select * from  "pnew' || stamp || '" ';
  execute immediate 'alter session disable parallel dml';
  execute immediate 'alter table ' || schemaname || '."p' || stamp ||
                    '"  drop column  "alpine_adaboost_peoso" ';
  execute immediate 'alter table ' || schemaname || '."p' || stamp ||
                    '"  drop column  "alpine_adaboost_totalpeoso" ';
  i      := 2;
  sqlan  := 'alter table ' || schemaname || '."p' || stamp || '" add ("C(' ||
            dependinfor(1) || ')"   binary_double';
  sqlan1 := 'update ' || schemaname || '."p' || stamp || '" set "C(' ||
            dependinfor(1) || ')"=0';
  while i <= classnumber loop
    dbms_lob.append(sqlan,
                    ',"C(' || dependinfor(i) || ')"   binary_double');
    dbms_lob.append(sqlan1, ' ,"C(' || dependinfor(i) || ')" =0 ');
    i := i + 1;
  end loop;
  dbms_lob.append(sqlan, ')');
  execute immediate sqlan;
  execute immediate sqlan1;
  commit;
  execute immediate 'alter session force parallel dml';
  execute immediate 'create table ' || schemaname || '."s' || stamp ||
                    '"   as select * from ' || schemaname || '."pnew' ||
                    stamp || '"';
  execute immediate 'alter session disable parallel dml';
  commit;
  RETURN rownumber;
end alpine_miner_adaboost_inittra;
/


CREATE OR REPLACE FUNCTION alpine_miner_adaboost_prere(tablename    varchar2,
                                                       dependcolumn varchar2,
                                                       infor        varchar2array,
                                                       isnumeric    int)
  RETURN binary_double AS
  rownumber   integer;
  classnumber integer;
  sqlan       clob;
  sql2        clob;
  peoso       binary_double;
  totalpeoso  binary_double;
  tempstring  varchar2(32767);
  classstring varchar2array;
  i           integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
  err binary_double;
BEGIN
  commit;
  classnumber := infor.count();
  sqlan       := 'update ' || tablename || ' set  "P(' || dependcolumn ||
                 ')" = CASE';
  sql2        := '(';
  i           := classnumber;
  while i > 1 loop
    dbms_lob.append(sql2, '  "C(' || infor(i) || ')" ,');
    i := i - 1;
  end loop;
  dbms_lob.append(sql2, '"C(' || infor(1) || ')" )');
  for i in 1 .. classnumber loop
    dbms_lob.append(sqlan, ' WHEN "C(' || infor(i) || ')"=greatest');
    dbms_lob.append(sqlan, sql2);
    dbms_lob.append(sqlan, ' THEN ');
    if isnumeric = 1 then
      dbms_lob.append(sqlan, infor(i));
    else
      dbms_lob.append(sqlan, '''' || infor(i) || '''');
    end if;
  end loop;
  dbms_lob.append(sqlan, ' END ');
  execute immediate sqlan;
  err := err / rownumber;
  commit;
  RETURN err;
end;
/



CREATE OR REPLACE FUNCTION alpine_miner_adaboost_prestep(tablename     varchar2,
                                                         temptablename varchar2,
                                                         dependcolumn  varchar2,
                                                         c             binary_double,
                                                         infor         varchar2array)
  RETURN binary_double  is
  rownumber   integer;
  classnumber integer;
  sqlan       clob;
  peoso       binary_double;
  totalpeoso  binary_double;
  tempstring  varchar2(32767);
  classstring varchar2array;
  i           integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
  err binary_double;
BEGIN
  commit;
  sqlan := 'update ' || tablename || '  set "C(' || infor(1) || ')"=  "C(' ||
           infor(1) || ')"+ (select "C(' || infor(1) || ')"  from ' ||
           temptablename || '  where ' || tablename ||
           '."alpine_adaboost_id" = ' || temptablename ||
           '."alpine_adaboost_id")*' || c || ' ';
  for i in 2 .. infor.count() loop
    dbms_lob.append(sqlan,
                    ', "C(' || infor(i) || ')"=  "C(' || infor(i) ||
                    ')"+ (select "C(' || infor(i) || ')"  from ' ||
                    temptablename || '  where ' || tablename ||
                    '."alpine_adaboost_id" = ' || temptablename ||
                    '."alpine_adaboost_id")*' || c || ' ');
  end loop;
  execute immediate sqlan;
  commit;
  RETURN c;
end;
/



CREATE OR REPLACE FUNCTION alpine_miner_adaboost_sample(schemaname varchar2,
                                                        tablename  varchar2,
                                                        stamp      varchar2,
                                                        partsize   integer)
  RETURN varchar2 is
  tempstring varchar2(32767);
  rownumber integer;
 
   TYPE crt IS REF CURSOR;
  myrecord crt;
  partnumber integer;
  splitpeoso Numberarray:=Numberarray();
  maxpeoso number;
  temppeoso number;
  i        integer;
  executesql varchar2(32767);
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
  execute immediate 'select count(*) from '||schemaname||'.'||tablename into rownumber;
  execute immediate ' select max("alpine_adaboost_totalpeoso")  from '||schemaname||'.'||tablename into maxpeoso;
   
 	if partsize>= rownumber
	then 
		partnumber:=1;
	else 
		if mod(rownumber ,partsize)=0
		then
			partnumber:= rownumber/partsize;
		else 
			partnumber:=trunc(rownumber/partsize)+1;
		end if;
	end if;

  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."s' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."r' || stamp || '"'')';
 
  execute immediate 'create table ' || schemaname || '."r' || stamp ||
                    '"      as select SYS.DBMS_RANDOM.VALUE(0,'||maxpeoso||')  "alpine_miner_adaboost_r" from ' ||
                    schemaname || '.' || tablename || ' order by SYS.DBMS_RANDOM.VALUE(0,'||maxpeoso||')';
  
  if partnumber=1
  then
    executesql := 'alter session force parallel dml';
   execute immediate executesql;
  execute immediate 'create table ' || schemaname || '."s' || stamp ||
                    '"  parallel  as select * from ' || schemaname || '.' ||
                    tablename || ' join ' || schemaname || '."r' || stamp ||
                    '" on ' || schemaname || '.' || tablename ||
                    '."alpine_adaboost_totalpeoso"  >= ' || schemaname ||
                    '."r' || stamp || '"."alpine_miner_adaboost_r" and ' || schemaname || '.' ||
                    tablename || '."alpine_adaboost_peoso" > (' ||
                    schemaname || '.' || tablename ||
                    '."alpine_adaboost_totalpeoso"-' || schemaname || '."r' ||
                    stamp || '"."alpine_miner_adaboost_r")';
    executesql := 'alter session disable parallel dml';
   execute immediate executesql;                  
    commit;                
  else 
  	tempstring:=' select "alpine_adaboost_totalpeoso" as peoso from '||schemaname||'.'||tablename||' where mod("alpine_adaboost_id",'||partsize||')=0 order by peoso';
 
    i:=1;
    splitpeoso.extend();
    splitpeoso(i):=0;
     open myrecord for tempstring;
  loop
   FETCH myrecord INTO temppeoso;
   EXIT WHEN myrecord%NOTFOUND;
   i:=i+1;
    splitpeoso.extend();
   splitpeoso(i):=temppeoso;
      
   end loop;
   if splitpeoso(i)!=maxpeoso
   then 
  
      i:=i+1;
       splitpeoso.extend();
      splitpeoso(i):=maxpeoso;
        
   end if;
   
   
   
   i:=1;
    executesql := 'alter session force parallel dml';
   execute immediate executesql;
   	tempstring:='create table '||schemaname||'."s'||stamp||'"  parallel as select * from  ( select * from '||schemaname||'.'||tablename||' 
			where "alpine_adaboost_totalpeoso">'||splitpeoso(i)||' and  "alpine_adaboost_totalpeoso"<='||splitpeoso(i+1)||')   foo'||i||' join (select * from "r'||stamp||'" where "alpine_miner_adaboost_r"
			>'||splitpeoso(i)||' and  "alpine_miner_adaboost_r"<='||splitpeoso(i+1)||')   foor'||i||' on foo'||i||'."alpine_adaboost_totalpeoso" >=foor'||i||'."alpine_miner_adaboost_r" and foo'||i||'."alpine_adaboost_peoso" > 
		(foo'||i||'."alpine_adaboost_totalpeoso"-foor'||i||'."alpine_miner_adaboost_r") ';
  		execute  immediate tempstring;
       executesql := 'alter session disable parallel dml';
   execute immediate executesql;                  
    commit;      
   
      		for i in 2..partnumber loop
			tempstring:= '  insert into  '||schemaname||'."s'||stamp||'"   select * from ( select * from '||schemaname||'.'||tablename||' 
  			where "alpine_adaboost_totalpeoso">'||splitpeoso(i)||' and  "alpine_adaboost_totalpeoso"<='||splitpeoso(i+1)||')   foo'||i||' join (select * from "r'||stamp||'" where "alpine_miner_adaboost_r" 
  			>'||splitpeoso(i)||' and "alpine_miner_adaboost_r"<='||splitpeoso(i+1)||')   foor'||i||' on foo'||i||'."alpine_adaboost_totalpeoso" >=foor'||i||'."alpine_miner_adaboost_r" and foo'||i||'."alpine_adaboost_peoso" > 
 			(foo'||i||'."alpine_adaboost_totalpeoso"-foor'||i||'."alpine_miner_adaboost_r") ';
		    execute  immediate 'select count(*) from '||schemaname||'."s'||stamp||'"' into  rownumber;
  			execute immediate  tempstring;
     
   		end loop;
 	end if;    
  tempstring := 's' || stamp;
  commit;
  RETURN tempstring;
end alpine_miner_adaboost_sample;


/



CREATE OR REPLACE FUNCTION alpine_miner_adaboost_cleanre(schemaname varchar2,
                                                         stamp      varchar2)
  return integer is
  rownumber   integer;
  classnumber integer;
  sqlan       varchar2(32767);
  sql2        varchar2(32767);
  i           integer := 0;
  err         binary_double;
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."pnew' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."dn' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."pnew' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS( ''' || schemaname ||
                    '."tp' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."p' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."s' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."r' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                      '."sp' || stamp || '"'')';
  return 0;
end;
/



  CREATE OR REPLACE FUNCTION ALPINE_MINER_CONTAINS (array varchar2array, element varchar2)
return integer
as
begin
	for i in 1..array.count() loop
		if array(i) = element then
			return 1;
		end if;
	end loop;
	return 0;
end;
/
 

  CREATE OR REPLACE FUNCTION ALPINE_MINER_SPLIT 
(
    p_list varchar2,
    p_del varchar2 := ','
) return varchar2array
is
    l_idx    pls_integer;
    l_list    varchar2(32767) := p_list;
    l_value    varchar2(32767);
    result varchar2array := varchar2array();
begin
    loop
        l_idx := instr(l_list,p_del);
        if l_idx > 0 then
            result.extend();
            result(result.count()):= (substr(l_list,1,l_idx-1));
            l_list := substr(l_list,l_idx+length(p_del));
        else
            result.extend();
            result(result.count()) := l_list;
            exit;
        end if;
    end loop;
    return result;
end;
/
 

create or replace
FUNCTION ALPINE_MINER_AR_PREDICT (text_attribute integer, attribute_double FloatArray, attribute_text varchar2Array, positive varchar2, ar varchar2)-- ar clob)
return varchar2
as
	--sqlstr varchar2(4000) := '';
	i int := 0;
	result varchar2(4000) := null;
	result_array varchar2array := varchar2array();
	premise_conclusion_array varchar2array := varchar2array();
	premise_array varchar2array := varchar2array();
	conclusion_array varchar2array := varchar2array();
	ar_array varchar2array := varchar2array();
	--arribute_length integer := 0;
	conclusion_ok integer := 1;
	premise_str varchar2(4000);
	conclusion_str varchar2(4000);
BEGIN
    if ar = ''  or ar is null then
      return null;
    end if;
		ar_array := alpine_miner_split(ar, ';');
		for i in 1..ar_array.count() loop
			premise_conclusion_array := alpine_miner_split(ar_array(i), ':');
			premise_str := premise_conclusion_array(1);
			premise_array := alpine_miner_split(premise_str, '|');
			conclusion_str := premise_conclusion_array(2);
			conclusion_array := alpine_miner_split(conclusion_str, '|');
			conclusion_ok := 1;
			if text_attribute = 1 then
				if attribute_text(TO_NUMBER(conclusion_array(2))) = positive then
					GOTO label_continue;
				end if;
			else
				if attribute_double(TO_NUMBER(conclusion_array(2)))=TO_NUMBER(positive) then
					GOTO label_continue;
				end if;
			end if;

			for j in 1.. premise_array.count() loop
				if  text_attribute = 1 then
					if attribute_text(TO_NUMBER(premise_array(j))) !=  positive then
						conclusion_ok := 0;
						exit;
					end if;
				else
					if attribute_double(TO_NUMBER(premise_array(j)))!=  TO_NUMBER(positive) then
						conclusion_ok := 0;
						exit;
					end if;
				end if;
			end loop;
			if conclusion_ok = 1 then
				if alpine_miner_contains(result_array, conclusion_array(1))  = 0 then
					result_array.extend();
					result_array(result_array.count()) := conclusion_array(1);
					if result is not null then
						result := result||',';
					end if;
					result := result || conclusion_array(1);
				end if;
			end if;
		    <<label_continue>>
    		NULL;
		end loop;
	RETURN result;
END;

/
 
create or replace type Floatarray is  varray(100000000) of binary_double;
/
create or replace type IntegerArray is  varray(100000000) of Integer;
/
create or replace type Varchar2Array is Varray(100000000) of Varchar2(4000);
/
create or replace type Numberarray is  varray(100000000) of number;
/

create or replace
type FloatArrayArray is  varray(100000000) of FloatArray;
/

create or replace
type IntegerArrayArray is  varray(100000000) of IntegerArray;
/

create or replace
type Varchar2ArrayArray is  varray(100000000) of Varchar2Array;
/

create or replace function alpine_miner_faa2fa(f_arrayarray FloatArrayArray)
return FloatArray
as
i integer := 0;
j integer := 0;
k integer := 0;
f_array FloatArray := FloatArray();
temp FloatArray;
begin
	for i in 1..f_arrayarray.count() loop
		temp := f_arrayarray(i);
		for j in 1..temp.count() loop
			f_array.extend();
			k := k + 1;
			f_array(k) :=  temp(j);
		end loop;
	end loop;
	return f_array;
end;
/
create or replace function alpine_miner_iaa2ia(i_arrayarray IntegerArrayArray)
return IntegerArray
as
i integer := 0;
j integer := 0;
k integer := 0;
i_array IntegerArray := IntegerArray();
temp IntegerArray;
begin
	for i in 1..i_arrayarray.count() loop
		temp := i_arrayarray(i);
		for j in 1..temp.count() loop
			i_array.extend();
			k := k + 1;
			i_array(k) :=  temp(j);
		end loop;
	end loop;
	return i_array;
end;
/


create or replace function alpine_miner_v2aa2v2a(v_arrayarray Varchar2ArrayArray)
return Varchar2Array
as
i integer := 0;
j integer := 0;
k integer := 0;
v_array Varchar2Array := Varchar2Array();
temp Varchar2Array;
begin
	for i in 1..v_arrayarray.count() loop
		temp := v_arrayarray(i);
		for j in 1..temp.count() loop
			v_array.extend();
			k := k + 1;
			v_array(k) :=  temp(j);
		end loop;
	end loop;
	return v_array;
end;
/

create or replace
function alpine_miner_get_fa_element(farray FloatArray, elementindex integer)
return binary_double
as 
begin
	if (elementindex > 0 and elementindex <= farray.count())
	then
		return farray(elementindex);
	else
		return null;
	end if;
end;
/

create or replace
function alpine_miner_get_ia_element(iarray IntegerArray, elementindex integer)
return binary_double
as
begin
  if (elementindex > 0 and elementindex <= iarray.count())
  then
    return iarray(elementindex);
  else
    return null;
  end if;
end;
/
create or replace
function alpine_miner_get_faa_element(farrayarray FloatArrayArray, elementindex number)
return binary_double
as
  countTotal integer := 0;
  i integer := 0;
  farray FloatArray;
begin
  for i in 1..farrayarray.count() loop
    farray := farrayarray(i);
    if (countTotal + farray.count()>= elementindex) then
      return farray(elementindex - countTotal);
    end if;
    countTotal := countTotal + farray.count();
  end loop;
  return null;
end;
/

create or replace
function alpine_miner_null_to_0(value number)
return number
as
begin
	if(value is null) then return 0; else return value; end if;
end;
/

create or replace
FUNCTION ALPINE_MINER_ARRAY_COUNT
( arrayarray IN FLOATARRAYARRAY
) RETURN INTEGER AS
  countTotal integer := 0;
  i integer := 0;
  farray FloatArray;
BEGIN
  for i in 1..arrayarray.count() loop
    farray := arrayarray(i);
    countTotal := countTotal + farray.count();
  end loop;
  RETURN countTotal;
END ALPINE_MINER_ARRAY_COUNT;
/



create or replace function alpine_miner_get_v2a_element(v2array varchar2Array, elementindex integer) 
return varchar2 as 
begin if (elementindex > 0 and elementindex <= v2array.count()) 
then return v2array(elementindex);
 else return null; 
 end if; 
 end;
 
 /

 create or replace function alpine_miner_get_v2aa_element(v2arrayarray varchar2ArrayArray,
                                                          elementindex number)
   return varchar2 as
   countTotal integer := 0;
   i          integer := 0;
   v2array    varchar2Array;
 begin
   for i in 1 .. v2arrayarray.count() loop
     v2array := v2arrayarray(i);
     if (countTotal + v2array.count() >= elementindex) then
       return v2array(elementindex - countTotal);
     end if;
     countTotal := countTotal + v2array.count();
   end loop;
   return null;
 end;
/
 create or replace function alpine_miner_v2aa2faa(column_namearray          varchar2ArrayArray,
                                                  column_array_length_array integerArrayArray)
   return clob as
   i          integer := 0;
   j          integer := 0;
   l          integer := 0;
   i_index    integer := 0;
   j_index    integer := 0;
   firstflag  integer := 1;
   resultclob clob := '';
   v_array    varchar2Array;
   countTotal integer := 0;
   PRAGMA AUTONOMOUS_TRANSACTION;
 begin
   for i in 1 .. column_namearray.count() loop
     v_array    := column_namearray(i);
     countTotal := countTotal + v_array.count();
   end loop;
   resultclob := resultclob || 'floatarrayarray(';
   i_index    := trunc(countTotal / 999);
   j_index    := countTotal - 999 * i_index;
   for i in 1 .. i_index loop
     if firstflag = 1 then
       firstflag := 0;
     else
       resultclob := resultclob || ',';
     end if;
     resultclob := resultclob || 'floatarray(';
     for j in 0 .. 999 loop
       if j != 1 then
         resultclob := resultclob || ',';
       end if;
       if alpine_miner_get_iaa_element(column_array_length_array,
                                       (i - 1) * 999 + j) < 1 then
         resultclob := resultclob || 'cast("' ||
                       alpine_miner_get_v2aa_element(column_namearray,
                                                     (i - 1) * 999 + j) ||
                       '"  as binary_double)';
       else
         l := 1;
         while l <= alpine_miner_get_iaa_element(column_array_length_array,
                                                 (i - 1) * 999 + j) loop
           if l != 1 then
             resultclob := resultclob || ',';
           end if;
           resultclob := resultclob ||
                         'cast(alpine_miner_get_faa_element("' ||
                         alpine_miner_get_v2aa_element(column_namearray,
                                                       (i - 1) * 999 + j) || '",' || l ||
                         ')  as binary_double)';
           l          := l + 1;
         end loop;
       end if;
     end loop;
     resultclob := resultclob || ')';
   end loop;
   if j_index > 0 then
     if firstflag = 1 then
       firstflag := 0;
     else
       resultclob := resultclob || ',';
     end if;
     resultclob := resultclob || 'floatarray(';
     for j in 1 .. j_index loop
       if j != 1 then
         resultclob := resultclob || ',';
       end if;
       if alpine_miner_get_iaa_element(column_array_length_array,
                                       i_index * 999 + j) < 1 then
         resultclob := resultclob || 'cast("' ||
                       alpine_miner_get_v2aa_element(column_namearray,
                                                     i_index * 999 + j) ||
                       '" as binary_double)';
       else
         l := 1;
         while l <= alpine_miner_get_iaa_element(column_array_length_array,
                                                 i_index * 999 + j) loop
           if l != 1 then
             resultclob := resultclob || ',';
           end if;
           resultclob := resultclob ||
                         'cast(alpine_miner_get_faa_element("' ||
                         alpine_miner_get_v2aa_element(column_namearray,
                                                       i_index * 999 + j) || '",' || l ||
                         ')  as binary_double)';
           l          := l + 1;
         end loop;
       end if;
     end loop;
     resultclob := resultclob || ')';
   end if;
   resultclob := resultclob || ')';
   RETURN resultclob;
 end alpine_miner_v2aa2faa;
/
create or replace function alpine_miner_v2aa2faaavg(column_namearray          varchar2ArrayArray,
                                                    column_array_length_array integerArrayArray)
  return clob as
  i          integer := 0;
  j          integer := 0;
  l          integer := 0;
  i_index    integer := 0;
  j_index    integer := 0;
  firstflag  integer := 1;
  resultclob clob := '';
  v_array    varchar2Array;
  countTotal integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  for i in 1 .. column_namearray.count() loop
    v_array    := column_namearray(i);
    countTotal := countTotal + v_array.count();
  end loop;
  resultclob := resultclob || 'floatarrayarray(';
  i_index    := trunc(countTotal / 999);
  j_index    := countTotal - 999 * i_index;
  for i in 1 .. i_index loop
    if firstflag = 1 then
      firstflag := 0;
    else
      resultclob := resultclob || ',';
    end if;
    resultclob := resultclob || 'floatarray(';
    for j in 0 .. 999 loop
      if j != 1 then
        resultclob := resultclob || ',';
      end if;
      if alpine_miner_get_iaa_element(column_array_length_array,
                                      (i - 1) * 999 + j) < 1 then
        resultclob := resultclob || 'trunc(avg("' ||
                      alpine_miner_get_v2aa_element(column_namearray,
                                                    (i - 1) * 999 + j) ||
                      '"),10)';
      else
        l := 1;
        while l <= alpine_miner_get_iaa_element(column_array_length_array,
                                                (i - 1) * 999 + j) loop
          if l != 1 then
            resultclob := resultclob || ',';
          end if;
          resultclob := resultclob ||
                        'trunc(avg(alpine_miner_get_faa_element("' ||
                        alpine_miner_get_v2aa_element(column_namearray,
                                                      (i - 1) * 999 + j) || '",' || l ||
                        ')),10)';
          l          := l + 1;
        end loop;
      end if;
    end loop;
    resultclob := resultclob || ')';
  end loop;
  if j_index > 0 then
    if firstflag = 1 then
      firstflag := 0;
    else
      resultclob := resultclob || ',';
    end if;
    resultclob := resultclob || 'floatarray(';
    for j in 1 .. j_index loop
      if j != 1 then
        resultclob := resultclob || ',';
      end if;
      if alpine_miner_get_iaa_element(column_array_length_array,
                                      i_index * 999 + j) < 1 then
        resultclob := resultclob || 'trunc(avg("' ||
                      alpine_miner_get_v2aa_element(column_namearray,
                                                    i_index * 999 + j) ||
                      '"),10)';
      else
        l := 1;
        while l <= alpine_miner_get_iaa_element(column_array_length_array,
                                                i_index * 999 + j) loop
          if l != 1 then
            resultclob := resultclob || ',';
          end if;
          resultclob := resultclob ||
                        'trunc(avg(alpine_miner_get_faa_element("' ||
                        alpine_miner_get_v2aa_element(column_namearray,
                                                      i_index * 999 + j) || '",' || l ||
                        ')),10)';
          l          := l + 1;
        end loop;
      end if;
    end loop;
    resultclob := resultclob || ')';
  end if;
  resultclob := resultclob || ')';
  RETURN resultclob;
end alpine_miner_v2aa2faaavg;
/
create or replace function alpine_miner_get_iaa_element(iarrayarray  IntegerArrayArray,
                                                         elementindex integer)
   return float as
   countTotal integer := 0;
   i          integer := 0;
   iarray     IntegerArray;
 begin
   for i in 1 .. iarrayarray.count() loop
     iarray := iarrayarray(i);
     if (countTotal + iarray.count() >= elementindex) then
       return iarray(elementindex - countTotal);
     end if;
     countTotal := countTotal + iarray.count();
   end loop;
   return null;
 end alpine_miner_get_iaa_element;
/


	create or replace type FloatarraySumImpl as object
(
  varraysum Floatarray,
  static function ODCIAggregateInitialize(fs IN OUT FloatarraySumImpl) 
    return number,
  member function ODCIAggregateIterate(self IN OUT FloatarraySumImpl, 
    value IN Floatarray) return number,
  member function ODCIAggregateTerminate(self IN FloatarraySumImpl, 
    returnValue OUT Floatarray, flags IN number) return number,
  member function ODCIAggregateMerge(self IN OUT FloatarraySumImpl, 
    fs2 IN FloatarraySumImpl) return number
)
	;
/
	
	create or replace type body FloatarraySumImpl is 
static function ODCIAggregateInitialize(fs IN OUT FloatarraySumImpl) 
return number is 
arraysum Floatarray := floatArray();
begin
  fs := FloatarraySumImpl(floatArray());
  fs.varraysum := (arraysum);
  return ODCIConst.Success;
end;

member function ODCIAggregateIterate(self IN OUT FloatarraySumImpl, value IN Floatarray) return number is
i integer := 0;
begin
  if self.varraysum.count() = 0 then
    for i in 1..value.count() loop
      self.varraysum.extend();
      self.varraysum(i) := 0.0;
    end loop;
  end if;
  for i in 1..value.count() loop
    self.varraysum(i) := self.varraysum(i) + value(i);
  end loop;
  return ODCIConst.Success;
end;

member function ODCIAggregateTerminate(self IN FloatarraySumImpl, 
    returnValue OUT Floatarray, flags IN number) 
return number is
begin
  returnValue := self.varraysum;
  return ODCIConst.Success;
end;

member function ODCIAggregateMerge(self IN OUT FloatarraySumImpl, fs2 IN FloatarraySumImpl) 
return number is
i integer :=0;
mincount integer := 0;
begin
  if self.varraysum.count() < fs2.varraysum.count() then
    for i in 1..self.varraysum.count() loop
      self.varraysum(i) := self.varraysum(i) + fs2.varraysum(i);
    end loop;
    for i in (self.varraysum.count()+1)..fs2.varraysum.count() loop
      self.varraysum.extend();
      self.varraysum(i) := fs2.varraysum(i);
    end loop;
  else
    for i in 1..fs2.varraysum.count() loop
      self.varraysum(i) := self.varraysum(i) + fs2.varraysum(i);
    end loop;
  end if;
  return ODCIConst.Success;
end;
end;
/

create or replace
FUNCTION FloatarraySum (input FloatArray) RETURN FloatArray 
 PARALLEL_ENABLE  AGGREGATE USING FloatarraySumImpl;
/

create or replace
FUNCTION floatarraysum_cursor(sqlarray VARCHAR2ARRAY)
RETURN floatarray AS
  TYPE crt IS REF CURSOR;
  sqlstr clob := ' ';
  c1 crt;
  fa floatArray;
  ret floatarray := floatarray();
  i int := 0;
  j int := 0;

BEGIN
  for i in 1..sqlarray.count() loop
     dbms_lob.append(sqlstr,sqlarray(i));
  end loop;
  open c1 for sqlstr;
  i := 1;

  LOOP

  FETCH c1 INTO fa;
  EXIT WHEN c1%NOTFOUND;

  IF i = 1 THEN
  	for j in 1..fa.count() loop
		ret.extend();
		ret(j) := fa(j);
	end loop;
  ELSE
  	for j in 1..fa.count() loop
		ret(j) := ret(j) + fa(j);
	end loop;
  END IF;

  i := i + 1;
  END LOOP;
  return ret;
END;
/


create or replace
FUNCTION getAMVersion
RETURN varchar2 AS
BEGIN
  return 'Alpine Miner Release 5.0';
END;

/

CREATE OR REPLACE FUNCTION alpine_farray_to_clob(dataarray  floatarray,splitchar varchar2)
return clob is
indexnumber binary_double;
resultdata clob;
begin
indexnumber:=1;
resultdata:='';
dbms_lob.append(resultdata,to_char(dataarray(1)));
for indexnumber in 2 .. dataarray.count() loop
	  dbms_lob.append( resultdata,splitchar||dataarray(indexnumber));

  end loop;

return resultdata;
END alpine_farray_to_clob;

/

CREATE OR REPLACE FUNCTION alpine_farray_to_string(dataarray  floatarray,splitchar varchar2)
return varchar2 is
indexnumber binary_double;
resultdata varchar2(32767);
begin
indexnumber:=1;
resultdata:=dataarray(1);
for indexnumber in 2 .. dataarray.count() loop
    resultdata:=resultdata||splitchar||dataarray(indexnumber);

  end loop;

return resultdata;
END alpine_farray_to_string;

/

CREATE OR REPLACE FUNCTION alpine_varray_to_clob(dataarray  varchar2array,splitchar varchar2)
return clob is
indexnumber binary_double;
resultdata clob;
begin
indexnumber:=1;
resultdata:=dataarray(1);
for indexnumber in 2 .. dataarray.count() loop
	  dbms_lob.append( resultdata,splitchar||dataarray(indexnumber));

  end loop;

return resultdata;
END alpine_varray_to_clob;


/


CREATE OR REPLACE FUNCTION alpine_varray_to_string(dataarray  varchar2array,splitchar varchar2)
return varchar2 is
indexnumber binary_double;
resultdata varchar2(32767);
begin
indexnumber:=1;
resultdata:=dataarray(1);
for indexnumber in 2 .. dataarray.count() loop
	  resultdata:=resultdata||splitchar||dataarray(indexnumber);

  end loop;

return resultdata;
END alpine_varray_to_string;

/


CREATE OR REPLACE FUNCTION alpine_iarray_to_clob(dataarray IntegerArray,
                                                 splitchar varchar2)
  return clob is
  indexnumber integer;
  resultdata  clob:=empty_clob();
begin
  indexnumber := 1;
  resultdata  := '';
  resultdata:=resultdata||dataarray(1);
  for indexnumber in 2 .. dataarray.count() loop
     dbms_lob.append(resultdata, splitchar || dataarray(indexnumber));
  end loop;
  return resultdata;
END alpine_iarray_to_clob;


/

CREATE OR REPLACE FUNCTION alpine_iarray_to_string(dataarray  IntegerArray,splitchar varchar2)
return varchar2 is
indexnumber integer;
resultdata varchar2(32767);
begin
indexnumber:=1;
resultdata:=dataarray(1);
for indexnumber in 2 .. dataarray.count() loop
    resultdata:=resultdata||splitchar||dataarray(indexnumber);

  end loop;

return resultdata;
END alpine_iarray_to_string;

/
create or replace function alpine_miner_array_avg(arraydata FloatArray, arraysize integer)
return FloatArray as
	newarraydata FloatArray:=FloatArray();
BEGIN
	for i in 1..arraydata.count() loop
		newarraydata.extend();
		newarraydata(i):=arraydata(i)/arraysize;
	end loop;
	return newarraydata;
end;


/

create or replace function alpine_miner_em_getp(columnarray varchar2array, mu FloatArray,sigma FloatArray,alpha binary_double)
return binary_double as
	peoso binary_double;
	sigmaValue binary_double;
begin
	peoso:=0;
	sigmaValue:=1;
	for i in 1..columnarray.count() loop
		peoso:=peoso+(columnarray(i)-mu(i))*(columnarray(i)-mu(i))/sigma(i);
		sigmaValue:=sigmaValue*sigma(i);
	end loop;
	peoso:=alpha*exp(-0.5*peoso)/sqrt(sigmaValue);
	return peoso;
end;


/


create or replace function alpine_miner_em_getmaxsub(firstarray FloatArray,secondarray FloatArray) 
return binary_double as
	tempsub binary_double;
	maxsub binary_double;
begin
	maxsub:=0;
	for i in 1..firstarray.count() loop
		tempsub:=abs(firstarray(i)-secondarray(i));
		if tempsub>maxsub then maxsub:=tempsub;
		end if;
	end loop;
	return maxsub;
end;

/

create or replace function floatarraydiv(arraydata FloatArray, arraysize integer)
return FloatArray as
  newarraydata FloatArray:=FloatArray();
BEGIN
  for i in 1..arraydata.count() loop
    newarraydata.extend();
    newarraydata(i):=arraydata(i)/arraysize;
  end loop;
  return newarraydata;
end;

/

create or replace function GETFARANGE(farray       FloatArray,
                                                       elementfrom integer,
                                                       elementend integer)
  return varchar2 as
  newdatastring varchar2(32767);
  i integer;
  j integer;
begin
  j:=1;
  i:=1;
  newdatastring:='';
  while(i<=farray.count()) loop
  if (i >=elementfrom and i <= elementend) then
    if j=1 then
	   newdatastring:=newdatastring||farray(i);
       j:=j+1;
       else
	   newdatastring:=newdatastring||','||farray(i);
       j:=j+1;
    end if;
  end if;
  i:=i+1;
  end loop;
  return newdatastring;
end;


/

CREATE OR REPLACE FUNCTION farray_cat(firstarray floatarray,secondarray floatarray)
RETURN floatarray as
newdataarray FloatArray:=FloatArray();
i integer;

begin
i:=1;

 while(i<=firstarray.count()) loop
  newdataarray.extend();
  newdataarray(i):=firstarray(i);
  i:=i+1;
 end loop;
 i:=1;
 while(i<=secondarray.count()) loop
  newdataarray.extend();
  newdataarray(firstarray.count()+i):=secondarray(i);
  i:=i+1;
 end loop;
 return newdataarray;
end;

/

CREATE OR REPLACE FUNCTION array_to_string(varchararray varchar2array,split varchar2)
RETURN clob as
newstring clob;
i integer;
begin
 i:=1;
 while(i<=varchararray.count()) loop
  if i=1
  then
  newstring:=varchararray(i);
  else
  dbms_lob.append(newstring, split||varchararray(i));
  end if;
  i:=i+1;
 end loop;
 return newstring;
end;

/

CREATE OR REPLACE FUNCTION ALPINE_MINER_EM_TRAIN(tablename     varchar2,
                                                  columnname    varchar2array,
                                                  clusternumber integer,
                                                  clustersize   integer,
                                                  maxiteration  integer,
                                                  epsilon       binary_double,
                                                  temptable     varchar2,
                                                  tempbytemp    varchar2,
                                                  sigmas        Floatarray)
   RETURN Floatarray AS
   sqlexecute    clob;
   alpha         Floatarray := Floatarray();
   mu            Floatarray := Floatarray();
   sigma         Floatarray := Floatarray();
   prealpha      Floatarray := Floatarray();
   premu         Floatarray := Floatarray();
   presigma      Floatarray := Floatarray();
   maxsubalpha   binary_double;
   maxsubmu      binary_double;
   maxsubsigma   binary_double;
   maxsubvalue   binary_double;
  
   columnsize    integer;
   tempmu        clob;
   tempsigma     clob;
   tempalpha     clob;
   sumsql        clob;
   tempiteration integer;
   stop          integer;
   i             integer;
   j             integer;
   k             integer;
   TYPE crt IS REF CURSOR;
   myrecord   crt;
   tempa      Floatarray := Floatarray();
   tempmuf    Floatarray := Floatarray();
   tempsigmaf Floatarray := Floatarray();
   tempalphaf Floatarray := Floatarray();
 
   
   PRAGMA AUTONOMOUS_TRANSACTION;
 begin
   columnsize := columnname.count();
   sqlexecute := ' select floatarraydiv(arraydata,cnt) as a from ( select count(*) as cnt,floatarraysum(floatarray(' ||
                 array_to_string(columnname, ',') ||
                 ')) as arraydata from (select mod( rownum,' ||
                 clusternumber || ' ) as clusterid,' ||
                 array_to_string(columnname, ',') ||
                 ' from ( select dbms_random.value as rand,' ||
                 array_to_string(columnname, ',') || ' from ' || tablename ||
                 ' where ' ||
                 array_to_string(columnname, ' is not null and ') ||
                 ' is not null order by rand ) where rownum<=' ||
                 clusternumber || '*' || clustersize ||
                 ') group by clusterid)';
   i          := 1;
   k          := 1;
   j          := 0;
   open myrecord for sqlexecute;
   loop
     FETCH myrecord
       INTO tempa;
     EXIT WHEN myrecord%NOTFOUND;
     if j = 0 then
       mu     := tempa;
       sumsql := '(alpine_miner_em_p' || k;
       j      := 1;
     else
       mu := farray_cat(mu, tempa);
       dbms_lob.append(sumsql, '+alpine_miner_em_p' || k);
     end if;
     alpha.extend();
     alpha(k) := 1.0 / clusternumber;
     k := k + 1;
     i := i + 1;
   end loop;
   dbms_lob.append(sumsql, ') as alpine_miner_em_sum ');
   for i in 1 .. columnsize * clusternumber loop
     sigma.extend();
     sigma(i) := sigmas(i);
   end loop;
   sqlexecute := 'create table ' || tempbytemp || ' parallel as ( select  ' ||
                 tablename || '.*';
   for i in 1 .. clusternumber loop
     dbms_lob.append(sqlexecute,
                     ',alpine_miner_em_getp(varchar2array(' ||
                     array_to_string(columnname, ',') || '),floatarray(' ||
                     GETFARANGE(mu,
                                (i - 1) * columnsize + 1,
                                (i * columnsize)) || '),floatarray(' ||
                     GETFARANGE(sigma,
                                (i - 1) * columnsize + 1,
                                (i * columnsize)) || '),' || alpha(i) ||
                     ') as alpine_miner_em_p' || i);
   end loop;
   sqlexecute := sqlexecute || ' from ' || tablename || ' where ' ||
                array_to_string(columnname, ' is not null and ') ||' is not null)';
   execute immediate 'alter session force parallel dml';
   execute immediate sqlexecute;
   execute immediate 'alter session disable parallel dml';
   sqlexecute := 'create table ' || temptable || ' parallel as (select ' ||
                 tempbytemp || '.* , ' || sumsql || ' from ' || tempbytemp || ' where ' ||
                array_to_string(columnname, ' is not null and ') ||' is not null)';
   execute immediate 'alter session force parallel dml';
   execute immediate sqlexecute;
   execute immediate 'alter session disable parallel dml';
   
   sqlexecute := ' update  ' || temptable ||
                 ' set alpine_miner_em_p1=(case when alpine_miner_em_p1<1e-22 and alpine_miner_em_sum<1e-20 then ' ||
                 1.0 / clusternumber || ' else alpine_miner_em_p1 end)';
   for i in 2 .. clusternumber loop
     sqlexecute := sqlexecute || ',alpine_miner_em_p' || i ||
                   '=(case when alpine_miner_em_p' || i ||
                   '<1e-22 and alpine_miner_em_sum<1e-20 then ' ||
                   1.0 / clusternumber || ' else alpine_miner_em_p' || i ||
                   ' end)';
   end loop;
 
   execute immediate sqlexecute;
  
   sqlexecute := ' update  ' || temptable ||
                 ' set alpine_miner_em_sum=alpine_miner_em_p1';
   for i in 2 .. clusternumber loop
     sqlexecute := sqlexecute || '+alpine_miner_em_p' || i;
   end loop;
  
   execute immediate sqlexecute;
 
   tempiteration := 2;
   stop          := 0;
   while stop = 0 and tempiteration <= maxiteration loop
     prealpha := alpha;
     premu    := mu;
     presigma := sigma;
     for i in 1 .. clusternumber loop
       if i = 1 then
         tempalpha := ' floatarray(avg(alpine_miner_em_p1/alpine_miner_em_sum)';
         for j in 1 .. columnsize loop
           if j = 1 then
             tempmu := ' floatarray(sum(' || columnname(j) ||
                       '*alpine_miner_em_p' || i ||
                       '/alpine_miner_em_sum)/sum(alpine_miner_em_p' || i ||
                       '/alpine_miner_em_sum)';
           else
             dbms_lob.append(tempmu,
                             ',sum(' || columnname(j) ||
                             '*alpine_miner_em_p' || i ||
                             '/alpine_miner_em_sum)/sum(alpine_miner_em_p' || i ||
                             '/alpine_miner_em_sum)');
           end if;
         end loop;
       else
         dbms_lob.append(tempalpha,
                         ',avg(alpine_miner_em_p' || i ||
                         '/alpine_miner_em_sum)');
         for j in 1 .. columnsize loop
           dbms_lob.append(tempmu,
                           ',sum(' || columnname(j) || '*alpine_miner_em_p' || i ||
                           '/alpine_miner_em_sum)/sum(alpine_miner_em_p' || i ||
                           '/alpine_miner_em_sum)');
         end loop;
       end if;
     end loop;
     dbms_lob.append(tempalpha, ') ');
     dbms_lob.append(tempmu, ') ');
     sqlexecute := ' select  ' || tempalpha || ' as alpha from ' ||
                   temptable;
     i          := 1;
     open myrecord for sqlexecute;
     loop
       FETCH myrecord
         INTO tempalphaf;
       EXIT WHEN myrecord%NOTFOUND;
       alpha := tempalphaf;
       i     := i + 1;
     end loop;
     sqlexecute := ' select  ' || tempmu || ' as mu from ' || temptable;
     i          := 1;
     open myrecord for sqlexecute;
     loop
       FETCH myrecord
         INTO tempmuf;
       EXIT WHEN myrecord%NOTFOUND;
       mu := tempmuf;
       i  := i + 1;
     end loop;
     for i in 1 .. clusternumber loop
       for j in 1 .. columnsize loop
         k := (i - 1) * columnsize + j;
         if i = 1 then
           if j = 1 then
             tempsigma := ' floatarray(sum((' || columnname(j) || '- ' ||
                          mu(k) || ')*(' || columnname(j) || '- ' || mu(k) ||
                          ')*alpine_miner_em_p' || i ||
                          '/alpine_miner_em_sum)/sum(alpine_miner_em_p' || i ||
                          '/alpine_miner_em_sum)';
           else
             dbms_lob.append(tempsigma,
                             ',sum((' || columnname(j) || '- ' || mu(k) ||
                             ')*(' || columnname(j) || '- ' || mu(k) ||
                             ')*alpine_miner_em_p' || i ||
                             '/alpine_miner_em_sum)/sum(alpine_miner_em_p' || i ||
                             '/alpine_miner_em_sum)');
           end if;
         else
           dbms_lob.append(tempsigma,
                           ',sum((' || columnname(j) || '- ' || mu(k) ||
                           ')*(' || columnname(j) || '- ' || mu(k) ||
                           ')*alpine_miner_em_p' || i ||
                           '/alpine_miner_em_sum)/sum(alpine_miner_em_p' || i ||
                           '/alpine_miner_em_sum)');
         end if;
       end loop;
     end loop;
     dbms_lob.append(tempsigma, ') ');
     sqlexecute := ' select ' || tempsigma || ' as sigma  from ' ||
                   temptable;
     i          := 1;
     open myrecord for sqlexecute;
     loop
       FETCH myrecord
         INTO tempsigmaf;
       EXIT WHEN myrecord%NOTFOUND;
       sigma := tempsigmaf;
       i     := i + 1;
     end loop;
     maxsubalpha := alpine_miner_em_getmaxsub(prealpha, alpha);
     maxsubmu    := alpine_miner_em_getmaxsub(premu, mu);
     maxsubsigma := alpine_miner_em_getmaxsub(presigma, sigma);
     if maxsubalpha > maxsubmu and maxsubalpha > maxsubsigma then
       maxsubvalue := maxsubalpha;
     else
       if maxsubmu > maxsubalpha and maxsubmu > maxsubsigma then
         maxsubvalue := maxsubmu;
       else
         if maxsubsigma > maxsubalpha and maxsubsigma > maxsubmu then
           maxsubvalue := maxsubsigma;
         end if;
       end if;
     end if;
     if epsilon > maxsubvalue then
       stop := 1;
     end if;
     tempiteration := tempiteration + 1;
   end loop;
   commit;
   RETURN farray_cat(farray_cat(alpha, mu), sigma);
 END;



/


CREATE OR REPLACE FUNCTION alpine_miner_em_predict(outputtable   varchar2,
                                                   predicttable  varchar2,
                                                   columnname    varchar2array,
                                                   modelinfo     FloatArray,
                                                   clusternumber integer,
												   temptablename   varchar2) 
RETURN integer AS
  sqlexecute clob;
  alpha      FloatArray:=FloatArray();
  mu         FloatArray:=FloatArray();
  sigma      FloatArray:=FloatArray();
  columnsize integer;
  sqlsum        clob;
  sqlmax        clob;
  casewhen   clob;
  updatesql  clob;
  resultsql  clob;
  i          integer;
  j          integer;
  k          integer;
  
  Apan clob;
  PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

  columnsize := columnname.count();

  for i in 1 .. clusternumber loop
    alpha.extend();
    alpha(i):= modelinfo(i);
    for j in 1 .. columnsize loop
    mu.extend();
      mu((i - 1) * columnsize + j) := modelinfo(clusternumber + (i - 1) * columnsize + j);
    sigma.extend();
      sigma((i - 1) * columnsize + j) := modelinfo (clusternumber +clusternumber * columnsize +(i - 1) * columnsize + j);
    end loop;
  end loop;

  for i in 1 .. clusternumber loop
    if i = 1 then
      sqlmax       := 'greatest("C(alpine_miner_emClust' || i || ')"';
      sqlsum       := '("C(alpine_miner_emClust' || i || ')"';
      updatesql := ' set "C(alpine_miner_emClust' || i ||
                   ')"="C(alpine_miner_emClust' || i || ')"/alpine_em_sum ';
    else
	dbms_lob.append(sqlmax,',"C(alpine_miner_emClust' || i || ')"');
	dbms_lob.append(sqlsum,'+"C(alpine_miner_emClust' || i || ')"');
	dbms_lob.append(updatesql,',"C(alpine_miner_emClust' || i ||')"="C(alpine_miner_emClust' || i || ')"/alpine_em_sum ');
    end if;
  end loop;

  dbms_lob.append(sqlmax,')');
  dbms_lob.append(sqlsum,') as alpine_em_sum');

  casewhen := ' case ';
  for i in 1 .. clusternumber loop
	dbms_lob.append(casewhen,' when "C(alpine_miner_emClust' || i || ')"=' || sqlmax ||' then  ' || i || ' ');
  end loop;
	dbms_lob.append(casewhen,' end ');

  sqlexecute	:=	' create  table ' || temptablename ||' parallel as (select  '|| predicttable ||'.*';	  
  for i in 1 .. clusternumber loop
	dbms_lob.append(sqlexecute,',alpine_miner_em_getp(varchar2array('||array_to_string(columnname,',')||'),floatarray('||GETFARANGE(mu,(i-1)*columnsize+1,(i*columnsize))||'),floatarray('||GETFARANGE(sigma,(i-1)*columnsize+1,(i*columnsize))||'),'||alpha(i)||') as "C(alpine_miner_emClust' || i ||')"');

  end loop;
  dbms_lob.append(sqlexecute,' from ' || predicttable || ') ');

  execute immediate 'alter session force parallel dml';
  execute immediate sqlexecute;
  execute immediate 'alter session disable parallel dml';
  
  sqlexecute  := ' create  table ' || outputtable||
              ' parallel as select ' || temptablename ||'.* , ' || sqlsum || ', ' || casewhen ||
              ' alpine_em_cluster from '|| temptablename;

  execute immediate 'alter session force parallel dml';
  execute immediate sqlexecute;
  execute immediate 'alter session disable parallel dml';
        
  sqlexecute := ' update ' || outputtable || updatesql;
  execute immediate sqlexecute;
  sqlexecute := ' alter table ' || outputtable || ' drop column alpine_em_sum';
  execute immediate sqlexecute;
  commit;
  return 1;
end;



/


 CREATE OR REPLACE FUNCTION ALPINE_MINER_KMEANS_DISTANCE(distancetype  integer,
                                                         column_name   varchar2array,
                                                         column_number integer,
                                                         k             integer)
   return clob as
   caculate_array clob := ' ';
   temp1          clob := ' ';
   temp2          clob := ' ';
   temp3          clob := ' ';
   temp4          clob := ' ';
   i              integer;
   j              integer;
 begin
   if distancetype = 1 then
     i := 1;
     while i < (k + 1) loop
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number loop
         dbms_lob.append(caculate_array,
                         '(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)-y."k' || i ||
                         column_name(j) || '")*(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)-y."k' || i ||
                         column_name(j) || '")+');
         j := j + 1;
       end loop;
       if i = k then
         dbms_lob.append(caculate_array,
                         '(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)-y."k' || i ||
                         column_name(j) || '")*(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)-y."k' || i ||
                         column_name(j) || '")) as d' || (i - 1));
       else
         dbms_lob.append(caculate_array,
                         '(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)-y."k' || i ||
                         column_name(j) || '")*(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)-y."k' || i ||
                         column_name(j) || '")) as d' || (i - 1) || ',');
       end if;
       i := i + 1;
     end loop;
   elsif distancetype = 2 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       temp1 := '(';
       temp2 := '(';
       while j < column_number loop
         temp1 := temp1 || '(y."k' || i || column_name(j) || '"*ln(y."k' || i ||
                  column_name(j) || '"*cast(1.0 as binary_double)/x."' ||
                  column_name(j) || '"))+';
         temp2 := temp2 || '(y."k' || i || column_name(j) ||
                  '"*cast(1.0 as binary_double)-x."' || column_name(j) ||
                  '")+';
         j     := j + 1;
       end loop;
       temp1 := temp1 || '(y."k' || i || column_name(j) || '"*ln(y."k' || i ||
                column_name(j) || '"*cast(1.0 as binary_double)/x."' ||
                column_name(j) || '")))';
       temp2 := temp2 || '(y."k' || i || column_name(j) ||
                '"*cast(1.0 as binary_double)-x."' || column_name(j) ||
                '"))';
       temp3 := '(' || temp1 || '-' || temp2 || ')';
       if i = k then
         temp3 := temp3 || 'as d' || (i - 1);
       else
         temp3 := temp3 || 'as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp3);
       i := i + 1;
     end loop;
   elsif distancetype = 3 then
     i := 1;
     while i < (k + 1) loop
       j := 1;
       if (i = 1) then
         caculate_array := caculate_array || '(';
       else
         dbms_lob.append(caculate_array, '(');
       end if;
       while j < column_number loop
         dbms_lob.append(caculate_array,
                         '(y."k' || i || column_name(j) ||
                         '"*log(2.0,(y."k' || i || column_name(j) ||
                         '"*cast(1.0 as binary_double)/x."' ||
                         column_name(j) || '")))+');
         j := j + 1;
       end loop;
       if i = k then
         dbms_lob.append(caculate_array,
                         '(y."k' || i || column_name(j) ||
                         '"*log(2.0,(y."k' || i || column_name(j) ||
                         '"*cast(1.0 as binary_double)/x."' ||
                         column_name(j) || '")))) as d' || (i - 1));
       else
         dbms_lob.append(caculate_array,
                         '(y."k' || i || column_name(j) ||
                         '"*log(2.0,(y."k' || i || column_name(j) ||
                         '"*cast(1.0 as binary_double)/x."' ||
                         column_name(j) || '")))) as d' || (i - 1) || ',');
       end if;
       i := i + 1;
     end loop;
   elsif distancetype = 4 then
     i := 1;
     while i < (k + 1) loop
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number loop
         dbms_lob.append(caculate_array,
                         '(abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))-(y."k' || i ||
                         column_name(j) || '"))/abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))+(y."k' || i ||
                         column_name(j) || '")))+');
         j := j + 1;
       end loop;
       if i = k then
         dbms_lob.append(caculate_array,
                         '(abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))-(y."k' || i ||
                         column_name(j) || '"))/abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))+(y."k' || i ||
                         column_name(j) || '")))) as d' || (i - 1));
       else
         dbms_lob.append(caculate_array,
                         '(abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))-(y."k' || i ||
                         column_name(j) || '"))/abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))+(y."k' || i ||
                         column_name(j) || '")))) as d' || (i - 1) || ',');
       end if;
       i := i + 1;
     end loop;
   elsif distancetype = 5 then
     i := 1;
     while i < (k + 1) loop
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number loop
         dbms_lob.append(caculate_array,
                         'abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))-(y."k' || i ||
                         column_name(j) || '"))+');
         j := j + 1;
       end loop;
       if i = k then
         dbms_lob.append(caculate_array,
                         'abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))-(y."k' || i ||
                         column_name(j) || '"))) as d' || (i - 1));
       else
         dbms_lob.append(caculate_array,
                         'abs((x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double))-(y."k' || i ||
                         column_name(j) || '"))) as d' || (i - 1) || ',');
       end if;
       i := i + 1;
     end loop;
   elsif distancetype = 6 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       temp1 := '(';
       temp2 := '(';
       temp3 := '(';
       while j < column_number loop
         temp1 := temp1 || '(x."' || column_name(j) ||
                  '"*cast(1.0 as binary_double)*y."k' || i ||
                  column_name(j) || '")+';
         temp2 := temp2 || '(x."' || column_name(j) ||
                  '"*cast(1.0 as binary_double)*x."' || column_name(j) ||
                  '")+';
         temp3 := temp3 || '(y."k' || i || column_name(j) ||
                  '"*cast(1.0 as binary_double)*y."k' || i ||
                  column_name(j) || '")+';
         j     := j + 1;
       end loop;
       temp1 := temp1 || '(x."' || column_name(j) ||
                '"*cast(1.0 as binary_double)*y."k' || i || column_name(j) ||
                '"))';
       temp2 := temp2 || '(x."' || column_name(j) ||
                '"*cast(1.0 as binary_double)*x."' || column_name(j) ||
                '"))';
       temp3 := temp3 || '(y."k' || i || column_name(j) ||
                '"*cast(1.0 as binary_double)*y."k' || i || column_name(j) ||
                '"))';
       if i = k then
         temp4 := 'acos(case when (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || ')))>1 then 1 when (' || temp1 ||
                  '/(sqrt(' || temp2 || ')*sqrt(' || temp3 ||
                  ')))<-1 then -1 else (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || '))) end ) as d' || (i - 1);
       else
         temp4 := 'acos(case when (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || ')))>1 then 1 when (' || temp1 ||
                  '/(sqrt(' || temp2 || ')*sqrt(' || temp3 ||
                  ')))<-1 then -1 else (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || '))) end ) as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   elsif distancetype = 7 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       temp1 := '(';
       temp2 := '(';
       temp3 := '(';
       while j < column_number loop
         temp1 := temp1 || '(x."' || column_name(j) ||
                  '"*cast(1.0 as binary_double))+';
         temp2 := temp2 || '(y."k' || i || column_name(j) ||
                  '"*cast(1.0 as binary_double))+';
         temp3 := temp3 || '(x."' || column_name(j) ||
                  '"*cast(1.0 as binary_double)*y."k' || i ||
                  column_name(j) || '")+';
         j     := j + 1;
       end loop;
       temp1 := temp1 || '(x."' || column_name(j) || '"))';
       temp2 := temp2 || '(y."k' || i || column_name(j) || '"))';
       temp3 := temp3 || '(x."' || column_name(j) || '"*y."k' || i ||
                column_name(j) || '"))';
       if i = k then
         temp4 := '(-2*' || temp3 || '/(' || temp1 || '+' || temp2 ||
                  ')) as d' || (i - 1);
       else
         temp4 := '(-2*' || temp3 || '/(' || temp1 || '+' || temp2 ||
                  ')) as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   elsif distancetype = 8 then
     i := 1;
     while i < (k + 1) loop
       j := 1;
       dbms_lob.append(caculate_array, '-(');
       while j < column_number loop
         dbms_lob.append(caculate_array,
                         '(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)*y."k' || i ||
                         column_name(j) || '")+');
         j := j + 1;
       end loop;
       if i = k then
         dbms_lob.append(caculate_array,
                         '(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)*y."k' || i ||
                         column_name(j) || '")) as d' || (i - 1));
       else
         dbms_lob.append(caculate_array,
                         '(x."' || column_name(j) ||
                         '"*cast(1.0 as binary_double)*y."k' || i ||
                         column_name(j) || '")) as d' || (i - 1) || ',');
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   elsif distancetype = 9 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       temp1 := '(';
       temp2 := '(';
       temp3 := '(';
       while j < column_number loop
         temp1 := temp1 || '(x."' || column_name(j) ||
                  '"*cast(1.0 as binary_double))+';
         temp2 := temp2 || '(y."k' || i || column_name(j) ||
                  '"*cast(1.0 as binary_double))+';
         temp3 := temp3 || '(x."' || column_name(j) ||
                  '"*cast(1.0 as binary_double)*y."k' || i ||
                  column_name(j) || '")+';
         j     := j + 1;
       end loop;
       temp1 := temp1 || '(x."' || column_name(j) || '"))';
       temp2 := temp2 || '(y."k' || i || column_name(j) || '"))';
       temp3 := temp3 || '(x."' || column_name(j) || '"*y."k' || i ||
                column_name(j) || '"))';
       if i = k then
         temp4 := '(-' || temp3 || '/(' || temp1 || '+' || temp2 || '-' ||
                  temp3 || ')) as d' || (i - 1);
       else
         temp4 := '(-' || temp3 || '/(' || temp1 || '+' || temp2 || '-' ||
                  temp3 || ')) as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   end if;
   return(caculate_array);
 end alpine_miner_kmeans_distance;
/
 CREATE OR REPLACE FUNCTION ALPINE_MINER_KMEANS_DISTANCE1(distancetype              integer,
                                                          column_namearray          varchar2ArrayArray,
                                                          column_array_length_array integerArrayArray,
                                                          column_number             integer,
                                                          k                         integer)
   return clob as
   caculate_array clob := ' ';
   temp1          clob := ' ';
   temp2          clob := ' ';
   temp3          clob := ' ';
   temp4          clob := ' ';
   i              integer := 1;
   j              integer;
   l              integer;
   m              integer;
   i_array        integerarray;
   countTotal     integer := 0;
 begin
   for i in 1 .. column_array_length_array.count() loop
     i_array := column_array_length_array(i);
     if i_array.count() != 0 then
       for j in 1 .. i_array.count() loop
         if alpine_miner_get_ia_element(i_array, j) = 0 then
           countTotal := countTotal + 1;
         else
           countTotal := countTotal +
                         alpine_miner_get_ia_element(i_array, j);
         end if;
       end loop;
     end if;
   end loop;
   if distancetype = 1 then
     i := 1;
     while i < (k + 1) loop
       m := 1;
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           dbms_lob.append(caculate_array,
                           '(x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) ||
                           '"*cast(1.0 as binary_double)-alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                           '))* (x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) ||
                           '"*cast(1.0 as binary_double)-alpine_miner_get_faa_element(y."k' || i || '",' || m || '))');
           if countTotal != m then
             dbms_lob.append(caculate_array, '+');
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             dbms_lob.append(caculate_array,
                             '(alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             ')*cast(1.0 as binary_double)-alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                             '))* (alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             ')*cast(1.0 as binary_double)-alpine_miner_get_faa_element(y."k' || i || '",' || m || '))');
             if countTotal != m then
               dbms_lob.append(caculate_array, '+');
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           dbms_lob.append(caculate_array, ') as d' || (i - 1));
           if i != k then
             dbms_lob.append(caculate_array, ',');
           end if;
         end if;
         j := j + 1;
       end loop;
       i := i + 1;
     end loop;
   elsif distancetype = 2 then
     i := 1;
     while i < (k + 1) loop
       m     := 1;
       j     := 1;
       temp1 := '(';
       temp2 := '(';
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           temp1 := temp1 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                    ')*ln(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                    ')*cast(1.0 as binary_double)/x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"))';
           temp2 := temp2 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                    ')*cast(1.0 as binary_double)-x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) || '")';
           if countTotal != m then
             temp1 := temp1 || '+';
             temp2 := temp2 || '+';
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             temp1 := temp1 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                      ')*ln(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                      ')*cast(1.0 as binary_double)/alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')))';
             temp2 := temp2 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                      ')*cast(1.0 as binary_double)-alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || m || '))';
             if countTotal != m then
               temp1 := temp1 || '+';
               temp2 := temp2 || '+';
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           temp1 := temp1 || ')';
           temp2 := temp2 || ')';
         end if;
         j := j + 1;
       end loop;
       temp3 := '(' || temp1 || '-' || temp2 || ')';
       if i = k then
         temp3 := temp3 || 'as d' || (i - 1);
       else
         temp3 := temp3 || 'as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp3);
       i := i + 1;
     end loop;
   elsif distancetype = 3 then
     i := 1;
     while i < (k + 1) loop
       m := 1;
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           dbms_lob.append(caculate_array,
                           '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                           ')*log(2.0,(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                           ')*cast(1.0 as binary_double)/x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) || '")))');
           if countTotal != m then
             dbms_lob.append(caculate_array, '+');
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             dbms_lob.append(caculate_array,
                             '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                             ')*log(2.0,(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                             ')*cast(1.0 as binary_double)/alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             '))))');
             if countTotal != m then
               dbms_lob.append(caculate_array, '+');
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           dbms_lob.append(caculate_array, ') as d' || (i - 1));
           if i != k then
             dbms_lob.append(caculate_array, ',');
           end if;
         end if;
         j := j + 1;
       end loop;
       i := i + 1;
     end loop;
   elsif distancetype = 4 then
     i := 1;
     while i < (k + 1) loop
       m := 1;
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           dbms_lob.append(caculate_array,
                           '(abs((x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) ||
                           '"*cast(1.0 as binary_double))-(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                           ')))/abs((x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) ||
                           '"*cast(1.0 as binary_double))+(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                           '))))');
           if countTotal != m then
             dbms_lob.append(caculate_array, '+');
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             dbms_lob.append(caculate_array,
                             '(abs((alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             ')*cast(1.0 as binary_double))-(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                             ')))/abs((alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             ')*cast(1.0 as binary_double))+(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                             '))))');
             if countTotal != m then
               dbms_lob.append(caculate_array, '+');
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           dbms_lob.append(caculate_array, ') as d' || (i - 1));
           if i != k then
             dbms_lob.append(caculate_array, ',');
           end if;
         end if;
         j := j + 1;
       end loop;
       i := i + 1;
     end loop;
   elsif distancetype = 5 then
     i := 1;
     while i < (k + 1) loop
       m := 1;
       j := 1;
       dbms_lob.append(caculate_array, '(');
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           dbms_lob.append(caculate_array,
                           'abs((x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) ||
                           '"*cast(1.0 as binary_double))-(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                           ')))');
           if countTotal != m then
             dbms_lob.append(caculate_array, '+');
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             dbms_lob.append(caculate_array,
                             'abs((alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             ')*cast(1.0 as binary_double))-(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                             ')))');
             if countTotal != m then
               dbms_lob.append(caculate_array, '+');
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           dbms_lob.append(caculate_array, ') as d' || (i - 1));
           if i != k then
             dbms_lob.append(caculate_array, ',');
           end if;
         end if;
         j := j + 1;
       end loop;
       i := i + 1;
     end loop;
   elsif distancetype = 6 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       m     := 1;
       temp1 := '(';
       temp2 := '(';
       temp3 := '(';
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           temp1 := temp1 || '(x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
           temp2 := temp2 || '(x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"*cast(1.0 as binary_double)*x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) || '")';
           temp3 := temp3 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                    ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
           if countTotal != m then
             temp1 := temp1 || '+';
             temp2 := temp2 || '+';
             temp3 := temp3 || '+';
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             temp1 := temp1 || '(alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
             temp2 := temp2 || '(alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l || '))';
             temp3 := temp3 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m ||
                      ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
             if countTotal != m then
               temp1 := temp1 || '+';
               temp2 := temp2 || '+';
               temp3 := temp3 || '+';
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           temp1 := temp1 || ')';
           temp2 := temp2 || ')';
           temp3 := temp3 || ')';
         end if;
         j := j + 1;
       end loop;
       if i = k then
         temp4 := 'acos(case when (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || ')))>1 then 1 when (' || temp1 ||
                  '/(sqrt(' || temp2 || ')*sqrt(' || temp3 ||
                  ')))<-1 then -1 else (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || '))) end ) as d' || (i - 1);
       else
         temp4 := 'acos(case when (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || ')))>1 then 1 when (' || temp1 ||
                  '/(sqrt(' || temp2 || ')*sqrt(' || temp3 ||
                  ')))<-1 then -1 else (' || temp1 || '/(sqrt(' || temp2 ||
                  ')*sqrt(' || temp3 || '))) end ) as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   elsif distancetype = 7 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       m     := 1;
       temp1 := '(';
       temp2 := '(';
       temp3 := '(';
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           temp1 := temp1 || '(x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"*cast(1.0 as binary_double))';
           temp2 := temp2 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
           temp3 := temp3 || '(x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
           if countTotal != m then
             temp1 := temp1 || '+';
             temp2 := temp2 || '+';
             temp3 := temp3 || '+';
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             temp1 := temp1 || '(alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')*cast(1.0 as binary_double))';
             temp2 := temp2 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
             temp3 := temp3 || '(alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
             if countTotal != m then
               temp1 := temp1 || '+';
               temp2 := temp2 || '+';
               temp3 := temp3 || '+';
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           temp1 := temp1 || ')';
           temp2 := temp2 || ')';
           temp3 := temp3 || ')';
         end if;
         j := j + 1;
       end loop;
       if i = k then
         temp4 := '(-2*' || temp3 || '/(' || temp1 || '+' || temp2 ||
                  ')) as d' || (i - 1);
       else
         temp4 := '(-2*' || temp3 || '/(' || temp1 || '+' || temp2 ||
                  ')) as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   elsif distancetype = 8 then
     i := 1;
     while i < (k + 1) loop
       m := 1;
       j := 1;
       dbms_lob.append(caculate_array, '-(');
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           dbms_lob.append(caculate_array,
                           '(x."' ||
                           alpine_miner_get_v2aa_element(column_namearray,
                                                         j) ||
                           '"*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))');
           if countTotal != m then
             dbms_lob.append(caculate_array, '+');
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             dbms_lob.append(caculate_array,
                             '(alpine_miner_get_faa_element(x."' ||
                             alpine_miner_get_v2aa_element(column_namearray,
                                                           j) || '",' || l ||
                             ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))');
             if countTotal != m then
               dbms_lob.append(caculate_array, '+');
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           dbms_lob.append(caculate_array, ') as d' || (i - 1));
           if i != k then
             dbms_lob.append(caculate_array, ',');
           end if;
         end if;
         j := j + 1;
       end loop;
       i := i + 1;
     end loop;
   elsif distancetype = 9 then
     i := 1;
     while i < (k + 1) loop
       j     := 1;
       m     := 1;
       temp1 := '(';
       temp2 := '(';
       temp3 := '(';
       while j < column_number + 1 loop
         if alpine_miner_get_iaa_element(column_array_length_array, j) < 1 then
           temp1 := temp1 || '(x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"*cast(1.0 as binary_double))';
           temp2 := temp2 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
           temp3 := temp3 || '(x."' ||
                    alpine_miner_get_v2aa_element(column_namearray, j) ||
                    '"*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
           if countTotal != m then
             temp1 := temp1 || '+';
             temp2 := temp2 || '+';
             temp3 := temp3 || '+';
           end if;
           m := m + 1;
         else
           l := 1;
           while l <=
                 alpine_miner_get_iaa_element(column_array_length_array, j) loop
             temp1 := temp1 || '(alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')*cast(1.0 as binary_double))';
             temp2 := temp2 || '(alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
             temp3 := temp3 || '(alpine_miner_get_faa_element(x."' ||
                      alpine_miner_get_v2aa_element(column_namearray, j) || '",' || l ||
                      ')*cast(1.0 as binary_double)*alpine_miner_get_faa_element(y."k' || i || '",' || m || '))';
             if countTotal != m then
               temp1 := temp1 || '+';
               temp2 := temp2 || '+';
               temp3 := temp3 || '+';
             end if;
             l := l + 1;
             m := m + 1;
           end loop;
         end if;
         if countTotal + 1 = m then
           temp1 := temp1 || ')';
           temp2 := temp2 || ')';
           temp3 := temp3 || ')';
         end if;
         j := j + 1;
       end loop;
       if i = k then
         temp4 := '(-' || temp3 || '/(' || temp1 || '+' || temp2 || '-' ||
                  temp3 || ')) as d' || (i - 1);
       else
         temp4 := '(-' || temp3 || '/(' || temp1 || '+' || temp2 || '-' ||
                  temp3 || ')) as d' || (i - 1) || ',';
       end if;
       dbms_lob.append(caculate_array, temp4);
       i := i + 1;
     end loop;
   end if;
   return(caculate_array);
 end alpine_miner_kmeans_distance1;
/



CREATE OR REPLACE FUNCTION ALPINE_MINER_KMEANS_C_1_5(table_name               varchar2,
                                                     table_name_withoutschema varchar2,
                                                     column_name              varchar2array,
                                                     column_number            integer,
                                                     id                       varchar2,
                                                     tempid                   varchar2,
                                                     clustername              varchar2,
                                                     k                        integer,
                                                     max_run                  integer,
                                                     max_iter                 integer,
                                                     distance                 integer)
  return floatarray as
  temptablename   varchar2(30);
  executesql      clob := ' ';
  executesql_temp clob := ' ';
  i               integer := 0;
  j               integer := 0;
  column_array    clob := ' ';
  column_all      clob := ' ';
  run             integer := 1;
  none_stable     integer;
  tmp_res_1       varchar2(30);
  tmp_res_2       varchar2(30);
  tmp_res_3       varchar2(30);
  tmp_res_4       varchar2(30);
  avg_array       clob := ' ';
  comp_sql        clob := ' ';
  x_array         clob := ' ';
  result1         varchar2(30);
  sampleid        integer := 0;
  d_array         clob := ' ';
  d_array1        clob := ' ';
  caculate_array  clob := ' ';
  columnname      clob := ' ';
  alpine_id       varchar2(30);
  resultarray     floatarray;
  nullflag        integer := 0;
  tempsum         binary_double;
  tempint         integer := 1;
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  temptablename := table_name_withoutschema;
  executesql    := 'call proc_droptemptableifexists(''' || temptablename ||
                   'copy'')';
  execute immediate executesql;
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  if id = 'null' then
    executesql := 'create table ' || temptablename ||
                  'copy parallel as(select ' || table_name ||
                  '.*,row_number() over (order by 1) ' || tempid ||
                  ' from ' || table_name || ' where ';
    alpine_id  := tempid;
  else
    executesql := 'create table ' || temptablename ||
                  'copy parallel as(select * from ' || table_name ||
                  ' where ';
    alpine_id  := id;
  end if;
  i := 1;
  while i < (column_number) loop
    dbms_lob.append(executesql,
                    ' "' || column_name(i) || '" is not null and ');
    i := i + 1;
  end loop;
  dbms_lob.append(executesql, ' "' || column_name(i) || '" is not null)');
  execute immediate executesql;
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  i := 2;
  while i < (column_number + 1) loop
    column_array := column_array || ',"' || column_name(i) || '"';
    i            := i + 1;
  end loop;
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                '_random_new'')';
  execute immediate executesql;
  executesql := 'select tablek1.seq sample_id,0 as stable,';
  column_all := ' ';
  i          := 1;
  while i < (k + 1) loop
    j := 1;
    while j < (column_number + 1) loop
      dbms_lob.append(column_all,
                      'cast("k' || i || '' || column_name(j) ||
                      '" as binary_double) "k' || i || '' || column_name(j) || '",');
      j := j + 1;
    end loop;
    i := i + 1;
  end loop;
  dbms_lob.append(executesql, column_all || '0 as iter from ');
  i := 1;
  while i < (k + 1) loop
    dbms_lob.append(executesql, '(select ');
    j := 1;
    while j < (column_number + 1) loop
      dbms_lob.append(executesql,
                      '"' || column_name(j) || '" "k' || i ||
                      column_name(j) || '",');
      j := j + 1;
    end loop;
    if i = 1 then
      dbms_lob.append(executesql,
                      ' row_number() over (order by DBMS_RANDOM.VALUE())-1 as seq from (select ' ||
                      temptablename || 'copy.* from ' || temptablename ||
                      'copy order by DBMS_RANDOM.VALUE()) where rownum<' ||
                      max_run || '+1) tablek' || i || ' inner join ');
    else
      if i = k then
        dbms_lob.append(executesql,
                        ' row_number() over (order by DBMS_RANDOM.VALUE())-1 as seq from (select ' ||
                        temptablename || 'copy.* from ' || temptablename ||
                        'copy order by DBMS_RANDOM.VALUE()) where rownum<' ||
                        max_run || '+1) tablek' || i || ' on tablek' ||
                        (i - 1) || '.seq=tablek' || i || '.seq');
      else
        dbms_lob.append(executesql,
                        ' row_number() over (order by DBMS_RANDOM.VALUE())-1 as seq from (select  rownum alpine_no,' ||
                        temptablename || 'copy.* from ' || temptablename ||
                        'copy order by DBMS_RANDOM.VALUE() ) where rownum<' ||
                        max_run || '+1) tablek' || i || ' on tablek' ||
                        (i - 1) || '.seq=tablek' || i || '.seq inner join ');
      end if;
    end if;
    i := i + 1;
  end loop;
  executesql_temp := 'create table ';
  dbms_lob.append(executesql_temp,
                  temptablename || '_random_new parallel as (');
  dbms_lob.append(executesql_temp, executesql);
  dbms_lob.append(executesql_temp, ')');
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  execute immediate executesql_temp;
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  while run <= max_iter loop
    tmp_res_1 := to_char('tmp_res_1' || run);
    tmp_res_2 := to_char('tmp_res_2' || run);
    tmp_res_3 := to_char('tmp_res_3' || run);
    tmp_res_4 := to_char('tmp_res_4' || run);
    i         := 2;
    avg_array := 'trunc(avg("' || column_name(1) || '"),10) "' ||
                 column_name(1) || '"';
    while i < (column_number + 1) loop
      avg_array := avg_array || ',trunc(avg("' || column_name(i) ||
                   '"),10) "' || column_name(i) || '"';
      i         := i + 1;
    end loop;
    i        := 0;
    j        := 0;
    d_array  := 'case ';
    d_array1 := 'case ';
    while i < k - 1 loop
      j        := i + 1;
      d_array  := d_array || ' when d' || i || '<=d' || j;
      d_array1 := d_array1 || ' when d' || i || '<=d' || j;
      j        := j + 1;
      while j < k loop
        d_array  := d_array || ' and d' || i || '<=d' || j;
        d_array1 := d_array1 || ' and d' || i || '<=d' || j;
        j        := j + 1;
      end loop;
      d_array  := d_array || ' then ' || i;
      d_array1 := d_array1 || ' then d' || i;
      i        := i + 1;
    end loop;
    d_array        := d_array || ' else ' || (k - 1) || ' end';
    d_array1       := d_array1 || ' else d' || (k - 1) || ' end';
    caculate_array := '';
    columnname     := 'varchar2array(';
    i              := 1;
    while i < column_number loop
      columnname := columnname || '''' || column_name(i) || ''',';
      i          := i + 1;
    end loop;
    columnname := columnname || '''' || column_name(i) || ''')';
    executesql := 'select alpine_miner_kmeans_distance(' || distance || ',' ||
                  columnname || ',' || column_number || ',' || k ||
                  ') from dual';
    execute immediate executesql
      into caculate_array; /*data_array:='varchar2array('; i:=1; while i<column_number loop data_array:=data_array||'"'||column_name(i)||'",'; i:=i+1; end loop; data_array:=data_array||'"'||column_name(i)||'")';*/
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_2 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'create table ' || temptablename || tmp_res_2 ||
                  ' parallel as (select sample_id,' || alpine_id || ', ' ||
                  d_array || ' as cluster_id from ( select sample_id,' ||
                  alpine_id || ', ' || caculate_array || ' from ' ||
                  temptablename || 'copy x inner join ' || temptablename ||
                  '_random_new y on y.stable=0) foo)';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_1 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'create table ' || temptablename || tmp_res_1 ||
                  ' parallel as ( select sample_id, cluster_id, ' ||
                  avg_array || ' from ' || temptablename || tmp_res_2 ||
                  ' x,' || temptablename || 'copy y where x.' || alpine_id ||
                  '=y.' || alpine_id || ' group by sample_id,cluster_id )';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    comp_sql := '(case when ';
    i        := 1;
    while i < (k + 1) loop
      j := 1;
      while j < column_number + 1 loop
        if i = k and j = column_number then
          comp_sql := comp_sql || 'x."k' || i || column_name(j) || '"=y."k' || i ||
                      column_name(j) || '"';
        else
          comp_sql := comp_sql || 'x."k' || i || column_name(j) || '"=y."k' || i ||
                      column_name(j) || '" and ';
        end if;
        j := j + 1;
      end loop;
      i := i + 1;
    end loop;
    comp_sql   := comp_sql || ' then 1 else 0 end ) as stable';
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_4 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'select tablek1.sample_id,0 as stable,';
    column_all := '';
    i          := 1;
    while i < (k + 1) loop
      j := 1;
      while j < (column_number + 1) loop
        column_all := column_all || '"k' || i || column_name(j) || '",';
        j          := j + 1;
      end loop;
      i := i + 1;
    end loop;
    dbms_lob.append(executesql, column_all || ' 0 as iter from ');
    i := 1;
    while i < (k + 1) loop
      dbms_lob.append(executesql, '(select ');
      j := 1;
      while j < (column_number + 1) loop
        dbms_lob.append(executesql,
                        '"' || column_name(j) || '" "k' || i ||
                        column_name(j) || '",');
        j := j + 1;
      end loop;
      if i = 1 then
        dbms_lob.append(executesql,
                        ' sample_id from ' || temptablename || tmp_res_1 ||
                        ' where cluster_id=' || (i - 1) || ')  tablek' || i ||
                        ' inner join ');
      else
        if i = k then
          dbms_lob.append(executesql,
                          ' sample_id from ' || temptablename || tmp_res_1 ||
                          ' where cluster_id=' || (i - 1) || ')  tablek' || i ||
                          ' on tablek' || (i - 1) || '.sample_id=tablek' || i ||
                          '.sample_id');
        else
          dbms_lob.append(executesql,
                          ' sample_id from ' || temptablename || tmp_res_1 ||
                          ' where cluster_id=' || (i - 1) || ')  tablek' || i ||
                          ' on tablek' || (i - 1) || '.sample_id=tablek' || i ||
                          '.sample_id inner join ');
        end if;
      end if;
      i := i + 1;
    end loop;
    executesql := 'create table ' || temptablename || tmp_res_4 ||
                  ' parallel as (' || executesql || ')';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    x_array := '';
    i       := 1;
    while i < (k + 1) loop
      j := 1;
      while j < (column_number + 1) loop
        x_array := x_array || 'x."k' || i || column_name(j) || '",';
        j       := j + 1;
      end loop;
      i := i + 1;
    end loop;
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_3 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'create table ' || temptablename || tmp_res_3 ||
                  ' parallel as ( select x.sample_id, ' || comp_sql || ',' ||
                  x_array || run || ' as iter from  ' || temptablename ||
                  tmp_res_4 || ' x, ' || temptablename ||
                  '_random_new  y where x.sample_id=y.sample_id  ) ';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    executesql := 'insert into ' || temptablename || tmp_res_3 ||
                  ' (select a.* from ' || temptablename ||
                  '_random_new a left join ' || temptablename || tmp_res_3 ||
                  ' b on a.sample_id=b.sample_id';
    dbms_lob.append(executesql, ' where b.sample_id is null)');
    execute immediate executesql;
    executesql := 'truncate table ' || temptablename || '_random_new';
    execute immediate executesql;
    executesql := 'drop table ' || temptablename || '_random_new';
    execute immediate executesql;
    executesql := 'alter table ' || temptablename || tmp_res_3 ||
                  ' rename to ' || temptablename || '_random_new';
    execute immediate executesql;
    execute immediate 'select count(*)  from  ' || temptablename ||
                      '_random_new where stable=0'
      into none_stable;
    if none_stable = 0 then
      exit;
    end if;
    run := run + 1;
  end loop;
  i := 1;
  while i < (run + 1) loop
    tmp_res_1  := to_char('tmp_res_1' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_1 || ''')';
    execute immediate executesql;
    tmp_res_2  := to_char('tmp_res_2' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_2 || ''')';
    execute immediate executesql;
    tmp_res_3  := to_char('tmp_res_3' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_3 || ''')';
    execute immediate executesql;
    tmp_res_4  := to_char('tmp_res_4' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_4 || ''')';
    execute immediate executesql;
    i := i + 1;
  end loop;
  executesql := 'select floatarray(sample_id,len) from ( select sample_id,len,row_number() over(order by len) as seq from ( select sample_id,avg(len) as len from ( select sample_id,' ||
                alpine_id || ', ' || d_array1 ||
                ' as len from ( select sample_id, ' || alpine_id || ', ' ||
                caculate_array || ' from ' || temptablename ||
                'copy x inner join ' || temptablename ||
                '_random_new y on y.stable=1 )t )a group by sample_id )b )z where seq=1';
  execute immediate 'select count(*) from ' || temptablename ||
                    '_random_new y where y.stable=1'
    into tempint;
  if tempint <> 0 then
    execute immediate executesql
      into resultarray;
    sampleid := resultarray(1);
  else
    execute immediate 'select floatarray(0,0) from dual '
      into resultarray;
  end if;
  if sampleid is null then
    sampleid := 0;
    nullflag := 1;
  end if;
  result1    := 'result1';
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                result1 || ''')';
  execute immediate executesql;
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  execute immediate 'create table ' || temptablename || result1 ||
                    ' parallel as ( select * from  ' || temptablename ||
                    '_random_new  where sample_id =' || sampleid || ' )';
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  if nullflag = 1 then
    executesql := 'select len from ( select sample_id,len,row_number() over(order by len) as seq from ( select sample_id,avg(len) as len from ( select sample_id,' ||
                  alpine_id || ', ' || d_array1 ||
                  ' as len from ( select sample_id, ' || alpine_id || ', ' ||
                  caculate_array || ' from ' || temptablename ||
                  'copy x inner join ' || temptablename ||
                  '_random_new y on y.stable=0 )t )a group by sample_id )b )z where seq=1';
    execute immediate executesql
      into tempsum;
    resultarray(2) := tempsum;
  end if;
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                'result2'')';
  execute immediate executesql;
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  execute immediate 'create table ' || temptablename ||
                    'result2 parallel as select ' || temptablename ||
                    'copy.*,0 ' || temptablename || 'copy_flag from ' ||
                    temptablename || 'copy';
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                'table_name_temp'')';
  execute immediate executesql;
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  executesql := 'select ' || alpine_id || ' as temp_id,' || d_array ||
                ' as ' || clustername || ' from ( select x.' || alpine_id || ',' ||
                caculate_array || ' from ' || temptablename ||
                'result2 x inner join ' || temptablename || result1 ||
                ' y on x.' || temptablename || 'copy_flag=0 ) foo ';
  execute immediate ' create table ' || temptablename ||
                    'table_name_temp parallel as ( ' || executesql || ' )';
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  resultarray(1) := run;
  RETURN resultarray;
end alpine_miner_kmeans_c_1_5;
/

CREATE OR REPLACE FUNCTION ALPINE_MINER_KMEANS_C_1_5_2(table_name                varchar2,
                                                       table_name_withoutschema  varchar2,
                                                       column_namearray          varchar2ArrayArray,
                                                       column_array_length_array integerArrayArray,
                                                       column_number             integer,
                                                       id                        varchar2,
                                                       tempid                    varchar2,
                                                       clustername               varchar2,
                                                       k                         integer,
                                                       max_run                   integer,
                                                       max_iter                  integer,
                                                       distance                  integer)
  return floatarray as
  temptablename   varchar2(30);
  executesql      clob;
  executesql_temp clob;
  i               integer := 0;
  j               integer := 0;
  column_array    clob;
  column_all      clob;
  run             integer := 1;
  none_stable     integer;
  tmp_res_1       varchar2(30);
  tmp_res_2       varchar2(30);
  tmp_res_3       varchar2(30);
  tmp_res_4       varchar2(30);
  comp_sql        clob;
  x_array         clob;
  result1         varchar2(30);
  sampleid        integer := 0;
  d_array         clob;
  d_array1        clob;
  caculate_array  clob;
  alpine_id       varchar2(30);
  resultarray     floatarray;
  nullflag        integer := 0;
  tempsum         binary_double;
  tempint         integer := 1;
  countTotal      integer := 0;
  i_array         integerarray;
  stringlength    integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  for i in 1 .. column_array_length_array.count() loop
    i_array    := column_array_length_array(i);
    countTotal := countTotal + i_array.count();
  end loop;
  temptablename := table_name_withoutschema;
  executesql    := 'call proc_droptemptableifexists(''' || temptablename ||
                   'copy'')';
  execute immediate executesql;
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  if id = 'null' then
    executesql := 'create table ' || temptablename ||
                  'copy parallel as(select ' || table_name ||
                  '.*,row_number() over (order by 1) ' || tempid ||
                  ' from ' || table_name || ' where ';
    alpine_id  := tempid;
  else
    executesql := 'create table ' || temptablename ||
                  'copy parallel as(select * from ' || table_name ||
                  ' where ';
    alpine_id  := id;
  end if;
  i := 1;
  while i < (column_number) loop
    dbms_lob.append(executesql,
                    ' "' ||
                    alpine_miner_get_v2aa_element(column_namearray, i) ||
                    '" is not null and ');
    i := i + 1;
  end loop;
  dbms_lob.append(executesql,
                  ' "' ||
                  alpine_miner_get_v2aa_element(column_namearray, i) ||
                  '" is not null)');
  execute immediate executesql;
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  i := 2;
  while i < (column_number + 1) loop
    column_array := column_array || ',"' ||
                    alpine_miner_get_v2aa_element(column_namearray, i) || '"';
    i            := i + 1;
  end loop;
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                '_random_new'')';
  execute immediate executesql;
  executesql := 'select tablek1.seq sample_id,0 as stable,';
  column_all := '';
  i          := 1;
  while i < (k + 1) loop
    column_all := column_all || ' "k' || i || '",';
    i          := i + 1;
  end loop;
  dbms_lob.append(executesql, column_all || '0 as iter from ');
  i := 1;
  while i < (k + 1) loop
    dbms_lob.append(executesql, '(select ');
    dbms_lob.append(executesql,
                    alpine_miner_v2aa2faa(column_namearray,
                                          column_array_length_array) ||
                    ' "k' || i || '",');
    if i = 1 then
      dbms_lob.append(executesql,
                      ' row_number() over (order by DBMS_RANDOM.VALUE)-1 as seq from (select  rownum alpine_no,' ||
                      temptablename || 'copy.* from ' || temptablename ||
                      'copy order by DBMS_RANDOM.VALUE() ) where rownum<' ||
                      max_run || '+1) tablek' || i || ' inner join ');
    else
      if i = k then
        dbms_lob.append(executesql,
                        ' row_number() over (order by DBMS_RANDOM.VALUE())-1 as seq from (select ' ||
                        temptablename || 'copy.* from ' || temptablename ||
                        'copy order by DBMS_RANDOM.VALUE()) where rownum<' ||
                        max_run || '+1) tablek' || i || ' on tablek' ||
                        (i - 1) || '.seq=tablek' || i || '.seq');
      else
        dbms_lob.append(executesql,
                        ' row_number() over (order by DBMS_RANDOM.VALUE())-1 as seq from (select  rownum alpine_no,' ||
                        temptablename || 'copy.* from ' || temptablename ||
                        'copy order by DBMS_RANDOM.VALUE() ) where rownum<' ||
                        max_run || '+1) tablek' || i || ' on tablek' ||
                        (i - 1) || '.seq=tablek' || i || '.seq inner join ');
      end if;
    end if;
    i := i + 1;
  end loop;
  executesql_temp := 'create table ';
  dbms_lob.append(executesql_temp,
                  temptablename || '_random_new parallel as (');
  dbms_lob.append(executesql_temp, executesql);
  dbms_lob.append(executesql_temp, ')');
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  execute immediate executesql_temp;
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  while run <= max_iter loop
    tmp_res_1 := to_char('tmp_res_1' || run);
    tmp_res_2 := to_char('tmp_res_2' || run);
    tmp_res_3 := to_char('tmp_res_3' || run);
    tmp_res_4 := to_char('tmp_res_4' || run);
    i         := 0;
    j         := 0;
    d_array   := 'case ';
    d_array1  := 'case ';
    while i < k - 1 loop
      j        := i + 1;
      d_array  := d_array || ' when d' || i || '<=d' || j;
      d_array1 := d_array1 || ' when d' || i || '<=d' || j;
      j        := j + 1;
      while j < k loop
        d_array  := d_array || ' and d' || i || '<=d' || j;
        d_array1 := d_array1 || ' and d' || i || '<=d' || j;
        j        := j + 1;
      end loop;
      d_array  := d_array || ' then ' || i;
      d_array1 := d_array1 || ' then d' || i;
      i        := i + 1;
    end loop;
    d_array        := d_array || ' else ' || (k - 1) || ' end';
    d_array1       := d_array1 || ' else d' || (k - 1) || ' end';
    caculate_array := '';
    select alpine_miner_kmeans_distance1(distance,
                                         column_namearray,
                                         column_array_length_array,
                                         column_number,
                                         k)
      into caculate_array
      from dual;
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_2 || ''')';
    execute immediate executesql;
    executesql := 'create table ' || temptablename || tmp_res_2 ||
                  ' parallel as (select sample_id,' || alpine_id || ', ' ||
                  d_array || ' as cluster_id from ( select sample_id,' ||
                  alpine_id || ', ' || caculate_array || ' from ' ||
                  temptablename || 'copy x inner join ' || temptablename ||
                  '_random_new y on y.stable=0) foo)';
    execute immediate executesql;
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_1 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'create table ' || temptablename || tmp_res_1 ||
                  ' parallel as ( select sample_id, cluster_id, ' ||
                  alpine_miner_v2aa2faaavg(column_namearray,
                                           column_array_length_array) ||
                  ' avg from ' || temptablename || tmp_res_2 || ' x,' ||
                  temptablename || 'copy y where x.' || alpine_id || '=y.' ||
                  alpine_id || ' group by sample_id,cluster_id )';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    comp_sql := '(case when ';
    i        := 1;
    while i < (k + 1) loop
      j := 1;
      while j < countTotal + 1 loop
        if i = k and j = column_number then
          comp_sql := comp_sql || 'alpine_miner_get_faa_element(x."k' || i || '",' || j ||
                      ')=alpine_miner_get_faa_element(y."k' || i || '",' || j || ')';
        else
          comp_sql := comp_sql || 'alpine_miner_get_faa_element(x."k' || i || '",' || j ||
                      ')=alpine_miner_get_faa_element(y."k' || i || '",' || j ||
                      ') and ';
        end if;
        j := j + 1;
      end loop;
      i := i + 1;
    end loop;
    comp_sql   := comp_sql || ' then 1 else 0 end ) as stable';
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_4 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'select tablek1.sample_id,0 as stable,';
    i          := 1;
    while i < (k + 1) loop
      dbms_lob.append(executesql, '"k' || i || '",');
      i := i + 1;
    end loop;
    dbms_lob.append(executesql, ' 0 as iter from ');
    i := 1;
    while i < (k + 1) loop
      dbms_lob.append(executesql, '(select avg "k' || i || '",');
      if i = 1 then
        dbms_lob.append(executesql,
                        ' sample_id from ' || temptablename || tmp_res_1 ||
                        ' where cluster_id=' || (i - 1) || ')  tablek' || i ||
                        ' inner join ');
      else
        if i = k then
          dbms_lob.append(executesql,
                          ' sample_id from ' || temptablename || tmp_res_1 ||
                          ' where cluster_id=' || (i - 1) || ')  tablek' || i ||
                          ' on tablek' || (i - 1) || '.sample_id=tablek' || i ||
                          '.sample_id');
        else
          dbms_lob.append(executesql,
                          ' sample_id from ' || temptablename || tmp_res_1 ||
                          ' where cluster_id=' || (i - 1) || ')  tablek' || i ||
                          ' on tablek' || (i - 1) || '.sample_id=tablek' || i ||
                          '.sample_id inner join ');
        end if;
      end if;
      i := i + 1;
    end loop;
    executesql := 'create table ' || temptablename || tmp_res_4 ||
                  ' parallel as (' || executesql || ')';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    x_array := '';
    i       := 1;
    while i < (k + 1) loop
      x_array := x_array || 'x."k' || i || '",';
      i       := i + 1;
    end loop;
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_3 || ''')';
    execute immediate executesql;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    executesql := 'create table ' || temptablename || tmp_res_3 ||
                  ' parallel as ( select x.sample_id, ' || comp_sql || ',' ||
                  x_array || run || ' as iter from  ' || temptablename ||
                  tmp_res_4 || ' x, ' || temptablename ||
                  '_random_new  y where x.sample_id=y.sample_id  ) ';
    execute immediate executesql;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    executesql := 'insert into ' || temptablename || tmp_res_3 ||
                  ' (select a.* from ' || temptablename ||
                  '_random_new a left join ' || temptablename || tmp_res_3 ||
                  ' b on a.sample_id=b.sample_id';
    dbms_lob.append(executesql, ' where b.sample_id is null)');
    execute immediate executesql;
    executesql := 'truncate table ' || temptablename || '_random_new';
    execute immediate executesql;
    executesql := 'drop table ' || temptablename || '_random_new';
    execute immediate executesql;
    executesql := 'alter table ' || temptablename || tmp_res_3 ||
                  ' rename to ' || temptablename || '_random_new';
    execute immediate executesql;
    execute immediate 'select count(*)  from  ' || temptablename ||
                      '_random_new where stable=0'
      into none_stable;
    if none_stable = 0 then
      exit;
    end if;
    run := run + 1;
  end loop;
  
    -----drop temp table start--------------
 i:=1;
 while i < run loop
     tmp_res_1 := to_char('tmp_res_1' || i);
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_1 || ''')';
    execute immediate executesql;
    tmp_res_2 := to_char('tmp_res_2' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_2 || ''')';
    execute immediate executesql;
    tmp_res_3 := to_char('tmp_res_3' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_3 || ''')';
    execute immediate executesql;
    tmp_res_4 := to_char('tmp_res_4' || i);
    executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                  tmp_res_4 || ''')';
    execute immediate executesql;
 i := i + 1;
end loop;
-----drop temp table end--------------

  executesql := 'select floatarray(sample_id,len) from ( select sample_id,len,row_number() over(order by len) as seq from ( select sample_id,avg(len) as len from ( select sample_id,' ||
                alpine_id || ', ' || d_array1 ||
                ' as len from ( select sample_id, ' || alpine_id || ', ' ||
                caculate_array || ' from ' || temptablename ||
                'copy x inner join ' || temptablename ||
                '_random_new y on y.stable=1 )t )a group by sample_id )b )z where seq=1';
  execute immediate 'select count(*) from ' || temptablename ||
                    '_random_new y where y.stable=1'
    into tempint;
  if tempint <> 0 then
    execute immediate executesql
      into resultarray;
    sampleid := resultarray(1);
  else
    execute immediate 'select floatarray(0,0) from dual '
      into resultarray;
  end if;
  if sampleid is null then
    sampleid := 0;
    nullflag := 1;
  end if;
  result1    := 'result1';
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                result1 || ''')';
  execute immediate executesql;
  executesql := 'alter session force parallel dml';
  execute immediate executesql;
  execute immediate 'create table ' || temptablename || result1 ||
                    ' parallel as ( select * from  ' || temptablename ||
                    '_random_new  where sample_id =' || sampleid || ' )';
  if nullflag = 1 then
    executesql := 'select len from ( select sample_id,len,row_number() over(order by len) as seq from ( select sample_id,avg(len) as len from ( select sample_id,' ||
                  alpine_id || ', ' || d_array1 ||
                  ' as len from ( select sample_id, ' || alpine_id || ', ' ||
                  caculate_array || ' from ' || temptablename ||
                  'copy x inner join ' || temptablename ||
                  '_random_new y on y.stable=0 )t )a group by sample_id )b )z where seq=1';
    execute immediate executesql
      into tempsum;
    resultarray(2) := tempsum;
  end if;
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                'result2'')';
  execute immediate executesql;
  execute immediate 'create table ' || temptablename ||
                    'result2 as select ' || temptablename || 'copy.*,0 ' ||
                    temptablename || 'copy_flag from ' || temptablename ||
                    'copy';
  executesql := 'call proc_droptemptableifexists(''' || temptablename ||
                'table_name_temp'')';
  execute immediate executesql;
  executesql := 'select ' || alpine_id || ' as temp_id,' || d_array ||
                ' as ' || clustername || ' from ( select x.' || alpine_id || ',' ||
                caculate_array || ' from ' || temptablename ||
                'result2 x inner join ' || temptablename || result1 ||
                ' y on x.' || temptablename || 'copy_flag=0 ) foo ';
  execute immediate ' create table ' || temptablename ||
                    'table_name_temp parallel as ( ' || executesql || ' )';
  resultarray(1) := run;
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  RETURN resultarray;
end alpine_miner_kmeans_c_1_5_2;
/

create or replace
FUNCTION 
alpine_miner_compute_der( column_count integer,column FloatArray, result_data in out FloatArray ,weight_arg binary_double, y integer,add_intercept_arg integer, pi binary_double)
return FloatArray
as
i int := 1;
foo binary_double := 0;
begin
	foo := weight_arg * (y - pi);
	while (i <= column_count) loop
		result_data(i) := (column(i))*foo;
		i := i + 1;
	end loop;
	if (add_intercept_arg = 1) then
		result_data(column_count + 1) := foo;
	end if;
	return result_data;
end;

/
create or replace FUNCTION 
alpine_miner_compute_hessian(beta_count int ,beta FloatArray, column FloatArray, result_data in out FloatArray
		,weight_arg binary_double, add_intercept_arg integer, pi binary_double)
return floatArray
as
	i int := 1;
	j int := 1;
	ind int := 1;
	x binary_double := 0;
	y binary_double := 0;
begin

	while (i <= beta_count) loop
		if ((i = (beta_count)) and add_intercept_arg = 1) then
			x := 1.0;
		else
			x := (column(i));
		end if;
		j := i;
		while(j <= beta_count) loop
			if ((j = (beta_count)) and add_intercept_arg = 1) then
				y := 1.0;
			else
				y := (column(j));
			end if;
			result_data(ind) := (-x*y*weight_arg*pi*(1.0 - pi));
			ind := ind + 1;
			j := j + 1;
		end loop;
		i := i + 1;
	end loop;
	return result_data;
end;
/

create or replace FUNCTION 
alpine_miner_compute_pi(beta FloatArray, column FloatArray, add_intercept_arg integer)
return binary_double
as
	pi binary_double := 0;
	i int := 1;
	column_count int := column.count();
	beta_count int := beta.count();
	gx binary_double := 0;
	tmp binary_double := 0;
begin

	while (i <= beta_count and i <= column_count) loop
		gx := gx + (beta(i)) * (column(i));
		i := i + 1;
	end loop;
	if add_intercept_arg = 1 then
		gx := gx + (beta(beta_count));
	end if;

	if (gx > 30) then
		tmp := 1.0/2.2204460492503131e-16;
	elsif (gx < -30) then
		tmp := 2.2204460492503131e-16;
	else
		tmp := exp(gx);
	end if;
	pi := tmp/(1.0 + tmp);
	return pi;
end;
/
create or replace FUNCTION 
alpine_miner_compute_xwz(column_count int ,column FloatArray, result_data in out FloatArray
		, weight_arg binary_double,  y integer, add_intercept_arg integer, pi binary_double)
return FloatArray
as
i integer := 1;
eta binary_double := 0;
exp_eta binary_double := 0;
mu_eta_dev binary_double := 0;
foo binary_double := 0;
begin

	eta := ln(pi/(1 - pi));
	exp_eta := pi/(1-pi);
	mu_eta_dev := 0;
	if (eta > 30 or eta < -30) then
		mu_eta_dev := 2.2204460492503131e-16;
	else
		mu_eta_dev := exp_eta/((1+exp_eta)*(1+exp_eta));
	end if;

	foo := weight_arg * pi*(1-pi)*(eta+(y - pi)/mu_eta_dev);
	while (i <= column_count) loop
		result_data(i) := (column(i))*foo;
		i := i + 1;
	end loop;
	if (add_intercept_arg = 1) then
		result_data(column_count + 1) := foo;
	end if;
	return result_data;
end;
/
	
	create or replace FUNCTION alpine_miner_lr_ca_beta(beta_arrayarray floatArrayArray,column_arrayarray floatArrayArray,add_intercept integer, weight binary_double, y int, times int) 
RETURN floatArray
as
  i integer := 1;
	fitness binary_double:= 0.0;
	gx binary_double:= 0.0;
	pi binary_double:= 0.0;
  beta FloatArray ;
  column FloatArray ;
  beta_count integer := 0;
  column_count integer := 0;
  result_count integer := 0;
  result_data FloatArray := FloatArray();
  result_data_xwz FloatArray := FloatArray();
begin
	if (beta_arrayarray is null or column_arrayarray is null or add_intercept is null or weight is null or y is null or times is null) then
		return null;
	end if;
  beta := alpine_miner_faa2fa(beta_arrayarray);
  column := alpine_miner_faa2fa(column_arrayarray);
  beta_count := beta.count();
  column_count := column.count();
	result_count := beta_count *(beta_count+1)/2 + beta_count + 1;
  --DBMS_OUTPUT.PUT_LINE(result_count);
  --DBMS_OUTPUT.PUT_LINE(column_count);

	for i in 1..result_count loop
		result_data.extend();
	end loop;
 	for i in 1..column_count loop
		result_data_xwz.extend();
	end loop;
  if add_intercept = 1 then
    result_data_xwz.extend();
  end if;
	if times = 0 then
		pi := (weight * y + 0.5)/(weight + 1);
	else
		pi := alpine_miner_compute_pi(beta,  column, add_intercept);
	end if;
  --DBMS_OUTPUT.PUT_LINE('pi:'||pi);

	result_data := alpine_miner_compute_hessian(beta_count,beta,column, result_data,weight, add_intercept, pi);
	result_data_xwz := alpine_miner_compute_xwz(column_count,column, result_data_xwz ,weight, y, add_intercept, pi);
  --DBMS_OUTPUT.PUT_LINE('result_data:'||result_data(1));
  --DBMS_OUTPUT.PUT_LINE('result_data_xwz:'||result_data_xwz(1));

  for i in 1..column_count loop
    result_data(i+beta_count *(beta_count+1)/2) := result_data_xwz(i);
  end loop;
  if add_intercept = 1 then
    result_data(column_count + 1 +beta_count *(beta_count+1)/2) := result_data_xwz(column_count + 1);
  end if;
	if (y = 1) then
		fitness := ln(pi);
	else
		fitness := ln(1.0 - pi);
	end if;
	fitness := fitness * weight;
	result_data(result_count) := fitness;
	return result_data;
end;
/
	create or replace FUNCTION alpine_miner_lr_ca_derivative(beta floatArray, column floatArray,add_intercept integer, weight binary_double, y binary_double) return FloatArray
as
i integer := 1;
	gx binary_double := 0.0;
	pi binary_double := 0.0;
	result_data FloatArray := FloatArray();
	result_count int := 0;
beta_count integer := beta.count();
column_count integer := column.count();
begin
	if (beta is null or column is null or add_intercept is null or weight is null or y is null) then
		return null;
	end if;
  result_count := beta_count;

	for i in 1..result_count loop
		result_data.extend();
	end loop;
	pi := alpine_miner_compute_pi(beta,  column, add_intercept);

	result_data := alpine_miner_compute_der(column_count,column, result_data ,weight, y, add_intercept,  pi);
    return result_data;
end;
/
	create or replace FUNCTION alpine_miner_lr_ca_fitness(beta_arrayarray floatArrayArray,column_arrayarray FloatArrayArray,add_intercept integer, weight binary_double, label_value int)
RETURN binary_double
as
        i integer := 1;
	fitness binary_double:= 0.0;
	gx binary_double:= 0.0;
	pi binary_double:= 0.0;

	beta FloatArray;
	column FloatArray; 
	beta_count integer := 0;
	column_count integer := 0;
begin
	if (beta_arrayarray is null or column_arrayarray is null or add_intercept is null or weight is null or label_value is null) then
		return null;
	end if;
	
  	beta := alpine_miner_faa2fa(beta_arrayarray);
	column := alpine_miner_faa2fa(column_arrayarray);
	pi := alpine_miner_compute_pi(beta, column,  add_intercept);

	if (label_value = 1) then
		fitness := ln(pi);
	else
		fitness := ln(1.0 - pi);
	end if;
	fitness := fitness * weight;

	return fitness;
end;
/
	create or replace FUNCTION alpine_miner_lr_ca_he(beta_arrayarray floatArrayArray,column_arrayarray FloatArrayArray,add_intercept integer, weight binary_double) return FloatArray
as
i integer := 1;
	gx binary_double := 0.0;
	pi binary_double := 0.0;
	result_count integer := 0;

	beta FloatArray;
	column FloatArray; 
	beta_count integer := 0;
	column_count integer := 0;
	result FloatArray := FloatArray();
begin
	if (beta_arrayarray is null or column_arrayarray is null or add_intercept is null or weight is null) then
		return null;
	end if;

  	beta := alpine_miner_faa2fa(beta_arrayarray);
	column := alpine_miner_faa2fa(column_arrayarray);
	beta_count := beta.count();
	result_count := beta_count *(beta_count+1)/2;
  for i in 1..result_count loop
    result.extend();
  end loop;
	pi := alpine_miner_compute_pi(beta,  column,  add_intercept);
	result := alpine_miner_compute_hessian(beta_count,beta,column, result
		,weight, add_intercept,  pi);
	return result;
end;
/
	create or replace FUNCTION alpine_miner_lr_ca_he_de(beta_arrayarray floatArrayArray,column_arrayarray FloatArrayArray,add_intercept integer, weight binary_double, y int) 
return floatArray
as
  i integer := 1;
	fitness binary_double:= 0.0;
	gx binary_double:= 0.0;
	pi binary_double:= 0.0;
	beta FloatArray;
	column FloatArray;
	beta_count integer := 0;
	column_count integer := 0;
  result_count integer := 0;
  result_data FloatArray := FloatArray();
  result_data_der FloatArray := FloatArray();
begin
	if (beta_arrayarray is null or column_arrayarray is null or add_intercept is null or weight is null or y is null) then
		return null;
	end if;

  	beta := alpine_miner_faa2fa(beta_arrayarray);
	column := alpine_miner_faa2fa(column_arrayarray);
	beta_count  := beta.count();
	column_count := column.count();
	result_count := beta_count *(beta_count+1)/2 + beta_count + 1;
	for i in 1..result_count loop
		result_data.extend();
	end loop;
  for i in 1..column_count loop
		result_data_der.extend();
	end loop;
  if add_intercept = 1 then
    result_data_der.extend();
  end if;
	pi := alpine_miner_compute_pi(beta,  column, add_intercept);
	result_data := alpine_miner_compute_hessian(beta_count,beta,column, result_data
		,weight, add_intercept,  pi);

	result_data_der := alpine_miner_compute_der(column_count,column, result_data_der
		,weight, y, add_intercept, pi);
  for i in 1..column_count loop
    result_data(i+beta_count *(beta_count+1)/2) := result_data_der(i);
  end loop;
  if add_intercept = 1 then
    result_data(column_count + 1 + beta_count*(beta_count+1)/2) := result_data_der(column_count + 1);
  end if;
	if (y = 1) then
		fitness := ln(pi);
	else
		fitness := ln(1.0 - pi);
	end if;
	fitness := fitness *weight;
	result_data(result_count) := (fitness);
	return result_data;
end;
/
	create or replace FUNCTION alpine_miner_lr_ca_pi(beta_arrayarray floatArrayArray,column_arrayarray FloatArrayArray,add_intercept integer)
RETURN binary_double
as
        i integer := 1;
	fitness binary_double:= 0.0;
	gx binary_double:= 0.0;
	pi binary_double:= 0.0;
	beta FloatArray;
	column FloatArray;

begin
	if (beta_arrayarray is null or column_arrayarray is null or add_intercept is null) then
		return null;
	end if;
  	beta := alpine_miner_faa2fa(beta_arrayarray);
	column := alpine_miner_faa2fa(column_arrayarray);
	pi := alpine_miner_compute_pi(beta,  column, add_intercept);
	return pi;
end;
/


create or replace function alpine_miner_nb_ca_pro( 
nominal_null BOOLEAN , 
numerical_null BOOLEAN,
nominal_columns_arg Varchar2Array,
nominal_mapping_count_arg IntegerArray,
nominal_columns_mapping_arg Varchar2Array,
nominal_columns_pro_arg FloatArray,
dependent_column_mapping_arg Varchar2Array,
dependent_column_pro_arg FloatArray,
numerical_columns_arg FloatArray,
numerical_columns_pro_arg FloatArray
)
return FloatArray
as
  i int := 1;
  j int := 1;
  k int := 1;
  nominal_mapping_index int := 0;
  pro_column_offset int := 0;
  pro_index int := 0;
  mapping_index int := 0;
  NUMERICAL_pro_LENGTH integer := 3;
  max_log_pro binary_double := 0.0;
  diff binary_double := 0.0;
  pro_sum binary_double := 0.0;    
  base binary_double := 0;
  pro FloatArray := FloatArray();
begin
	for i  in  1 .. dependent_column_mapping_arg.count() loop
    pro.extend();
		pro(i) := dependent_column_pro_arg(i);
	end loop;
	if not nominal_null
	then
		for i in 1 .. dependent_column_mapping_arg.count() loop
			pro_column_offset := 0;
			pro_index := 0;
			nominal_mapping_index := 0;
			for j in 1..nominal_columns_arg.count() loop
				pro_index := pro_column_offset + (i - 1)* nominal_mapping_count_arg(j); 
				for k in  1.. nominal_mapping_count_arg(j) loop
					if(nominal_columns_arg(j) = nominal_columns_mapping_arg(nominal_mapping_index + k ))
					then
						pro(i) :=  pro(i) + nominal_columns_pro_arg(pro_index + 1);
						EXIT ; -- when (1 == 1);
					end if;
					pro_index := pro_index + 1;
				end loop;
				pro_column_offset := pro_column_offset + dependent_column_mapping_arg.count() * nominal_mapping_count_arg(j);
				nominal_mapping_index := nominal_mapping_index + nominal_mapping_count_arg(j);
			end loop;
		end loop;
	end if;
  	if (not numerical_null) then
		for i in 1..dependent_column_mapping_arg.count() loop
			for j in 1..numerical_columns_arg.count() loop
				pro_index := NUMERICAL_pro_LENGTH * (j - 1) * dependent_column_mapping_arg.count();
				pro_index := pro_index + NUMERICAL_pro_LENGTH * (i - 1) + 1;
				base := (numerical_columns_arg(j) - numerical_columns_pro_arg(pro_index))
					/numerical_columns_pro_arg(pro_index + 1);
				pro(i) := pro(i) - (numerical_columns_pro_arg(pro_index + 2) + 0.5 * base * base);
			end loop;
		end loop;
	end if;
  
	for i in 1..dependent_column_mapping_arg.count() loop
		if (i = 1 or max_log_pro  < pro(i)) then
			max_log_pro := pro(i);
		end if;
	end loop;

	for i in 1..dependent_column_mapping_arg.count() loop
		diff := pro(i) - max_log_pro;
		if diff < -45 then
			pro(i) := 0.0000001;
		else
			pro(i) := exp(diff);
		end if;
	end loop;
	for i in 1..dependent_column_mapping_arg.count() loop
		pro_sum := pro_sum + pro(i);
	end loop;

	for i in 1 .. dependent_column_mapping_arg.count() loop
		pro(i) := pro(i)/pro_sum;
	end loop; 
	return pro;
end;
/

create or replace function alpine_miner_nb_ca_deviance  (
nominal_columns_aa_arg Varchar2ArrayArray,
nominal_mapping_count_aa_arg IntegerArrayArray,
nominal_columns_mapping_aa_arg Varchar2ArrayArray,
nominal_columns_pro_aa_arg FloatArrayArray,
dependent_column_arg varchar2, 
dependent_column_map_aa_arg Varchar2ArrayArray,
dependent_column_pro_aa_arg FloatArrayArray,
numerical_columns_aa_arg FloatArrayArray,
numerical_columns_pro_aa_arg FloatArrayArray

)
return binary_double
as 
	nominal_null BOOLEAN := true;
	numerical_null BOOLEAN := true;
	pro FloatArray := FloatArray();
  i integer := 1;
  deviance BINARY_DOUBLE := 0.0;
  nominal_columns_arg Varchar2Array;
  nominal_mapping_count_arg IntegerArray;
  nominal_columns_mapping_arg Varchar2Array;
  nominal_columns_pro_arg FloatArray;
  dependent_column_mapping_arg Varchar2Array;
  dependent_column_pro_arg FloatArray;
  numerical_columns_arg FloatArray;
  numerical_columns_pro_arg FloatArray;
begin
	if (dependent_column_arg is null or dependent_column_map_aa_arg is null or dependent_column_pro_aa_arg is null)
	then
		return null;
	end if;

	if(nominal_columns_aa_arg is not null and nominal_mapping_count_aa_arg is not null and nominal_columns_mapping_aa_arg is not null and nominal_columns_pro_aa_arg is not null)
	then
		nominal_null := false;
		nominal_columns_arg := alpine_miner_v2aa2v2a(nominal_columns_aa_arg);
		nominal_mapping_count_arg := alpine_miner_iaa2ia(nominal_mapping_count_aa_arg);
		nominal_columns_mapping_arg := alpine_miner_v2aa2v2a(nominal_columns_mapping_aa_arg);
		nominal_columns_pro_arg := alpine_miner_faa2fa(nominal_columns_pro_aa_arg);
	end if;

	if (numerical_columns_aa_arg is not null and numerical_columns_pro_aa_arg is not null)
	then
		numerical_null := false;
		numerical_columns_arg  := alpine_miner_faa2fa(numerical_columns_aa_arg);
		numerical_columns_pro_arg := alpine_miner_faa2fa(numerical_columns_pro_aa_arg);
	end if;

	dependent_column_mapping_arg := alpine_miner_v2aa2v2a(dependent_column_map_aa_arg);
	dependent_column_pro_arg := alpine_miner_faa2fa(dependent_column_pro_aa_arg);

	pro := alpine_miner_nb_ca_pro(nominal_null, numerical_null, 
        nominal_columns_arg ,
        nominal_mapping_count_arg ,
        nominal_columns_mapping_arg ,
        nominal_columns_pro_arg ,
        dependent_column_mapping_arg ,
        dependent_column_pro_arg ,
        numerical_columns_arg ,
        numerical_columns_pro_arg);

	for i in 1..dependent_column_mapping_arg.count() loop
    	if (dependent_column_arg = dependent_column_mapping_arg(i))
   		then
			deviance := -2.0*ln(pro(i));
			exit;
		end if;
	end loop;
	return deviance;

end;
/

create or replace function alpine_miner_nb_ca_confidence(
nominal_columns_aa_arg Varchar2ArrayArray,
nominal_mapping_count_aa_arg IntegerArrayArray,
nominal_columns_mapping_aa_arg Varchar2ArrayArray,
nominal_columns_pro_aa_arg FloatArrayArray,
dependent_column_map_aa_arg Varchar2ArrayArray,
dependent_column_pro_aa_arg FloatArrayArray,
numerical_columns_aa_arg FloatArrayArray,
numerical_columns_pro_aa_arg FloatArrayArray)
return FloatArray
as 
	pro FloatArray := FloatArray() ;
  nominal_null boolean := true;
	numerical_null boolean := true;
	i integer := 1;
	nominal_columns_arg Varchar2Array;
	nominal_mapping_count_arg IntegerArray;
	nominal_columns_mapping_arg Varchar2Array;
	nominal_columns_pro_arg FloatArray;
	dependent_column_mapping_arg Varchar2Array;
	dependent_column_pro_arg FloatArray;
	numerical_columns_arg FloatArray;
	numerical_columns_pro_arg FloatArray;
begin
	if (dependent_column_map_aa_arg is null or dependent_column_pro_aa_arg is null)
	then
		return null;
	end if;
	if(nominal_columns_aa_arg is not null and nominal_mapping_count_aa_arg is not null and nominal_columns_mapping_aa_arg is not null and nominal_columns_pro_aa_arg is not null) then
		nominal_null := false;
		nominal_columns_arg := alpine_miner_v2aa2v2a(nominal_columns_aa_arg);
		nominal_mapping_count_arg := alpine_miner_iaa2ia(nominal_mapping_count_aa_arg);
		nominal_columns_mapping_arg := alpine_miner_v2aa2v2a(nominal_columns_mapping_aa_arg);
		nominal_columns_pro_arg := alpine_miner_faa2fa(nominal_columns_pro_aa_arg);
	end if;
	if (numerical_columns_aa_arg is not null and  numerical_columns_pro_aa_arg is not null) then
		numerical_null := false;
		numerical_columns_arg  := alpine_miner_faa2fa(numerical_columns_aa_arg);
		numerical_columns_pro_arg := alpine_miner_faa2fa(numerical_columns_pro_aa_arg);
	end if;
	dependent_column_mapping_arg := alpine_miner_v2aa2v2a(dependent_column_map_aa_arg);
	dependent_column_pro_arg := alpine_miner_faa2fa(dependent_column_pro_aa_arg);
	pro := alpine_miner_nb_ca_pro(nominal_null, numerical_null,
        nominal_columns_arg ,
        nominal_mapping_count_arg ,
        nominal_columns_mapping_arg ,
        nominal_columns_pro_arg ,
        dependent_column_mapping_arg ,
        dependent_column_pro_arg ,
        numerical_columns_arg ,
        numerical_columns_pro_arg 
	);
	return pro;
end;
/

create or replace function alpine_miner_nb_ca_prediction(
confidence_column_arg FloatArray, 
dependent_column_map_aa_arg Varchar2ArrayArray) 
return varchar2
as 
    max_log_probability binary_double := 0.0;
    j integer := 1;
    dependent_column_mapping_arg Varchar2Array;
begin
	if (confidence_column_arg is null) then
		return null;
	end if;
	if (dependent_column_map_aa_arg is null) then
		return null;
	end if;
	dependent_column_mapping_arg := alpine_miner_v2aa2v2a(dependent_column_map_aa_arg);

	if (confidence_column_arg.count() != dependent_column_mapping_arg.count() or confidence_column_arg.count() <= 0) then
		return null;
	end if;

	for i in 1 .. confidence_column_arg.count() loop
		if (i = 1 or max_log_probability  < confidence_column_arg(i)) then
			max_log_probability := confidence_column_arg(i);
			j := i;
		end if;
	end loop;
	return dependent_column_mapping_arg(j);
end;
/
create or replace FUNCTION alpine_miner_nn_ca_output(  weight_arg FloatArray,  columns_arg FloatArray,  input_range_arg FloatArray,  input_base_arg FloatArray,  hidden_node_number_arg IntegerArray,  hidden_layer_number_arg integer,  output_range_arg binary_double,  output_base_arg binary_double,  output_node_no_arg integer,  normalize_arg integer ,  numerical_label_arg integer,	all_hidden_node_count in out integer,	input in out FloatArray,  output  in out FloatArray,	hidden_node_output in out FloatArray,  columns_count in out integer,  hidden_node_number_count in out integer,  weight_count in out  integer)
RETURN FloatArray
AS 
  i integer := 1;
	j integer := 1;
	k integer := 1;
 	weight_index integer := 0;
	hidden_node_number_index integer := 0;
  result_count  integer:= 0;
  result_data FloatArray := FloatArray();
begin

	if (weight_arg is null or columns_arg is null or input_range_arg is null or input_base_arg is null or hidden_node_number_arg is null or hidden_layer_number_arg is null or output_range_arg is null or output_base_arg is null or output_node_no_arg is null or normalize_arg is null or numerical_label_arg is null   or 	all_hidden_node_count is null or  input  is null or  output  is null or	hidden_node_output is null or  columns_count is null or  hidden_node_number_count is null or  weight_count is null)
	then
		return null;
	end if;
  columns_count := columns_arg.count();
  hidden_node_number_count := hidden_node_number_arg.count();
  weight_count  := weight_arg.count();
	for i in 1..columns_count loop
		input.extend();
	end loop;

	for i in 1..output_node_no_arg loop
		output.extend();
	end loop;
	all_hidden_node_count := 0;
	for i in 1..hidden_layer_number_arg loop
		all_hidden_node_count := all_hidden_node_count + hidden_node_number_arg(i);
	end loop;

	for i in 1..all_hidden_node_count loop
		hidden_node_output.extend();
	end loop;

	result_count := output_node_no_arg;
	for i in 1..result_count loop
		result_data.extend();
	end loop;

  if (normalize_arg = 1)  then
       i := 1;
       while  i <= columns_count loop
          if ((input_range_arg(i)) != 0) then
              input(i) := (columns_arg(i)-input_base_arg(i))/input_range_arg(i);
          else
              input(i) := columns_arg(i)-input_base_arg(i);
          end if;
          i := i + 1;
        end loop;
  else
      i := 1;
    	while  i <= columns_count loop
         	    input(i) := (columns_arg(i));
         	    i := i + 1;
    	end loop;
	end if;

  i := 1;
  while  i <= hidden_node_number_arg(1)  loop
          hidden_node_output(i) := weight_arg(1+(i-1)*(columns_count + 1));
          j := 1;
          while  j <= columns_count loop
                  hidden_node_output(i) := hidden_node_output(i)+input(j)*weight_arg(1 + j  + (i-1) *(columns_count + 1));
                  j := j + 1;
          end loop;

          if (hidden_node_output(i) < -45.0) then
            hidden_node_output(i) := 0;
          elsif (hidden_node_output(i) > 45.0) then
            hidden_node_output(i) := 1;
          else
            hidden_node_output(i) := (1.0/(1.0+exp( -1.0 * hidden_node_output(i))));
          end if;
          i := i + 1;
  end loop;
  weight_index := hidden_node_number_arg(1) * (columns_count + 1) ;

  if (hidden_layer_number_arg > 1) then
    hidden_node_number_index := 0;
    i := 2;
    while  i <= hidden_layer_number_arg  loop
            hidden_node_number_index := hidden_node_number_index + hidden_node_number_arg(i - 1);
            j := 1;
            while  j <= hidden_node_number_arg(i)  loop
                    hidden_node_output(hidden_node_number_index + j) := weight_arg(weight_index + 1 + (hidden_node_number_arg(i - 1) +1) * (j-1));
                    k := 1;
                    while  k <= hidden_node_number_arg(i - 1)  loop
                            hidden_node_output(hidden_node_number_index + j) := hidden_node_output(hidden_node_number_index + j)+hidden_node_output(hidden_node_number_index - hidden_node_number_arg(i - 1) + k)*weight_arg(weight_index + (hidden_node_number_arg(i - 1) +1) * (j-1) + k + 1);
                            k := k + 1;
                    end loop;
                    if (hidden_node_output(hidden_node_number_index + j) < -45.0) then
                      hidden_node_output(hidden_node_number_index + j) := 0;
                    elsif (hidden_node_output(hidden_node_number_index + j) > 45.0) then
                      hidden_node_output(hidden_node_number_index + j) := 1;
                    else
                      hidden_node_output(hidden_node_number_index + j) := (1.0/(1+exp(-1.0*hidden_node_output(hidden_node_number_index+j))));
                    end if;
                    j := j + 1;
            end loop;
            weight_index := weight_index + hidden_node_number_arg(i) * (hidden_node_number_arg(i - 1) + 1);
            i := i + 1;
   end loop;
  end if;

  i := 1;
  while  i <= output_node_no_arg loop
          output(i) := weight_arg(weight_index + 1 + (hidden_node_number_arg(hidden_layer_number_arg)+1) * (i - 1));
          j := 1;
          while  j <= hidden_node_number_arg(hidden_layer_number_arg)  loop
                  output(i) := output(i)+hidden_node_output(hidden_node_number_index + j) * weight_arg(1 + j + weight_index  + (hidden_node_number_arg(hidden_layer_number_arg)+1) * (i - 1) );
                  j := j + 1;
          end loop;
          if (numerical_label_arg = 1) then
                        output(i) := (output(i) * output_range_arg+output_base_arg);
          else
            if (output(i) < -45.0) then
              output(i) := 0;
            elsif (output(i) > 45.0) then
              output(i) := 1;
            else
              output(i) := (1.0/(1+exp(-1.0*output(i))));
            end if;
          end if;
          i := i + 1;
  end loop;

	for i in 1..output_node_no_arg loop
		result_data(i) := output(i);
	end loop;

  return result_data;
end;
/
create or replace FUNCTION alpine_miner_nn_ca_o(weight_arrayarray_arg FloatArrayArray,  columns_arrayarray_arg FloatArrayArray,  input_range_arrayarray_arg FloatArrayArray,  input_base_arrayarray_arg FloatArrayArray, hidden_node_number_arg IntegerArray, hidden_layer_number_arg integer,  output_range_arg binary_double, output_base_arg binary_double, output_node_no_arg integer, normalize_arg integer , numerical_label_arg integer)
    RETURN floatArray 
    AS 
	all_hidden_node_count integer := 0;
	input FloatArray := FloatArray();
  output FloatArray := FloatArray();
	hidden_node_output FloatArray := FloatArray();
  columns_count integer:= 0;
  hidden_node_number_count integer:= hidden_node_number_arg.count();
  weight_count  integer:= 0;
  result_data FloatArray := FloatArray();
	weight_arg FloatArray;
	columns_arg FloatArray;
	input_range_arg FloatArray;
	input_base_arg FloatArray;
begin
	if (weight_arrayarray_arg is null or columns_arrayarray_arg is null or input_range_arrayarray_arg is null or input_base_arrayarray_arg is null or hidden_node_number_arg is null or hidden_layer_number_arg is null or output_range_arg is null or output_base_arg is null or output_node_no_arg is null or normalize_arg is null or numerical_label_arg is null)
	then
		return null;
	end if;
	weight_arg := alpine_miner_faa2fa(weight_arrayarray_arg);
	columns_arg := alpine_miner_faa2fa(columns_arrayarray_arg);
	input_range_arg := alpine_miner_faa2fa(input_range_arrayarray_arg);
	input_base_arg := alpine_miner_faa2fa(input_base_arrayarray_arg);

  	columns_count := columns_arg.count();
  	weight_count := weight_arg.count();

  result_data := alpine_miner_nn_ca_output(  weight_arg ,  columns_arg ,  input_range_arg ,  input_base_arg ,  hidden_node_number_arg ,  hidden_layer_number_arg ,  output_range_arg ,  output_base_arg ,  output_node_no_arg ,  normalize_arg  ,  numerical_label_arg ,	all_hidden_node_count,	input ,  output ,	hidden_node_output,  columns_count,  hidden_node_number_count,  weight_count);
  return result_data;
end;
/

create or replace FUNCTION alpine_miner_nn_ca_change(  weight_arrayarray_arg FloatArrayArray,  columns_arrayarray_arg FloatArrayArray,  input_range_arrayarray_arg FloatArrayArray,  input_base_arrayarray_arg FloatArrayArray,  hidden_node_number_arg IntegerArray,  hidden_layer_number_arg integer,  output_range_arg binary_double,  output_base_arg binary_double,  output_node_no_arg integer,  normalize_arg integer ,  numerical_label_arg integer,  label_arg binary_double,  set_size_arg int)
RETURN FloatArray
AS 
  i integer := 1;
	j integer := 1;
	k integer := 1;
	all_hidden_node_count integer := 0;

	weight_index integer := 0;
	hidden_node_number_index integer := 0;
	input FloatArray := FloatArray();
  output FloatArray := FloatArray();
	hidden_node_output FloatArray := FloatArray();
  columns_count integer:= 0;
  hidden_node_number_count integer:= hidden_node_number_arg.count();
  weight_count  integer:= 0;
  result_count  integer:= 0;
  result_data FloatArray := FloatArray();
  set_size integer := 0;
  error_sum binary_double := 0.0;
	delta binary_double := 0.0;
	total_error binary_double := 0.0;
	output_error FloatArray := FloatArray();
	direct_output_error binary_double := 0.0;

	hidden_node_error FloatArray := FloatArray();
	current_change binary_double:= 0.0;
	threshold_change binary_double:= 0.0;
	weight_arg FloatArray;
	columns_arg FloatArray;
	input_range_arg FloatArray;
	input_base_arg FloatArray;

begin

	if (weight_arrayarray_arg is null or columns_arrayarray_arg is null or input_range_arrayarray_arg is null or input_base_arrayarray_arg is null or hidden_node_number_arg is null or hidden_layer_number_arg is null or output_range_arg is null or output_base_arg is null or output_node_no_arg is null or normalize_arg is null or numerical_label_arg is null or label_arg is null or set_size_arg is null)
	then
		return null;
	end if;

	weight_arg := alpine_miner_faa2fa(weight_arrayarray_arg);
	columns_arg := alpine_miner_faa2fa(columns_arrayarray_arg);
	input_range_arg := alpine_miner_faa2fa(input_range_arrayarray_arg);
	input_base_arg := alpine_miner_faa2fa(input_base_arrayarray_arg);
  	columns_count := columns_arg.count();
  	weight_count := weight_arg.count();

  output := alpine_miner_nn_ca_output(  weight_arg ,  columns_arg ,  input_range_arg ,  input_base_arg ,  hidden_node_number_arg ,  hidden_layer_number_arg ,  output_range_arg ,  output_base_arg ,  output_node_no_arg ,  normalize_arg  ,  numerical_label_arg ,	all_hidden_node_count,	input ,  output ,	hidden_node_output,  columns_count,  hidden_node_number_count,  weight_count);

	if (set_size_arg <= 0) then
		set_size := 1;
  else
    set_size := set_size_arg;
	end if;

	result_count := weight_count + 1;
	for i in 1..result_count loop
		result_data.extend();
	end loop;

	for i in 1..output_node_no_arg loop
		output_error.extend();
	end loop;
	for i in 1..output_node_no_arg  loop
		if(numerical_label_arg = 1) then
			if (output_range_arg = 0.0) then
				direct_output_error := 0.0;
			else
				direct_output_error := (label_arg - output(i))/output_range_arg;
			end if;
			output_error(i) := direct_output_error;
		else
			if ((label_arg) = (i - 1)) then
				direct_output_error := 1.0 - output(i);
			else
				direct_output_error := 0.0 - output(i);
			end if;
			output_error(i) := direct_output_error * output(i) * (1- output(i));
		end if;
		total_error := total_error + direct_output_error*direct_output_error;
	end loop;

	for i in 1..all_hidden_node_count loop
		hidden_node_error.extend();
	end loop;

	weight_index := weight_count - output_node_no_arg*(hidden_node_number_arg(hidden_layer_number_arg) + 1)  ;
	hidden_node_number_index := all_hidden_node_count - hidden_node_number_arg(hidden_layer_number_arg);
	for i in 1..hidden_node_number_arg(hidden_layer_number_arg)  loop
		error_sum := 0.0;
		for k in 1..output_node_no_arg  loop
			error_sum := error_sum+output_error(k)*weight_arg(weight_index + (hidden_node_number_arg(hidden_layer_number_arg) + 1)*(k - 1) + i + 1);
		end loop;
		hidden_node_error(hidden_node_number_index + i) := error_sum*hidden_node_output(hidden_node_number_index + i)*(1.0-hidden_node_output(hidden_node_number_index + i));
	end loop;

	if (hidden_layer_number_arg > 1) then
		weight_index := weight_index - (hidden_node_number_arg(hidden_layer_number_arg - 1) + 1)*hidden_node_number_arg(hidden_layer_number_arg);
		hidden_node_number_index := hidden_node_number_index - hidden_node_number_arg(hidden_layer_number_arg - 1);
		for i in REVERSE hidden_layer_number_arg - 1..1  loop
			for j in 1..hidden_node_number_arg(i)  loop
				error_sum := 0.0;
				for k in 1..hidden_node_number_arg(i + 1)  loop
					error_sum := error_sum+hidden_node_error(hidden_node_number_index + hidden_node_number_arg(i) + k)*weight_arg(weight_index + (hidden_node_number_arg(i)+1)*(k - 1) + j + 1);
				end loop;
				hidden_node_error(hidden_node_number_index + j) := error_sum*hidden_node_output(hidden_node_number_index + j)*(1-hidden_node_output(hidden_node_number_index + j));
			end loop;
      if (i != 1) then
        weight_index := weight_index - (hidden_node_number_arg(i - 1)+1) * hidden_node_number_arg(i);
        hidden_node_number_index := hidden_node_number_index - hidden_node_number_arg(i - 1);
      else
        weight_index := weight_index - (columns_count+1) * hidden_node_number_arg(i);
        hidden_node_number_index := 0;
      end if;
		end loop;
	end if;

	weight_index := weight_count - (hidden_node_number_arg(hidden_layer_number_arg)+ 1)* output_node_no_arg;
	hidden_node_number_index := all_hidden_node_count - hidden_node_number_arg(hidden_layer_number_arg);

	for i in 1..output_node_no_arg  loop
		delta := 1.0/set_size*output_error(i);
		threshold_change := delta;
		result_data(weight_index + 1 +(hidden_node_number_arg(hidden_layer_number_arg)+ 1)*(i - 1)) := (threshold_change);

		for j in 1..hidden_node_number_arg(hidden_layer_number_arg)  loop
			current_change := delta * hidden_node_output(hidden_node_number_index + j);
			result_data(weight_index +(hidden_node_number_arg(hidden_layer_number_arg)+ 1)*(i - 1) + 1 +j) := (current_change);
		end loop;
	end loop;

	if (hidden_layer_number_arg > 1) then
		for i in reverse hidden_layer_number_arg..2   loop
			weight_index := weight_index - (hidden_node_number_arg(i - 1)+1)*hidden_node_number_arg(i);
			hidden_node_number_index := hidden_node_number_index - hidden_node_number_arg(i - 1);
			delta := 0.0;
			for j in 1..hidden_node_number_arg(i)  loop
				delta := (1.0/set_size*hidden_node_error(hidden_node_number_index + hidden_node_number_arg(i - 1) + j));
				threshold_change := delta;
				result_data(weight_index + 1+ (hidden_node_number_arg(i - 1) + 1) * (j - 1)) := (threshold_change);
				for k in 1..hidden_node_number_arg(i - 1)  loop
					current_change := delta * hidden_node_output(hidden_node_number_index + k);
					result_data(weight_index + (hidden_node_number_arg(i - 1) + 1) * (j - 1) + 1 +  k) := (current_change);
				end loop;
			end loop;
		end loop;
	end if;

	weight_index := 0; 
	hidden_node_number_index := 0;
	delta := 0.0;
	for j in 1..hidden_node_number_arg(1)  loop
		delta := 1.0/set_size*hidden_node_error(hidden_node_number_index + j);
		threshold_change := delta;
		result_data(weight_index + 1 + (columns_count+1)*(j - 1)) := threshold_change;
		for k in 1..columns_count  loop
			current_change := delta*input(k);
			result_data(weight_index +  (columns_count+1)*(j - 1) + k + 1) := (current_change);
		end loop;
	end loop;
	result_data(weight_count + 1) := (total_error);
  return (result_data);
end;
/
create or replace function alpine_miner_initpca(tablename    varchar2,
                                                valueoutname varchar2,
                                                infor        varchar2array,
                                                createway    varchar2,
                                                dropif       varchar2)
  return floatarray is
  columnnumber binary_double;
  rownumber    binary_double;
  i            integer;
  j            integer;
  k            integer;
  numberindex  integer;
  totalindex   integer;
  frequency    integer:=0;
  maxcolumn    integer:=900;
  tempnumber   integer;
  sql1         clob;
  sql4         clob;
  sql2         clob;
  sql3         clob;
  sqltemp      clob;
  sql5        clob;
  lastresult   floatarray := floatarray();
  resultarray       floatarray := floatarray();
  temparray    floatarray:=floatarray();
  notnull      clob;
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  commit;
  
  notnull      := ' where ' || infor(1) || ' is not null ';
  columnnumber := infor.count;
 
  IF dropif = 'yes' THEN
    execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || valueoutname ||
                      ''')';
  END IF;
  sql1 := 'create table ' || valueoutname || '( ' || infor(1) ||
          '  binary_double';
  sql2 := ' ';
  sql3 := ' ';
  for i in 2 .. columnnumber loop
    dbms_lob.append(sql1, ', ' || infor(i) || ' binary_double');
    dbms_lob.append(notnull, ' and ' || infor(i) || ' is not null');
  end loop;
  dbms_lob.append(sql1,
                  ',"alpine_pcadataindex" integer,"alpine_pcaevalue" binary_double,"alpine_pcacumvl" binary_double,"alpine_pcatotalcumvl" binary_double) ');
  execute immediate sql1;
  execute immediate 'select count(*) from ' || tablename || notnull
    into rownumber;
  totalindex := 0;
  tempnumber:=0;
  for i in 1 .. columnnumber loop
    for j in i .. columnnumber loop
        tempnumber:=tempnumber+1;
        totalindex:=totalindex+1; 
         if tempnumber>= maxcolumn
        then
        frequency:=frequency+1;
         dbms_lob.append(sql2, 'sum(' || infor(i) || '*' || infor(j) || ')');      
      temparray.extend();
        sqltemp:='select floatarray(';
        dbms_lob.append(sqltemp,sql2);
         dbms_lob.append(sqltemp,') from ');
         dbms_lob.append(sqltemp,tablename);
         dbms_lob.append(sqltemp,notnull);
     execute immediate sqltemp into temparray;
            for k in 1..tempnumber loop
             resultarray.extend();
               resultarray((frequency-1)*maxcolumn+k):=temparray(k);
           end loop;
           sql2:=' ';
           if totalindex!=(columnnumber+1)*columnnumber/2
           then tempnumber:=0;
           end if;
          else   
          if totalindex=(columnnumber+1)*columnnumber/2
          then 
          dbms_lob.append(sql2, 'sum(' || infor(i) || '*' || infor(j) || ')');
          else   
          dbms_lob.append(sql2, 'sum(' || infor(i) || '*' || infor(j) || '),');
           end if;
         end if;
       if i = columnnumber and j = columnnumber then
        dbms_lob.append(sql3, 'avg(' || infor(i) || ')');
      else
        if j = columnnumber then
          dbms_lob.append(sql3, 'avg(' || infor(i) || '),');
          
        end if;
      end if;
    end loop;
  end loop;
   if tempnumber != 0 
  then
   sql4:='select floatarray(';
  dbms_lob.append(sql4,sql2);
   dbms_lob.append(sql4,') from ');
   dbms_lob.append(sql4,tablename);
   dbms_lob.append(sql4,notnull);
  execute immediate sql4
    into temparray;
    
     for k in 1..tempnumber loop
             resultarray.extend();
                resultarray((frequency)*maxcolumn+k):=temparray(k);
           end loop;
           end if;
         
           
           
     execute immediate 'select floatarray(' || sql3  || ') from ' ||
                    tablename || notnull
    into temparray;
    j:=(frequency)*maxcolumn+tempnumber;
    for  i in 1.. columnnumber loop
         resultarray.extend();
          resultarray(j+i):=temparray(i);
      end loop;
    commit;
  numberindex := 0;
  IF createway = 'cov-sam' THEN
    for i in 1 .. columnnumber loop
      for j in i .. columnnumber loop
        numberindex := numberindex + 1;
        lastresult.extend;
        lastresult(numberindex) := (resultarray(numberindex) -
                                   rownumber * resultarray(totalindex + i) *
                                   resultarray(totalindex + j)) /
                                   (rownumber - 1);
      end loop;
    end loop;
    RETURN lastresult;
  else
    IF createway = 'cov-pop' THEN
      for i in 1 .. columnnumber loop
        for j in i .. columnnumber loop
          numberindex := numberindex + 1;
          lastresult.extend;
          lastresult(numberindex) := (resultarray(numberindex) -
                                     rownumber * resultarray(totalindex + i) *
                                     resultarray(totalindex + j)) / (rownumber);
        end loop;
      end loop;
        RETURN lastresult;
     else
      IF createway = 'corr' THEN
        for i in 1 .. columnnumber loop
          for j in i .. columnnumber loop
            numberindex := numberindex + 1;
            lastresult.extend;
            lastresult(numberindex) := (resultarray(numberindex) -
                                       rownumber * resultarray(totalindex + i) *
                                       resultarray(totalindex + j)) /
                                       (sqrt(resultarray((2 * columnnumber + 2 - i) *
                                                    (i - 1) / 2 + 1) -
                                             rownumber *
                                             resultarray(totalindex + i) *
                                             resultarray(totalindex + i)) *
                                       sqrt(resultarray((2 * columnnumber + 2 - j) *
                                                    (j - 1) / 2 + 1) -
                                             rownumber *
                                             resultarray(totalindex + j) *
                                             resultarray(totalindex + j)));
          end loop;
        end loop;
          RETURN lastresult;
      end if;
    end if;
  end if;
END alpine_miner_initpca;

/

CREATE OR REPLACE FUNCTION ALPINE_MINER_PCARESULT(tablename    varchar2,
                                                  infor        varchar2array,
                                                  outtablename varchar2,
                                                  remainname   varchar2array,
                                                  valuename    varchar2,
                                                  pcanumber    integer,
                                                  dropif       varchar2)
  RETURN integer AS
  columnnumber integer;
  i            integer;
  j            integer;
  remainnumber integer;
  PRAGMA AUTONOMOUS_TRANSACTION;
  totalsql  clob;
  sumsql    clob;
  remainsql clob;
  tempvalue binary_double;
BEGIN
  commit;
  execute immediate 'alter session force parallel dml';
  if remainname is not null then
    remainnumber := remainname.count;
    remainsql    := ' ';
    for i in 1 .. remainnumber loop
      dbms_lob.append(remainsql, ',' || remainname(i));
    end loop;
  else
    remainsql := ' ';
  end if;
  columnnumber := infor.count;
  IF dropif = 'yes' THEN
    execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || outtablename ||
                      ''')';
  END IF;
  totalsql := 'create table    ' || outtablename || ' parallel as select';
  i        := 1;
  sumsql   := ' ';
  while i <= pcanumber loop
    execute immediate '(select ' || infor(1) || ' from ' || valuename ||
                      ' where  ' || valuename || '."alpine_pcadataindex"=' ||
                      (i - 1) || ')'
      into tempvalue;
    dbms_lob.append(sumsql,
                    ' ' || tablename || '.' || infor(1) || '* (' ||
                    tempvalue || ')');
    j := 2;
    while j <= columnnumber loop
      execute immediate '(select ' || infor(j) || ' from ' || valuename ||
                        ' where  ' || valuename ||
                        '."alpine_pcadataindex"=' || (i - 1) || ')'
        into tempvalue;
      dbms_lob.append(sumsql,
                      '+ ' || tablename || '.' || infor(j) || '*(' ||
                      tempvalue || ')');
      j := j + 1;
    end loop;
    IF i = pcanumber then
      dbms_lob.append(sumsql, '   "attribute' || i || '"');
    ELSE
      dbms_lob.append(sumsql, '   "attribute' || i || '" ,');
    END IF;
    i := i + 1;
  end loop;
  dbms_lob.append(totalsql, sumsql);
  dbms_lob.append(totalsql, remainsql);
  dbms_lob.append(totalsql, ' from ' || tablename);
  execute immediate totalsql;
  execute immediate 'alter session disable parallel dml';
  commit;
  RETURN i;
END ALPINE_MINER_PCARESULT;

/
create or replace function alpine_array_count(dataarray integerarray)
return integer is
length integer;
begin
      length:=dataarray.count();
return length;
end alpine_array_count;


/



create or replace TYPE plda_assign_topics AS object(
       assign IntegerArray,
       topic_count IntegerArray
);
/
create or replace TYPE plda_sum AS object(
       assign IntegerArray,
       topic_count IntegerArray,
       content IntegerArray,
       wordnumber integer,
       topicnumber integer,
       length     integer
);

/

create or replace type pldaSumImpl as object
(
  varraysum plda_sum,
  static function ODCIAggregateInitialize(fs IN OUT pldaSumImpl) 
    return number,
  member function ODCIAggregateIterate(self IN OUT pldaSumImpl, 
    value IN plda_sum ) return number,
  member function ODCIAggregateTerminate(self IN pldaSumImpl, 
    returnValue OUT plda_sum, flags IN number) return number,
  member function ODCIAggregateMerge(self IN OUT pldaSumImpl, 
    fs2 IN pldaSumImpl) return number
);
/ 
	  
create or replace type body pldaSumImpl is
static function ODCIAggregateInitialize(fs IN OUT pldaSumImpl)
return number is
arraysum plda_sum := plda_sum(integerarray(),integerarray(),integerarray(),0,0,0);
begin
  fs := pldaSumImpl(plda_sum(integerarray(),integerarray(),integerarray(),0,0,0));

  fs.varraysum := (arraysum);
  return ODCIConst.Success;
end;

member function ODCIAggregateIterate(self IN OUT pldaSumImpl,
    value IN plda_sum ) return number is
i integer := 0;
begin

  if self.varraysum.assign.count() = 0 then
    self.varraysum.assign.extend();
    self.varraysum.assign(1):=0;
    self.varraysum.assign.extend((value.wordnumber*value.topicnumber-1),1);
    self.varraysum.topic_count.extend();
    self.varraysum.topic_count(1):=0;
    self.varraysum.topic_count.extend((value.topicnumber-1),1);
  end if;
  for i in 1..value.content.count() loop
    self.varraysum.assign((value.content(i)-1)*value.topicnumber+value.assign(i)):=
    self.varraysum.assign((value.content(i)-1)*value.topicnumber+value.assign(i))+1;
    self.varraysum.topic_count(value.assign(i)):=self.varraysum.topic_count(value.assign(i))+1;
  end loop;
  return ODCIConst.Success;
end;

member function ODCIAggregateTerminate(self IN pldaSumImpl,
    returnValue OUT plda_sum, flags IN number)
return number is
begin
  returnValue := self.varraysum;
  return ODCIConst.Success;
end;

member function ODCIAggregateMerge(self IN OUT pldaSumImpl, fs2 IN pldaSumImpl)
return number is
i integer :=0;
mincount integer := 0;
begin
   if self.varraysum.assign.count() < fs2.varraysum.assign.count() then

    for i in 1..self.varraysum.assign.count() loop
      self.varraysum.assign(i) := self.varraysum.assign(i) + fs2.varraysum.assign(i);
    end loop;
    for i in 1..self.varraysum.topic_count.count() loop
      self.varraysum.topic_count(i) := self.varraysum.topic_count(i) + fs2.varraysum.topic_count(i);
    end loop;
     for i in (self.varraysum.assign.count() + 1) .. fs2.varraysum.assign.count() loop
         self.varraysum.assign.extend();
        self.varraysum.assign(i) :=   fs2.varraysum.assign(i);
    end loop;
      for i in (self.varraysum.topic_count.count() + 1) .. fs2.varraysum.topic_count.count() loop
         self.varraysum.topic_count.extend();
        self.varraysum.topic_count(i) :=   fs2.varraysum.topic_count(i);
    end loop;
   
    else 
     for i in 1..self.varraysum.assign.count() loop
      self.varraysum.assign(i) := self.varraysum.assign(i) + fs2.varraysum.assign(i);
    end loop;
    for i in 1..self.varraysum.topic_count.count() loop
      self.varraysum.topic_count(i) := self.varraysum.topic_count(i) + fs2.varraysum.topic_count(i);
    end loop;
end if;
  return ODCIConst.Success;
end;
 end ;

/

CREATE OR REPLACE TYPE AlpinePldaTableType
  AS TABLE OF integer;


/

  create or replace function generate_series(p_start in pls_integer,
                           p_end   in pls_integer,
                           p_step  in pls_integer := 1 )
       Return AlpinePldaTableType  Pipelined
  As
    v_i    integer := CASE WHEN p_start IS NULL THEN 1 ELSE p_start END;
    v_step integer := CASE WHEN p_step IS NULL OR p_step = 0 THEN 1 ELSE p_step END;
    v_terminating_value PLS_INTEGER :=  p_start + TRUNC(ABS(p_start-p_end) / abs(v_step) ) * v_step;
  Begin
     -- Check for impossible combinations
     If ( p_start > p_end AND SIGN(p_step) = 1 )
        Or
        ( p_start < p_end AND SIGN(p_step) = -1 ) Then
       Return;
     End If;
     -- Generate integers
     LOOP
       PIPE ROW ( v_i );
       EXIT WHEN ( v_i = v_terminating_value );
       v_i := v_i + v_step;
     End Loop;
     Return;
  End generate_series;

  /

 
 
 CREATE OR REPLACE FUNCTION alpine_plda_word_topic( arr integerarray, topicnumber integer,   wordnumber integer  )
  RETURN  integerarray is
  i integer; 
  resultarray integerarray:= integerarray();
 begin
      for i in 1..topicnumber loop
          resultarray.extend();
          resultarray(i):=arr((wordnumber-1)*topicnumber + i);
          end loop; 

       return resultarray;
end alpine_plda_word_topic;

/


create or replace
FUNCTION pldaSum (input plda_sum ) RETURN plda_sum 
 PARALLEL_ENABLE  AGGREGATE USING pldaSumImpl;
/
 
 

CREATE OR REPLACE FUNCTION alpine_miner_plda_first(columnsize integer,topicnumber integer)
  RETURN plda_assign_topics is
  tempnumber  integer;
  randomdata  integer;
  result plda_assign_topics := plda_assign_topics(IntegerArray(),IntegerArray());
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
   for tempnumber in 1..topicnumber loop
       result.topic_count.extend();
       result.topic_count(tempnumber):=0;
   end loop;


 for tempnumber in 1..columnsize loop
    result.assign.extend();
 
    randomdata:=trunc(dbms_random.value(1, (topicnumber+1)));
    result.assign(tempnumber):=randomdata;
    result.topic_count(randomdata):=result.topic_count(randomdata)+1;
  end loop;
  commit;
  RETURN(result);
END alpine_miner_plda_first;
/
CREATE OR REPLACE FUNCTION alpine_miner_plda_gene(doccontent IntegerArray,
																									alldoctopic IntegerArray,
																									wordtopic IntegerArray,
																									assign    IntegerArray,
																									topiccount IntegerArray,
																									alpha     binary_double,
																									beta      binary_double,
																									wordnumber integer,
																									topicnumber integer  )
  RETURN plda_assign_topics is
  tempnumber  integer;
 
  column_size integer;
  temptopic		integer;
  singledoctopic integer;
  temp_glwordtopic integer;
  k						integer;
  total_unpr binary_double;
  cl_prob   binary_double;
  j          integer;
	ret					integer;
	r				binary_double;
 
	topic_prs floatarray:=floatarray();
  result plda_assign_topics := plda_assign_topics(IntegerArray(),IntegerArray());
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN


   for tempnumber in 1..topicnumber loop
       result.topic_count.extend();
       result.topic_count(tempnumber):=0;
   end loop;
   column_size:=doccontent.count();
		for   k in 1.. column_size	loop
     total_unpr := 0;
     for j in 1.. topicnumber loop

		temp_glwordtopic :=  wordtopic((doccontent(k)-1) * topicnumber + j);
		singledoctopic := topiccount(j);
		if  j =   assign(k)
		then
		 temp_glwordtopic:=temp_glwordtopic-1;
		 singledoctopic:=singledoctopic-1;
		end if;
	  cl_prob := (singledoctopic + alpha) * (temp_glwordtopic + beta) /
			  (alldoctopic(j) + wordnumber * beta);
		total_unpr := total_unpr+cl_prob;
    topic_prs.extend();
		topic_prs(j) := total_unpr;
	end loop;
	for j in 1..topicnumber loop
		topic_prs(j) := topic_prs(j) / total_unpr;
	end loop;
	    r:= dbms_random.value(0,1);
   
	ret := 1;
  	while r > topic_prs(ret) and ret<topicnumber  loop
		      ret:=ret+1;
    end loop;
    temptopic:=ret;
    result.assign.extend();
		result.assign(k):=temptopic;
    result.topic_count(temptopic):=result.topic_count(temptopic)+1;
		end loop;
 
  RETURN(result);
END alpine_miner_plda_gene;


/

CREATE OR REPLACE FUNCTION alpine_miner_plda_train(
content_table varchar2 ,
  docidcolumn varchar2,
  doccontentcolumn varchar2,
  alpha binary_double ,
  beta binary_double ,
  topicnumber integer ,
  dictable varchar2,
  diccontentcolumn varchar2,
  iteration_number integer ,
  tempouttable varchar2,
  tempouttable1 varchar2,
  outtable varchar2,
  doctopictable varchar2,
  topicouttable varchar2)
  RETURN integer is
  tempiteration integer:=1;
  sqlan clob;

   wordtopic IntegerArray:=IntegerArray();--each word counts in every topic
  alldoctopic  IntegerArray:=IntegerArray();--counts for each topic
  temprecord plda_sum:=plda_sum(integerarray(),integerarray(),integerarray(),0,0,0);
  TYPE crt IS REF CURSOR;
  wordtopiclob clob;
  alldoctopiclob clob;
  executesql varchar2(4000);
  myrecord crt;
   diccontent varchar2array:=varchar2array();
   geneoutputtable varchar2(4000);
   geneinputtable  varchar2(4000);
  wordnumber integer;
    PRAGMA AUTONOMOUS_TRANSACTION;
begin
commit;
 
  
  sqlan:= 'select  '||diccontentcolumn||' as content from '||dictable||' ';
 open myrecord for sqlan;
  loop
   FETCH myrecord INTO diccontent;
  EXIT WHEN myrecord%NOTFOUND;
   end loop;
  wordnumber:=diccontent.count();

    commit;
  
     executesql := 'alter session force parallel dml';
   execute immediate executesql;
  execute  immediate   'create  table '||tempouttable||' parallel as ( select 1 as alpinepldagenera , '||docidcolumn||' , '|| doccontentcolumn||' ,
  alpine_miner_plda_first( alpine_array_count('|| doccontentcolumn||'),'||topicnumber||') as alpinepldainfo from '||content_table||' ) ';
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
  execute  immediate   'create  table '||tempouttable1||' parallel as (select * from '||tempouttable||' where 1=0 )' ;

   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
  
  commit;

   
  sqlan := 'select pldaSum(plda_sum((alpinepldainfo).assign,(alpinepldainfo).topic_count,'|| doccontentcolumn||','||wordnumber||','||topicnumber||',alpine_array_count('|| doccontentcolumn||'))) as wordtopic from '|| tempouttable||' where '||docidcolumn||' is not null and '|| doccontentcolumn||' is not null ';
   commit;
 

  open myrecord for sqlan;
  loop
   FETCH myrecord INTO temprecord;
  EXIT WHEN myrecord%NOTFOUND;
   end loop;
 
 
   alldoctopic.extend(wordnumber*topicnumber);
   wordtopic.extend(topicnumber);
     wordtopic :=temprecord.assign;
     alldoctopic :=temprecord.topic_count;

    geneoutputtable:=tempouttable;
    geneinputtable:=tempouttable1;
  for tempiteration in 2.. iteration_number loop
 

 
    if mod(tempiteration,2) = 0
    then
      geneoutputtable:=tempouttable1;
      geneinputtable:=tempouttable;
    else
      geneoutputtable:=tempouttable;
      geneinputtable:=tempouttable1;

    end if;

 
    executesql := 'alter session force parallel dml';
       execute immediate executesql;
       commit;
    execute  immediate ' TRUNCATE TABLE '||geneoutputtable;
      executesql := 'alter session disable parallel dml';
  execute immediate executesql;
     commit;
   
 
  
  wordtopiclob:=alpine_iarray_to_clob(wordtopic,',');
  alldoctopiclob:=alpine_iarray_to_clob(alldoctopic,',');
     sqlan:=' ';
 
     dbms_lob.append(sqlan,'insert into ');
     dbms_lob.append(sqlan,geneoutputtable);
     dbms_lob.append(sqlan, '    ( select ');
     dbms_lob.append(sqlan, to_char(tempiteration));
     dbms_lob.append(sqlan, ' as alpinepldagenera,');
     dbms_lob.append(sqlan, docidcolumn);
     dbms_lob.append(sqlan, ',');
     dbms_lob.append(sqlan, doccontentcolumn);
     dbms_lob.append(sqlan, ',alpine_miner_plda_gene(');
     dbms_lob.append(sqlan, doccontentcolumn);
     dbms_lob.append(sqlan, ',integerarray(');
     dbms_lob.append(sqlan, alldoctopiclob);
     dbms_lob.append(sqlan, '),integerarray(');
     dbms_lob.append(sqlan, wordtopiclob);
     dbms_lob.append(sqlan, '),(alpinepldainfo).assign,(alpinepldainfo).topic_count,');
     dbms_lob.append(sqlan, to_char(alpha));
     dbms_lob.append(sqlan, ',');
     dbms_lob.append(sqlan, to_char(beta));
     dbms_lob.append(sqlan, ',');
     dbms_lob.append(sqlan, to_char(wordnumber));
     dbms_lob.append(sqlan, ',');
     dbms_lob.append(sqlan,to_char(topicnumber));
     dbms_lob.append(sqlan, ') as  alpinepldainfo  from ');
     dbms_lob.append(sqlan,geneinputtable);
     dbms_lob.append(sqlan, ') ');
 
 
 
  executesql := 'alter session force parallel dml';
     execute immediate executesql;
 execute  immediate sqlan;
 commit;
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
   commit;
  
 
  executesql := 'alter session force parallel dml';
    execute immediate executesql;
     commit;
      sqlan := 'select pldaSum(plda_sum((alpinepldainfo).assign,(alpinepldainfo).topic_count,'|| doccontentcolumn||','||wordnumber||','||topicnumber||',alpine_array_count('|| doccontentcolumn||'))) as wordtopic from '|| geneoutputtable||' where '||docidcolumn||' is not null and '|| doccontentcolumn||' is not null ';
    open myrecord for sqlan;
  loop
   FETCH myrecord INTO temprecord;
  EXIT WHEN myrecord%NOTFOUND;
   end loop;
  
       wordtopic:=temprecord.assign;
     alldoctopic:=temprecord.topic_count;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
    commit;
  end loop;
 

   executesql := 'alter session force parallel dml';
  execute immediate executesql;
  execute  immediate 'create table '||outtable||'  parallel  as   select '||docidcolumn||'  , '|| doccontentcolumn||' ,   (alpinepldainfo).assign as assign from '|| geneoutputtable||' where alpinepldagenera = '||iteration_number||'  ';
  execute  immediate 'create table '||doctopictable||'  parallel  as  select '||docidcolumn||'  , '|| doccontentcolumn||' ,  (alpinepldainfo).topic_count as topic_count  from '|| geneoutputtable||' where alpinepldagenera = '||iteration_number||'  ';
 wordtopiclob:=alpine_iarray_to_clob(wordtopic,',');
   sqlan:='CREATE  TABLE '||topicouttable||'  parallel  as  select alpine_miner_get_v2a_element(diccontent,i) word, alpine_plda_word_topic(integerarray('||wordtopiclob||'),'||topicnumber||', i) topic
     from  (select '||diccontentcolumn||' as diccontent from '||dictable||' where rownum=1   ) ,  (select column_value i  from Table(generate_series(1,'||wordnumber||')))  ';
 
  execute  immediate sqlan;

  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
commit;
RETURN 1;

END alpine_miner_plda_train;


/

CREATE OR REPLACE FUNCTION alpine_miner_plda_row(doc integerarray, gtopic_count integerarray, wordtopic integerarray, topicnumber integer, wordnumber integer, alpha binary_double, beta binary_double, iteraternumber integer)
  RETURN  plda_assign_topics is
 
    result plda_assign_topics;
BEGIN
    result := alpine_miner_plda_first(doc.count(), topicnumber);
    FOR i in 1..iteraternumber LOOP
        result := alpine_miner_plda_gene(doc,gtopic_count,wordtopic,result.assign, result.topic_count,alpha,beta,wordnumber,topicnumber);
        END LOOP;
    RETURN (result);
END alpine_miner_plda_row;


/




CREATE OR REPLACE FUNCTION alpine_miner_plda_predict(modeltable varchar2,
                                                content_table varchar2,
                                                docidcolumn varchar2,
                                                doccontentcolumn varchar2,
                                                alpha binary_double,
                                                beta binary_double,
                                                topicnumber binary_double,
                                                iteration_number integer,
                                                dictable varchar2,
                                                diccontentcolumn varchar2,
                                                temptable varchar2,
                                                docouttable varchar2,
                                                doctopictable varchar2)
  RETURN  integer is
 
  i binary_double;
  
 
  wordnumber binary_double;
  tempnumber binary_double:=0;
 
  sqlan clob;
   TYPE crt IS REF CURSOR;
  wordtopiclob clob;
  alldoctopiclob clob;
  executesql varchar2(4000);
  myrecord crt;
  wordtopic integerarray:=integerarray();--each word counts in every topic
  alldoctopic  integerarray:=integerarray();--counts for each topic
  
    assigninfo integerarray:=integerarray();
  doccontent integerarray:=integerarray();
  diccontent varchar2array:=varchar2array();
 
   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

  sqlan := 'select  ' || diccontentcolumn || ' as content from ' ||
           dictable || ' where rownum=1 ';
  open myrecord for sqlan;
  loop
    FETCH myrecord
      INTO diccontent;
    EXIT WHEN myrecord%NOTFOUND;
  end loop;
  wordnumber := diccontent.count();
  wordtopic.extend();
  wordtopic(1):=0;
    wordtopic.extend(wordnumber*topicnumber-1,1);
    alldoctopic.extend();
    alldoctopic(1):=0;
   alldoctopic.extend(topicnumber-1,1);
    sqlan := 'select ' || docidcolumn || ' as alpineid,' || doccontentcolumn ||
           ' as alpinecontent, assign from ' || modeltable || ' ';
  open myrecord for sqlan;
  loop
    FETCH myrecord
      INTO i, doccontent, assigninfo;
    EXIT WHEN myrecord%NOTFOUND;
    for tempnumber in 1 .. assigninfo.count() loop
      alldoctopic(assigninfo(tempnumber)) := alldoctopic(assigninfo(tempnumber)) + 1;
      wordtopic(topicnumber * (doccontent(tempnumber) - 1) + assigninfo(tempnumber)) := wordtopic(topicnumber *
                                                                                                 (doccontent(tempnumber) - 1) +
                                                                                                 assigninfo(tempnumber)) + 1;
    end loop;
  end loop;
    
 
 wordtopiclob:=alpine_iarray_to_clob(wordtopic,',');
  alldoctopiclob:=alpine_iarray_to_clob(alldoctopic,',');
  commit;
   executesql := 'alter session force parallel ddl';
   execute immediate executesql;
  
 execute immediate 'create   table '||temptable ||' parallel as select '||docidcolumn||' ,'|| doccontentcolumn||',alpine_miner_plda_row('||doccontentcolumn||',integerarray('||alldoctopiclob||')
    ,integerarray('||wordtopiclob||'),'|| topicnumber||','||wordnumber||','||alpha||','||beta||','||iteration_number||') as alpinepldainfo  from '||content_table||' where '||docidcolumn||' is not null and '|| doccontentcolumn||' is not null   ';
  execute immediate 'CREATE  TABLE '||docouttable||' parallel as select  '||docidcolumn||'  , '|| doccontentcolumn||' ,  (alpinepldainfo).assign as alpinepldaassign  from '||temptable||'   ';
  execute immediate  ' create table '||doctopictable|| ' parallel  as select '||docidcolumn||'  , '|| doccontentcolumn||' ,  (alpinepldainfo).topic_count as alpinepldatopic  from  '||temptable||'   ';
  executesql := 'alter session disable parallel dml';
  execute immediate executesql;
  commit;




RETURN 1;

END alpine_miner_plda_predict;


/



create or replace procedure proc_droptableifexists(tablename varchar2) is
  v_count    number(10);
  executesql varchar2(4000);
begin
  select count(*)
    into v_count
    from user_tables
   where table_name = tablename;
  if v_count > 0 then
    executesql := 'drop table ' || '"' || tablename || '"';
    execute immediate executesql;
  end if;
end proc_droptableifexists;
/
create or replace PROCEDURE PROC_DROPSCHTABLEIFEXISTS(tablename varchar2) is
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE ' || tablename;
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -942 THEN
      RAISE;
    END IF;
END;
/

 create or replace procedure proc_droptemptableifexists(tablename varchar2) is
   v_count number(10);
 begin
   select count(*)
     into v_count
     from user_objects
    where object_name = upper(tablename);
   if v_count > 0 then
     execute immediate 'drop table ' || tablename;
   end if;
 end proc_droptemptableifexists;
/
 create or replace procedure proc_dropviewifexists(tablename varchar2) is
   v_count    number(10);
   executesql varchar2(4000);
 begin
   select count(*)
     into v_count
     from user_views
    where view_name = tablename;
   if v_count > 0 then
     executesql := 'drop view ' || '"' || tablename || '"';
     execute immediate executesql;
   end if;
 end proc_dropviewifexists;
/
CREATE OR REPLACE FUNCTION alpine_miner_rf_inittra(schemaname   varchar2,
                                                         tablename    varchar2,
                                                         stamp        varchar2,
                                                         dependcolumn varchar2 )
  RETURN integer is
  
  
  rownumber   integer;
  
  peoso       binary_double;
 
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."pnew' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."dn' || stamp || '"'')';
  execute immediate 'alter session force parallel dml';
  execute immediate 'Create  table ' || schemaname || '."dn' || stamp ||
                    '" parallel  as (select ' || schemaname || '.' ||
                    tablename || '.* from ' || schemaname || '.' ||
                    tablename || ' where ' || dependcolumn ||
                    ' is not null)';
  execute immediate 'alter session disable parallel dml';
  execute immediate 'select count(*)   from ' || schemaname || '."dn' ||
                    stamp || '"'
    into rownumber;
  peoso := 1.0 / rownumber;
  execute immediate 'Create  table ' || schemaname || '."pnew' || stamp ||
                    '"    as (select ' || schemaname || '."dn' || stamp ||
                    '".*, row_number()over(order by 1) "alpine_randomforest_id", ' ||
                    peoso || ' "alpine_randomforest_peoso", rownum*' || peoso ||
                    ' "alpine_randomforest_totalpeoso" from ' || schemaname ||
                    '."dn' || stamp || '") ';

  RETURN rownumber;
end alpine_miner_rf_inittra;

/

CREATE OR REPLACE FUNCTION alpine_miner_rf_sample(schemaname varchar2,
                                                        tablename  varchar2,
                                                        stamp      varchar2,
                                                        partsize   integer)
  RETURN varchar2 is
  tempstring varchar2(32767);
  rownumber  integer;
  TYPE crt IS REF CURSOR;
  myrecord   crt;
  partnumber integer;
  splitpeoso Numberarray := Numberarray();
  maxpeoso   number;
  temppeoso  number;
  i          integer;
  executesql varchar2(32767);
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
  execute immediate 'select count(*) from ' || schemaname || '.' ||
                    tablename
    into rownumber;
  execute immediate ' select max("alpine_randomforest_totalpeoso")  from ' ||
                    schemaname || '.' || tablename
    into maxpeoso;
  if partsize >= rownumber then
    partnumber := 1;
  else
    if mod(rownumber, partsize) = 0 then
      partnumber := rownumber / partsize;
    else
      partnumber := trunc(rownumber / partsize) + 1;
    end if;
  end if;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."s' || stamp || '"'')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || schemaname ||
                    '."r' || stamp || '"'')';
  execute immediate 'create table ' || schemaname || '."r' || stamp ||
                    '"      as select SYS.DBMS_RANDOM.VALUE(0,' || maxpeoso ||
                    ')  "alpine_miner_randomforest_r" from ' || schemaname || '.' ||
                    tablename || ' order by SYS.DBMS_RANDOM.VALUE(0,' ||
                    maxpeoso || ')';
  if partnumber = 1 then
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    execute immediate 'create table ' || schemaname || '."s' || stamp ||
                      '"  parallel  as select * from ' || schemaname || '.' ||
                      tablename || ' join ' || schemaname || '."r' || stamp ||
                      '" on ' || schemaname || '.' || tablename ||
                      '."alpine_randomforest_totalpeoso"  >= ' || schemaname ||
                      '."r' || stamp || '"."alpine_miner_randomforest_r" and ' ||
                      schemaname || '.' || tablename ||
                      '."alpine_randomforest_peoso" > (' || schemaname || '.' ||
                      tablename || '."alpine_randomforest_totalpeoso"-' ||
                      schemaname || '."r' || stamp ||
                      '"."alpine_miner_randomforest_r")';
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    commit;
  else
    tempstring := ' select "alpine_randomforest_totalpeoso" as peoso from ' ||
                  schemaname || '.' || tablename ||
                  ' where mod("alpine_randomforest_id",' || partsize ||
                  ')=0 order by peoso';
    i          := 1;
    splitpeoso.extend();
    splitpeoso(i) := 0;
    open myrecord for tempstring;
    loop
      FETCH myrecord
        INTO temppeoso;
      EXIT WHEN myrecord%NOTFOUND;
      i := i + 1;
      splitpeoso.extend();
      splitpeoso(i) := temppeoso;
    end loop;
    if splitpeoso(i) != maxpeoso then
      i := i + 1;
      splitpeoso.extend();
      splitpeoso(i) := maxpeoso;
    end if;
    i          := 1;
    executesql := 'alter session force parallel dml';
    execute immediate executesql;
    tempstring := 'create table ' || schemaname || '."s' || stamp ||
                  '"  parallel as select * from  ( select * from ' ||
                  schemaname || '.' || tablename ||
                  ' where "alpine_randomforest_totalpeoso">' || splitpeoso(i) ||
                  ' and  "alpine_randomforest_totalpeoso"<=' ||
                  splitpeoso(i + 1) || ')   foo' || i ||
                  ' join (select * from "r' || stamp ||
                  '" where "alpine_miner_randomforest_r" >' || splitpeoso(i) ||
                  ' and  "alpine_miner_randomforest_r"<=' || splitpeoso(i + 1) ||
                  ')   foor' || i || ' on foo' || i ||
                  '."alpine_randomforest_totalpeoso" >=foor' || i ||
                  '."alpine_miner_randomforest_r" and foo' || i ||
                  '."alpine_randomforest_peoso" > (foo' || i ||
                  '."alpine_randomforest_totalpeoso"-foor' || i ||
                  '."alpine_miner_randomforest_r") ';
    execute immediate tempstring;
    executesql := 'alter session disable parallel dml';
    execute immediate executesql;
    commit;
    for i in 2 .. partnumber loop
      tempstring := '  insert into  ' || schemaname || '."s' || stamp ||
                    '"   select * from ( select * from ' || schemaname || '.' ||
                    tablename || ' where "alpine_randomforest_totalpeoso">' ||
                    splitpeoso(i) || ' and  "alpine_randomforest_totalpeoso"<=' ||
                    splitpeoso(i + 1) || ')   foo' || i ||
                    ' join (select * from "r' || stamp ||
                    '" where "alpine_miner_randomforest_r" >' || splitpeoso(i) ||
                    ' and "alpine_miner_randomforest_r"<=' || splitpeoso(i + 1) ||
                    ')   foor' || i || ' on foo' || i ||
                    '."alpine_randomforest_totalpeoso" >=foor' || i ||
                    '."alpine_miner_randomforest_r" and foo' || i ||
                    '."alpine_randomforest_peoso" > (foo' || i ||
                    '."alpine_randomforest_totalpeoso"-foor' || i ||
                    '."alpine_miner_randomforest_r") ';
      execute immediate 'select count(*) from ' || schemaname || '."s' ||
                        stamp || '"'
        into rownumber;
      execute immediate tempstring;
    end loop;
  end if;
  tempstring := 's' || stamp;
  commit;
  RETURN tempstring;
end alpine_miner_rf_sample;



/

CREATE OR REPLACE FUNCTION alpine_miner_rf_initpre(schemaname   varchar2,
                                                         tablename    varchar2,
                                                         stamp        varchar2,
                                                         infor        varchar2array)
  RETURN integer is
  tempstring clob;
  i          integer := 0;
  idtable    varchar2(32767);
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  commit;
  if schemaname is null then
    idtable := '"id' || stamp || '"';
  else
    idtable := schemaname || '."id' || stamp || '"';
  end if;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || idtable || ''')';
  execute immediate 'Create  table ' || idtable || ' as (select ' ||
                    tablename ||
                    '.*,row_number()over(order by 1) "alpine_randomforest_id" from ' ||
                    tablename || ')';
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || tablename ||
                    ''')';
  execute immediate 'Create  table ' || tablename || ' as select * from ' ||
                    idtable;
  execute immediate 'call PROC_DROPSCHTABLEIFEXISTS(''' || idtable || ''')';
  tempstring := 'update ' || tablename || ' set "C(' || infor(1) || ')"=0';
  i          := 0;
  for i in 2 .. infor.count() loop
    dbms_lob.append(tempstring, ', "C(' || infor(i) || ')"=0');
  end loop;
  execute immediate tempstring;
  commit;
  RETURN i;
end alpine_miner_rf_initpre;


/
CREATE OR REPLACE FUNCTION alpine_miner_rf_prere(tablename    varchar2,
                                                       dependcolumn varchar2,
                                                       infor        varchar2array,
                                                       isnumeric    int)
  RETURN binary_double AS
  rownumber   integer;
  classnumber integer;
  sqlan       clob;
  sql2        clob;
    i           integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
  err binary_double;
BEGIN
  commit;
  classnumber := infor.count();
  sqlan       := 'update ' || tablename || ' set  "P(' || dependcolumn ||
                 ')" = CASE';
  sql2        := '(';
  i           := classnumber;
  while i > 1 loop
    dbms_lob.append(sql2, '  "C(' || infor(i) || ')" ,');
    i := i - 1;
  end loop;
  dbms_lob.append(sql2, '"C(' || infor(1) || ')" )');
  for i in 1 .. classnumber loop
    dbms_lob.append(sqlan, ' WHEN "C(' || infor(i) || ')"=greatest');
    dbms_lob.append(sqlan, sql2);
    dbms_lob.append(sqlan, ' THEN ');
    if isnumeric = 1 then
      dbms_lob.append(sqlan, infor(i));
    else
      dbms_lob.append(sqlan, '''' || infor(i) || '''');
    end if;
  end loop;
  dbms_lob.append(sqlan, ' END ');
  execute immediate sqlan;
  err := err / rownumber;
  commit;
  RETURN err;
end alpine_miner_rf_prere;

/

CREATE OR REPLACE FUNCTION alpine_miner_rf_prestep(tablename     varchar2,
                                                         temptablename varchar2,
                                                        
                                                          infor         varchar2array)
  RETURN binary_double is
  
  sqlan       clob;
   i           integer := 0;
  PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN
  commit;
  sqlan := 'update ' || tablename || '  set "C(' || infor(1) || ')"=  "C(' ||
           infor(1) || ')"+ (select "C(' || infor(1) || ')"  from ' ||
           temptablename || '  where ' || tablename ||
           '."alpine_randomforest_id" = ' || temptablename ||
           '."alpine_randomforest_id")  ';
  for i in 2 .. infor.count() loop
    dbms_lob.append(sqlan,
                    ', "C(' || infor(i) || ')"=  "C(' || infor(i) ||
                    ')"+ (select "C(' || infor(i) || ')"  from ' ||
                    temptablename || '  where ' || tablename ||
                    '."alpine_randomforest_id" = ' || temptablename ||
                    '."alpine_randomforest_id")  ');
  end loop;
  execute immediate sqlan;
  commit;
  RETURN 1;
end alpine_miner_rf_prestep;

/

 



create or replace
FUNCTION alpine_miner_svd_l(input_matrix varchar2,p_name varchar2, q_name varchar2,  m_column varchar2, n_column varchar2, value_column varchar2, num_features integer, init_val binary_double)
  RETURN floatarray AS
    i int := 0;
    j int := 0;
    sqlstr varchar2(32767);
    float_temp binary_double := 0;
    alpha floatarray := floatarray();
    beta floatarray  := floatarray();
    executesql varchar2(1000) := '';
    PRAGMA AUTONOMOUS_TRANSACTION ; 
BEGIN
    sqlstr := 'call PROC_DROPSCHTABLEIFEXISTS( '''||p_name||''')';
    execute immediate sqlstr;
    sqlstr := 'call PROC_DROPSCHTABLEIFEXISTS( '''||q_name||''')';
    execute immediate sqlstr;
    sqlstr := 'call PROC_DROPSCHTABLEIFEXISTS( '''||p_name||'1'')';
    execute immediate sqlstr;
    sqlstr := 'call PROC_DROPSCHTABLEIFEXISTS( '''||q_name||'1'')';
    execute immediate sqlstr;
    executesql:='alter session force parallel dml';
    execute immediate executesql;
    sqlstr := 'CREATE  TABLE '||p_name||' parallel as select ' || m_column || ' as m_column , 1 as n_column, ' || 'cast(1.0 as binary_double)' || ' as val from ' || input_matrix || ' where 0 = 1';
    execute immediate sqlstr;
    executesql:='alter session disable parallel dml';
    execute immediate executesql;
    executesql:='alter session force parallel dml';
    execute immediate executesql;
    sqlstr := 'CREATE TABLE '||q_name||'  parallel as select ' || n_column || ' as n_column , 1 as m_column, ' || 'cast(1.0 as binary_double)' || ' as val from ' || input_matrix || ' where 0 = 1'; 
    execute immediate sqlstr;
    executesql:='alter session disable parallel dml';
    execute immediate executesql;
    executesql:='alter session force parallel dml';
    execute immediate executesql;
    sqlstr := 'CREATE TABLE '||p_name||'1 parallel as select ' || m_column || ' as m_column , ' || 'cast(1.0 as binary_double)' || ' as val from ' || input_matrix || ' where 0 = 1';
    execute immediate sqlstr;
    executesql:='alter session disable parallel dml';
    execute immediate executesql;
    executesql:='alter session force parallel dml';
    execute immediate executesql;
    sqlstr := 'CREATE TABLE '||q_name||'1  parallel as select ' || n_column || ' as n_column , ' || 'cast(1.0 as binary_double)' || ' as val from ' || input_matrix || ' where 0 = 1';
    execute immediate sqlstr;
    executesql:='alter session disable parallel dml';
    execute immediate executesql;
    j := 1;
    execute immediate 'INSERT  INTO '||q_name||'1 SELECT distinct ' || n_column || ', '||(init_val)||' FROM ' || input_matrix || ' where ' || n_column || ' is not null';
    execute immediate 'INSERT  INTO '||q_name||' SELECT n_column, 1, val FROM '||q_name||'1'; 

    while (j <=  num_features) loop
       if (j = 1) then
            execute immediate 'insert  into  '||p_name||'1  select a.' || m_column || ', sum(cast(a.'|| value_column ||' as binary_double) * '||q_name||'.val) from ' || input_matrix || ' a join '||q_name||' on a.' || n_column || ' = '||q_name||'.n_column and '||q_name||'.m_column = 1 and a.'|| value_column ||' is not null  group by a.'|| m_column ;
        else
            execute immediate 'insert   into '||p_name||'1  select  foo.m_column , foo.val - cast('||beta(j - 1)||'  as binary_double) * '||p_name||'.val  from  (select a.' || m_column || ' as m_column, sum(cast(a.'|| value_column ||' as binary_double) * '||q_name||'.val)  val from ' || input_matrix || ' a join '||q_name||' on a.'||n_column|| ' = '||q_name||'.n_column and '||q_name||'.m_column = '||j||' and a.'|| value_column ||' is not null group by a.'|| m_column ||')  foo join '||p_name||'  on foo.m_column  = '||p_name||'.m_column  and  '||p_name||'.n_column = '||(j- 1);
        end if;
        execute immediate  'select sqrt(sum(cast(val  as binary_double) * val)) from '||p_name||'1 ' into float_temp;
        alpha.extend();
        alpha(j) := float_temp;
      	if alpha(j) = 0
        then 
          beta.extend();
          beta(j) := 0;
      		exit;
        end if;
       execute immediate 'INSERT INTO '||p_name||' SELECT  m_column,'||(j)||', (cast(val as binary_double)/'||alpha(j)||') FROM '||p_name||'1'; 
       execute immediate 'TRUNCATE TABLE '||q_name||'1';
        execute immediate 'insert into '||q_name||'1 select foo.n_column , foo.val - cast('||alpha(j)||'  as binary_double) * '||q_name||'.val from  (select a.' || n_column || 'as n_column,  sum(a.'|| value_column ||' * '||p_name||'.val)   val from ' || input_matrix || ' a join '||p_name||' on a.' || m_column || ' = '||p_name||'.m_column and '||p_name||'.n_column = '||j||' and a.'|| value_column ||' is not null group by a.'|| n_column ||')  foo join '||q_name||'  on foo.n_column  = '||q_name||'.n_column and '||q_name||'.m_column = '||j;
        execute immediate  'select sqrt(sum(cast(val  as binary_double)* val)) from '||q_name||'1 ' into float_temp;
        beta.extend();
        beta(j) := float_temp;
       if beta(j) = 0
         then 
      		exit;
        end if;
        if (j != num_features) then
          execute immediate 'INSERT INTO '||q_name||' SELECT n_column, '||(j + 1)||', (cast(val as binary_double) /'||beta(j)||') FROM '||q_name||'1'; 
      	end if;
        sqlstr := 'TRUNCATE TABLE '||p_name||'1';
        execute immediate sqlstr;
        j := j + 1;
  end loop;
  execute immediate 'drop table '||p_name||'1';
  execute immediate 'drop table '||q_name||'1';
  for i in 1..beta.count() loop
     alpha.extend();
     alpha(alpha.count()) := beta(i);
  end loop;
  return alpha;   
END;
/
  CREATE OR REPLACE PROCEDURE PROC_DROPSCHTABLEIFEXISTS(tablename varchar2) is
  BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE ' || tablename;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
        RAISE;
      END IF;
  END;
/
 CREATE OR REPLACE FUNCTION ALPINE_MINER_SVD(input_matrix        varchar2,
                                             col_name            varchar2,
                                             row_name            varchar2,
                                             value               varchar2,
                                             num_features        int,
                                             ORIGINAL_STEP       float,
                                             SPEEDUP_CONST       float,
                                             FAST_SPEEDUP_CONST  float,
                                             SLOWDOWN_CONST      float,
                                             NUM_ITERATIONS      int,
                                             MIN_NUM_ITERATIONS  int,
                                             MIN_IMPROVEMENT     float,
                                             IMPROVEMENT_REACHED int,
                                             INIT_VALUE          float,
                                             EARLY_TEMINATE      int,
                                             matrix_u            varchar2,
                                             matrix_v            varchar2,
                                             drop_u              int,
                                             drop_v              int)
   RETURN int AS
   ORIGINAL_STEP_ADJUST float := 0;
   error                float := 0;
   old_error            float := 0;
   keep_ind             int := 1;
   SD_ind               int := 1;
   feature_x            float := 0;
   feature_y            float := 0;
   i                    int := 0;
   j                    int := 0;
   cells                int := 0;
   sqlstr               varchar2(32767) := '';
   step                 float := 0;
   imp_reached          int := 0;
   timestr              varchar2(32767) := '';
   executesql           varchar2(1000) := '';
   PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN
   execute immediate 'SELECT count(distinct ' || col_name || ') AS c FROM ' ||
                     input_matrix || ' where ' || col_name ||
                     ' is not null'
     into feature_x;
   execute immediate 'SELECT count(distinct ' || row_name || ') AS c FROM ' ||
                     input_matrix || ' where ' || row_name ||
                     ' is not null'
     into feature_y;
   execute immediate 'SELECT count(*) AS c FROM ' || input_matrix
     into cells;
   select to_char(sysdate, 'YYYYMMDDhh24miss') into timestr from dual;
   ORIGINAL_STEP_ADJUST := ORIGINAL_STEP / (feature_x + feature_y) /
                           (cells);
   if (drop_u = 1) then
     sqlstr := 'call PROC_DROPSCHTABLEIFEXISTS( ''' || matrix_u || ''')';
     execute immediate sqlstr;
   end if;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE ' || matrix_u ||
             ' parallel as select 1 as "alpine_feature" , ' || col_name || ', ' ||
             value || ' from ' || input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   if (drop_v = 1) then
     sqlstr := 'call PROC_DROPSCHTABLEIFEXISTS(''' || matrix_v || ''')';
     execute immediate sqlstr;
   end if;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE ' || matrix_v || ' parallel as select ' ||
             row_name || ' , 1 as "alpine_feature" , ' || value || ' from ' ||
             input_matrix || ' where 0 =  1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists( ''e' || timestr || '1'')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE e' || timestr || '1  parallel as select ' ||
             row_name || ' as row_num , ' || col_name || ' as col_num , ' ||
             value || ' as val from ' || input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists(  ''e' || timestr || '2'')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE e' || timestr || '2  parallel as select ' ||
             row_name || ' as row_num , ' || col_name || ' as col_num , ' ||
             value || ' as val from ' || input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists(  ''S' || timestr || '1'')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE S' || timestr || '1  parallel as select ' ||
             col_name || ' as col_num , ' || value || ' as val from ' ||
             input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists(  ''S' || timestr || '2'')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE S' || timestr || '2 parallel as select ' ||
             col_name || ' as col_num , ' || value || ' as val from ' ||
             input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists(  ''D' || timestr || '1'')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE D' || timestr || '1  parallel as select ' ||
             row_name || ' as row_num , ' || value || ' as val from ' ||
             input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists(  ''D' || timestr || '2'')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE D' || timestr || '2 parallel as select ' ||
             row_name || ' as row_num , ' || value || ' as val from ' ||
             input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   sqlstr := 'call proc_droptableifexists(  ''e' || timestr || ''')';
   execute immediate sqlstr;
   executesql := 'alter session force parallel dml';
   execute immediate executesql;
   sqlstr := 'CREATE TABLE e' || timestr || ' parallel as select ' ||
             row_name || ' as row_num , ' || col_name || ' as col_num , ' ||
             value || ' as val from ' || input_matrix || ' where 0 = 1';
   execute immediate sqlstr;
   executesql := 'alter session disable parallel dml';
   execute immediate executesql;
   execute immediate 'INSERT INTO e' || timestr || '1 SELECT ' || row_name || ', ' ||
                     col_name || ', ' || value || ' FROM ' || input_matrix;
   j := 1;
   while (j <= num_features) loop
     sqlstr := 'TRUNCATE TABLE S' || timestr || '1';
     execute immediate sqlstr;
     sqlstr := 'TRUNCATE TABLE S' || timestr || '2';
     execute immediate sqlstr;
     sqlstr := 'TRUNCATE TABLE D' || timestr || '1';
     execute immediate sqlstr;
     sqlstr := 'TRUNCATE TABLE D' || timestr || '2';
     execute immediate sqlstr;
     execute immediate 'INSERT INTO S' || timestr || '1 SELECT distinct ' ||
                       col_name || ', ' || (INIT_VALUE) || ' FROM ' ||
                       input_matrix || ' where ' || col_name ||
                       ' is not null';
     execute immediate 'INSERT INTO D' || timestr || '1 SELECT distinct ' ||
                       row_name || ', ' || (INIT_VALUE) || ' FROM ' ||
                       input_matrix || ' where ' || row_name ||
                       ' is not null';
     SD_ind      := 1;
     i           := 0;
     step        := ORIGINAL_STEP_ADJUST;
     imp_reached := 0;
     while (true) loop
       i      := i + 1;
       sqlstr := 'TRUNCATE TABLE e' || timestr;
       execute immediate sqlstr;
       sqlstr := 'INSERT INTO e' || timestr ||
                 ' SELECT a.row_num, a.col_num, a.val-b.val*c.val FROM e' ||
                 timestr || (keep_ind) || '  a, S' || timestr || (SD_ind) ||
                 '  b, D' || timestr || (SD_ind) ||
                 '  c WHERE a.row_num=c.row_num AND a.col_num=b.col_num';
       execute immediate sqlstr;
       old_error := error;
       execute immediate 'SELECT sqrt(sum(val*val)) AS c FROM e' || timestr
         into error;
       if (((abs(error - old_error) < MIN_IMPROVEMENT) and
          (i >= MIN_NUM_ITERATIONS) and
          ((error < MIN_IMPROVEMENT) or (not (IMPROVEMENT_REACHED = 1)) or
          (imp_reached = 1))) or (NUM_ITERATIONS < i)) then
         exit;
       end if;
       if ((abs(error - old_error) >= MIN_IMPROVEMENT) and (old_error > 0)) then
         imp_reached := 1;
       end if;
       if ((error > old_error) and (old_error != 0)) then
         error  := 0;
         step   := step * SLOWDOWN_CONST;
         SD_ind := mod(SD_ind, 2) + 1;
       else
         if (sqrt((error - old_error) * (error - old_error)) <
            .1 * MIN_IMPROVEMENT) then
           step := step * FAST_SPEEDUP_CONST;
         else
           step := step * SPEEDUP_CONST;
         end if;
         execute immediate 'TRUNCATE TABLE S' || timestr ||
                           (mod(SD_ind, 2) + 1);
         execute immediate 'TRUNCATE TABLE D' || timestr ||
                           (mod(SD_ind, 2) + 1);
         execute immediate 'INSERT INTO S' || timestr ||
                           (mod(SD_ind, 2) + 1) ||
                           ' SELECT a.col_num, avg(b.val)+sum(a.val*c.val)*' ||
                           (step) || ' FROM e' || timestr || '  a, S' ||
                           timestr || (SD_ind) || '  b, D' || timestr ||
                           (SD_ind) ||
                           '  c WHERE a.col_num = b.col_num AND a.row_num=c.row_num GROUP BY a.col_num';
         execute immediate 'INSERT INTO D' || timestr ||
                           (mod(SD_ind, 2) + 1) ||
                           ' SELECT a.row_num, avg(c.val)+sum(a.val*b.val)*' ||
                           (step) || ' FROM e' || timestr || '  a, S' ||
                           timestr || (SD_ind) || '  b, D' || timestr ||
                           (SD_ind) ||
                           '  c WHERE a.col_num = b.col_num AND a.row_num=c.row_num GROUP BY a.row_num';
         SD_ind := mod(SD_ind, 2) + 1;
       end if;
     end loop;
     execute immediate 'TRUNCATE TABLE e' || timestr ||
                       (mod(keep_ind, 2) + 1);
     execute immediate 'INSERT INTO e' || timestr || (mod(keep_ind, 2) + 1) ||
                       ' SELECT a.row_num, a.col_num, (a.val-b.val*c.val) FROM e' ||
                       timestr || (keep_ind) || '  a, S' || timestr ||
                       (SD_ind) || '  b, D' || timestr || (SD_ind) ||
                       '  c WHERE a.col_num = b.col_num AND a.row_num=c.row_num';
     keep_ind := mod(keep_ind, 2) + 1;
     execute immediate 'INSERT INTO ' || matrix_u || ' SELECT ' || (j) ||
                       ', col_num, val FROM S' || timestr || (SD_ind);
     execute immediate 'INSERT INTO ' || matrix_v || ' SELECT row_num, ' || (j) ||
                       ', val FROM D' || timestr || (SD_ind);
     if ((error < MIN_IMPROVEMENT) and (EARLY_TEMINATE = 1)) then
       exit;
     end if;
     error := 0;
     j     := j + 1;
   end loop;
   sqlstr := 'call proc_droptableifexists(  ''e' || timestr || '1'')';
   execute immediate sqlstr;
   sqlstr := 'call proc_droptableifexists( ''e' || timestr || '2'')';
   execute immediate sqlstr;
   sqlstr := 'call proc_droptableifexists( ''S' || timestr || '1'')';
   execute immediate sqlstr;
   sqlstr := 'call proc_droptableifexists( ''S' || timestr || '2'')';
   execute immediate sqlstr;
   sqlstr := 'call proc_droptableifexists( ''D' || timestr || '1'')';
   execute immediate sqlstr;
   sqlstr := 'call proc_droptableifexists( ''D' || timestr || '2'')';
   execute immediate sqlstr;
   sqlstr := 'call proc_droptableifexists( ''e' || timestr || ''')';
   execute immediate sqlstr;
   return 1;
 end;
/

create or replace TYPE alpine_miner_svm_model AS object(
       inds int,
       cum_err binary_double,
       epsilon binary_double,
       rho binary_double,
       b   binary_double,
       nsvs int,
       ind_dim int,
       weights floatarray,
       individuals floatarray
);
/

create or replace TYPE alpine_miner_svm_model_faa AS object(
       inds int,
       cum_err binary_double,
       epsilon binary_double,
       rho binary_double,
       b   binary_double,
       nsvs int,
       ind_dim int,
       weights floatarrayarray,
       individuals floatarrayarray
);
/

create or replace FUNCTION alpine_miner_dot_kernel(x floatarray, y floatarray) RETURN binary_double AS
	len int;
	ret binary_double := 0;
BEGIN
	if x.count() < y.count() then
		len := x.count();
	else
		len := y.count();
	end if;
	FOR i in 1..len LOOP
	    ret := ret + x(i)*y(i);
	END LOOP;
	RETURN ret;
END;
/

CREATE OR REPLACE FUNCTION alpine_miner_polynomial_kernel(x floatarray, y floatarray, degree int) RETURN binary_double AS
BEGIN
	RETURN power(alpine_miner_dot_kernel(x,y),degree);
END;
/


create or replace
FUNCTION alpine_miner_gaussian_kernel(x floatarray, y floatarray, gamma binary_double) RETURN binary_double AS
	i int;
	len int;
	temp binary_double;
	diff floatarray := floatarray();
BEGIN
	if (x.count() < y.count) then
		len := x.count();
	else 
		len := y.count();
	end if;
	diff := floatarray();
	for i in 1..len loop
		diff.extend();
		diff(i) := x(i) - y(i);
	end loop;
	temp := -1.0 * gamma * alpine_miner_dot_kernel(diff,diff);
	if (temp < -30) then
		temp := -30;
	elsif(temp > 30) then
		temp := 30;
	end if;
	RETURN exp(temp);
END;
/
create or replace FUNCTION alpine_miner_kernel(x floatarray, y floatarray, kernel_type int, degree int, gamma binary_double) RETURN binary_double AS

	len INT;
BEGIN
	if kernel_type = 1 then
		RETURN alpine_miner_dot_kernel(x, y);
	else
		if kernel_type = 2 then
			return alpine_miner_polynomial_kernel(x, y, degree);
		else
			if kernel_type = 3 then
				return alpine_miner_gaussian_kernel(x, y, gamma);
			else
				return alpine_miner_dot_kernel(x, y);
			end if;
		end if;
	end if;


END;
/
create or replace FUNCTION
alpine_miner_svs_predict_fa(svs alpine_miner_svm_model, ind floatarray, kernel_type int, degree int, gamma binary_double)
RETURN binary_double AS

	ret binary_double := 0;
	individual floatArray ;
	i int;
	j int;
BEGIN
	FOR i IN 1..svs.nsvs LOOP
	    individual := floatArray();
	    FOR j IN 1..svs.ind_dim LOOP
	        individual.extend();
		individual(j) := svs.individuals(svs.ind_dim*(i - 1) + j);
	    END LOOP;
	    ret := ret + svs.weights(i) * alpine_miner_kernel(individual, ind , kernel_type, degree, gamma);
        END LOOP;
	RETURN ret;
END;
/

create or replace FUNCTION
alpine_miner_svs_predict(svs_faa alpine_miner_svm_model_faa, ind floatarrayarray, kernel_type int, degree int, gamma binary_double)
RETURN binary_double AS

	ret binary_double := 0;
	svs alpine_miner_svm_model;
	weights floatarray;
	individuals floatarray;
	ind_fa floatarray;
BEGIN
	weights := alpine_miner_faa2fa(svs_faa.weights);
	individuals := alpine_miner_faa2fa(svs_faa.individuals);
	ind_fa :=  alpine_miner_faa2fa(ind);
    	svs := alpine_miner_svm_model(svs_faa.inds, svs_faa.cum_err, svs_faa.epsilon, svs_faa.rho, svs_faa.b, svs_faa.nsvs, svs_faa.ind_dim, weights, individuals);
	RETURN alpine_miner_svs_predict_fa(svs, ind_fa , kernel_type, degree, gamma);
END;
/

create or replace
FUNCTION alpine_miner_online_sv_reg(table_name VARCHAR2,ind varchar2,label varchar2,wherecond varchar2array, kernel_type int, degree int, gamma binary_double, eta binary_double, slambda binary_double, nu binary_double)
RETURN alpine_miner_svm_model AS
  TYPE crt IS REF CURSOR;
	p binary_double;
	diff binary_double;
	error binary_double;
	weight binary_double;
  svs alpine_miner_svm_model := null;
  sqlstr varchar2(32767);
  c1 crt;
  fa floatArray;
  faa floatArrayArray;
  labelvalue binary_double;
  cap binary_double;
  i int := 0;
  j int := 0;
  wherestr varchar2(32767):= '';

BEGIN
  for i in 1..wherecond.count() loop
  	if(i != 1) then
  		wherestr := wherestr||' and ';
  	end if;
  	wherestr := wherestr||wherecond(i)||' is not null ';
  end loop;
  wherestr := wherestr||' and '||label||' is not null ';
  sqlstr := 'select '||ind||','||label||' from '||table_name||' where '||wherestr;
  svs := alpine_miner_svm_model(0,0,0,0,1,0,0,floatarray(),floatarray());
  open c1 for sqlstr;
  i := 0;
  j := 0;
  LOOP

  FETCH c1 INTO faa, labelvalue;
  EXIT WHEN c1%NOTFOUND;

  fa := alpine_miner_faa2fa(faa);
  IF j = 0 THEN
  svs.ind_dim := fa.count();
  END IF;

    p := alpine_miner_svs_predict_fa(svs, fa , kernel_type, degree, gamma);

    diff := labelvalue - p;
    error := abs(diff);
    svs.inds := svs.inds + 1;
    svs.cum_err := svs.cum_err + error;

    cap := 0.1 + 1 / (1 - eta * slambda);

    IF (error > svs.epsilon) THEN
        FOR i IN 1..svs.nsvs LOOP
	  if (abs(svs.weights(i)) < (cap + 0.1) * 2.2250738585072014e-308) then 
            svs.weights(i) := 0;
	  else 
            svs.weights(i) := svs.weights(i) * (1 - eta * slambda);
          end if;
        END LOOP;
        weight := eta;
        IF (diff < 0) THEN weight := -1 * weight; END IF;
        svs.nsvs := svs.nsvs + 1;
        svs.weights.extend();
        svs.weights(svs.nsvs) := weight;
	FOR i IN 1..fa.count() LOOP
          svs.individuals.extend();
          svs.individuals(svs.individuals.count()) := fa(i);
	END LOOP;
        svs.epsilon := svs.epsilon + (1 - nu) * eta;
    ELSE
        svs.epsilon := svs.epsilon - eta * nu;
    END IF;
  j := j + 1;
  END LOOP;
	return svs;
END;
/

create or replace
FUNCTION alpine_miner_online_sv_cl(table_name VARCHAR2,ind varchar2,label varchar2,wherecond varchar2array, kernel_type int, degree int, gamma binary_double,eta binary_double, nu binary_double)
RETURN alpine_miner_svm_model AS
  TYPE crt IS REF CURSOR;
	p binary_double;
	svs alpine_miner_svm_model := null;
  sqlstr varchar2(32767);
  c1 crt;
  fa floatArray;
  faa floatArrayArray;
  labelvalue binary_double;
  i int := 0;
  j int := 0;
  wherestr varchar2(32767):= '';

BEGIN
  for i in 1..wherecond.count() loop
  	if(i != 1) then
  		wherestr := wherestr||' and ';
  	end if;
  	wherestr := wherestr||wherecond(i)||' is not null ';
  end loop;
  wherestr := wherestr||' and '||label||' is not null ';
  sqlstr := 'select '||ind||','||label||' from '||table_name||' where '||wherestr;
  svs := alpine_miner_svm_model(0,0,0,0,1,0,0,floatarray(),floatarray());
  open c1 for sqlstr;
  i := 0;
  j := 0;
  LOOP

  FETCH c1 INTO faa, labelvalue;
  EXIT WHEN c1%NOTFOUND;

  fa := alpine_miner_faa2fa(faa);
  IF j = 0 THEN
  svs.ind_dim := fa.count();
  END IF;
	p := labelvalue * (alpine_miner_svs_predict_fa(svs, fa, kernel_type, degree, gamma) + svs.b);
	svs.inds := svs.inds + 1;
	IF p < 0 THEN
	    svs.cum_err := svs.cum_err + 1;
        END IF;

	IF (p <= svs.rho) THEN
	    FOR i IN 1..svs.nsvs LOOP
		  if (abs(svs.weights(i)) < 1.15 * 2.2250738585072014e-308) then
			  svs.weights(i) := 0;
		  else
	    	          svs.weights(i) := svs.weights(i) * (1 - 0.1 * eta);
		  end if;  
            END LOOP;

	    svs.nsvs := svs.nsvs + 1;
        svs.weights.extend();
        svs.weights(svs.nsvs) := labelvalue * eta;
	FOR i IN 1..fa.count() LOOP
          svs.individuals.extend();
          svs.individuals(svs.individuals.count()) := fa(i);
	END LOOP;
	    svs.b := svs.b + eta * labelvalue;
	    svs.rho := svs.rho - eta * (1 - nu);
	ELSE
	    svs.rho := svs.rho +  eta * nu;
    END IF;
  j := j + 1;
  END LOOP;
	return svs;
END;
/

create or replace
FUNCTION alpine_miner_online_sv_nd(table_name VARCHAR2,ind varchar2, wherecond varchar2array, kernel_type int, degree int, gamma binary_double, eta binary_double, nu binary_double)
RETURN alpine_miner_svm_model AS
  TYPE crt IS REF CURSOR;
	p binary_double;
	svs alpine_miner_svm_model := null;
  sqlstr varchar2(32767);
  c1 crt;
  fa floatArray;
  faa floatArrayArray;
  i int := 0;
  j int := 0;
  wherestr varchar2(32767):= '';

BEGIN
  for i in 1..wherecond.count() loop
  	if(i != 1) then
  		wherestr := wherestr||' and ';
  	end if;
  	wherestr := wherestr||wherecond(i)||' is not null ';
  end loop;

  sqlstr := 'select '||ind||' from '||table_name||' where '||wherestr;
  svs := alpine_miner_svm_model(0,0,0,0,0,0,0, floatarray(), floatarray());
  open c1 for sqlstr;
  i := 0;
  j := 0;
  LOOP

  FETCH c1 INTO faa;
  EXIT WHEN c1%NOTFOUND;

  fa := alpine_miner_faa2fa(faa);
  IF j = 0 THEN
  svs.ind_dim := fa.count();
  END IF;
	p := alpine_miner_svs_predict_fa(svs, fa, kernel_type, degree, gamma);
	svs.inds := svs.inds + 1;

	IF (p < svs.rho) THEN
	    FOR i IN 1..svs.nsvs LOOP
		  if (svs.weights(i) < 1.15 * 2.2250738585072014e-308) then
			  svs.weights(i) := 0;
		  else
	    	          svs.weights(i) := svs.weights(i) * (1 - 0.1 * eta);
		  end if; 
            END LOOP;

	    svs.nsvs := svs.nsvs + 1;
	    svs.weights.extend();
        svs.weights(svs.nsvs) := eta;
	FOR i IN 1..fa.count() LOOP
          svs.individuals.extend();
          svs.individuals(svs.individuals.count()) := fa(i);
	END LOOP;
	    svs.rho := svs.rho - eta * (1 - nu);
	ELSE
	    svs.rho := svs.rho + eta * nu;
    END IF;
  j := j + 1;
  END LOOP;
	return svs;
END;
/



